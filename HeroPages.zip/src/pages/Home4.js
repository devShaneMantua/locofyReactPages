import Navbar4 from "../components/Navbar4";
import Header3 from "../components/Header3";
import Layout14 from "../components/Layout14";
import Layout13 from "../components/Layout13";
import Testimonial5 from "../components/Testimonial5";
import Pricing from "../components/Pricing";
import FAQ3 from "../components/FAQ3";
import Layout12 from "../components/Layout12";
import CTA1 from "../components/CTA1";
import Footer3 from "../components/Footer3";
import styled from "styled-components";

const HomeRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Home4 = () => {
  return (
    <HomeRoot>
      <Navbar4 />
      <Header3 placeholderImage="/placeholder--lightbox.svg" />
      <Layout14 />
      <Layout13 />
      <Testimonial5 />
      <Pricing />
      <FAQ3 />
      <Layout12 />
      <CTA1
        heading="Call to action that excites the visitor to try your product"
        button="Get started"
        button1="Learn more"
      />
      <Footer3 />
    </HomeRoot>
  );
};

export default Home4;
