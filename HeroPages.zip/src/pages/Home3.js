import Navbar from "../components/Navbar";
import Header from "../components/Header";
import Logo from "../components/Logo";
import Layout1 from "../components/Layout1";
import Layout from "../components/Layout";
import Testimonial from "../components/Testimonial";
import styled from "styled-components";
import Column2 from "../components/Column2";
import Column1 from "../components/Column1";
import Column from "../components/Column";
import Blog from "../components/Blog";
import Footer from "../components/Footer";

const Heading = styled.h1`
  margin: 0;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 750px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Card = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const HeadingParent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Pricing20Inner = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const PlaceholderImage = styled.div`
  width: 1312px;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
  }
`;
const Pricing = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1050px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const HomeRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Home3 = () => {
  return (
    <HomeRoot>
      <Navbar />
      <Header />
      <Logo />
      <Layout1 />
      <Layout />
      <Testimonial />
      <Pricing>
        <Pricing20Inner>
          <HeadingParent>
            <Heading>Pricing plan</Heading>
            <Card>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Card>
          </HeadingParent>
        </Pricing20Inner>
        <PlaceholderImage>
          <Column2 />
          <Column1 />
          <Column />
        </PlaceholderImage>
      </Pricing>
      <Blog />
      <Footer />
    </HomeRoot>
  );
};

export default Home3;
