import Navbar5 from "../components/Navbar5";
import styled from "styled-components";
import Logo3 from "../components/Logo3";
import Layout19 from "../components/Layout19";
import Layout18 from "../components/Layout18";
import Testimonial7 from "../components/Testimonial7";
import Blog4 from "../components/Blog4";
import FAQ5 from "../components/FAQ5";
import Footer5 from "../components/Footer5";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 134px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-26xl);
    line-height: 54px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
`;
const Icon = styled.div`
  width: 560px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xl);
  background-color: var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Actions = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
`;
const Column = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  box-sizing: border-box;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Header = styled.section`
  align-self: stretch;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: 0px var(--padding-45xl);
  box-sizing: border-box;
  background-image: url("/header--5@3x.png");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
  min-height: 900px;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h1-size);
  color: var(--white);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
`;
const HomeRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Home7 = () => {
  return (
    <HomeRoot>
      <Navbar5 />
      <Header>
        <Column>
          <Content>
            <Heading>Describe what your company does in a few words</Heading>
            <Icon>
              Describe exactly what the company does and what a customer can
              expect when working with the company. Avoid using verbose words or
              phrases.
            </Icon>
          </Content>
          <Actions>
            <Button1>
              <Button>Book a consultation</Button>
            </Button1>
          </Actions>
        </Column>
      </Header>
      <Logo3 />
      <Layout19 />
      <Layout18 />
      <Testimonial7 />
      <Blog4 />
      <FAQ5 />
      <Footer5 />
    </HomeRoot>
  );
};

export default Home7;
