import Navbar3 from "../components/Navbar3";
import Header6 from "../components/Header6";
import Layout17 from "../components/Layout17";
import styled from "styled-components";
import Gallery from "../components/Gallery";
import CTA1 from "../components/CTA1";
import Blog3 from "../components/Blog3";
import Footer4 from "../components/Footer4";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const SectionTitle = styled.div`
  align-self: stretch;
  height: 81px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const GalleryFrame = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const PlaceholderImage = styled.img`
  height: 640px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 400px;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const Layout = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1200px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1050px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;
const HomeRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Home6 = () => {
  return (
    <HomeRoot>
      <Navbar3
        button="Book now"
        columnOverflow="hidden"
        buttonOverflow="hidden"
        buttonWidth="113px"
      />
      <Header6 />
      <Layout17 />
      <Layout>
        <GalleryFrame>
          <Heading>Tell the visitor what the [restuarant] is about</Heading>
          <SectionTitle>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla, ut commodo diam libero
            vitae erat.
          </SectionTitle>
        </GalleryFrame>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-7@2x.png"
        />
      </Layout>
      <Gallery />
      <CTA1
        heading="Call to action that invites the visitor to book"
        button="Book now"
        button1="View menu"
        propHeight="116px"
        propWidth="262px"
        propFlex="1"
      />
      <Blog3 />
      <Footer4 />
    </HomeRoot>
  );
};

export default Home6;
