import Navbar3 from "../components/Navbar3";
import Header4 from "../components/Header4";
import Column5 from "../components/Column5";
import styled from "styled-components";
import Layout11 from "../components/Layout11";
import Layout10 from "../components/Layout10";
import Testimonial4 from "../components/Testimonial4";
import Layout9 from "../components/Layout9";
import Testimonial3 from "../components/Testimonial3";
import CTA from "../components/CTA";
import FAQ2 from "../components/FAQ2";
import Footer2 from "../components/Footer2";

const Layout = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-29xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-29xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;
const HomeRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Home2 = () => {
  return (
    <HomeRoot>
      <Navbar3 button="Try for free" />
      <Header4 />
      <Layout>
        <Column5
          heading="Highlight benefit one"
          propTextAlign="left"
          propTextAlign1="left"
        />
        <Column5
          heading="Highlight benefit two"
          propTextAlign="left"
          propTextAlign1="left"
        />
        <Column5
          heading="Highlight benefit three"
          propTextAlign="left"
          propTextAlign1="left"
        />
      </Layout>
      <Layout11 />
      <Layout10
        placeholderImage="/placeholder--image-7@2x.png"
        subheading="Feature one"
        featureOne="feature one"
      />
      <Testimonial4 />
      <Layout9 />
      <Testimonial3 />
      <Layout10
        placeholderImage="/placeholder--image-31@2x.png"
        subheading="Feature three"
        featureOne="feature three"
      />
      <CTA />
      <FAQ2 />
      <Footer2 />
    </HomeRoot>
  );
};

export default Home2;
