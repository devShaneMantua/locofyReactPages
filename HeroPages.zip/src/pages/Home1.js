import Navbar2 from "../components/Navbar2";
import Header3 from "../components/Header3";
import Logo2 from "../components/Logo2";
import Layout8 from "../components/Layout8";
import Layout7 from "../components/Layout7";
import Layout6 from "../components/Layout6";
import Testimonial2 from "../components/Testimonial2";
import Header1 from "../components/Header1";
import FAQ1 from "../components/FAQ1";
import Blog2 from "../components/Blog2";
import NewsletterFrame from "../components/NewsletterFrame";
import FooterLinksContainer from "../components/FooterLinksContainer";
import styled from "styled-components";

const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const SocialIconsContainer = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const Link1 = styled.div`
  flex: 1;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
  min-width: 68px;
`;
const FooterLinks = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 224px;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Credits = styled.div`
  width: 589px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const IconFacebook = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const SocialLinks = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 1050px) {
    flex-wrap: wrap;
  }
`;
const Footer = styled.footer`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  max-width: 100%;
  z-index: 1;
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
    padding: var(--padding-33xl) var(--padding-21xl);
    box-sizing: border-box;
  }
`;
const HomeRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Home1 = () => {
  return (
    <HomeRoot>
      <Navbar2 />
      <Header3 placeholderImage="/placeholder--image-6@2x.png" />
      <Logo2 />
      <Layout8 heading="Describe feature one" />
      <Layout7 />
      <Layout8 heading="Describe feature three" />
      <Layout6 />
      <Testimonial2 />
      <Header1 />
      <FAQ1 />
      <Blog2 />
      <Footer>
        <NewsletterFrame />
        <FooterLinksContainer />
        <Divider />
        <Row>
          <Credits>
            <SocialIconsContainer>
              © 2023 Relume. All rights reserved.
            </SocialIconsContainer>
            <FooterLinks>
              <Link>Privacy Policy</Link>
              <Link1>Terms of Service</Link1>
              <Link1>Cookies Settings</Link1>
            </FooterLinks>
          </Credits>
          <SocialLinks>
            <IconFacebook loading="eager" alt="" src="/icon--facebook.svg" />
            <IconFacebook alt="" src="/icon--instagram.svg" />
            <IconFacebook alt="" src="/icon--twitter.svg" />
            <IconFacebook alt="" src="/icon--linkedin.svg" />
          </SocialLinks>
        </Row>
      </Footer>
    </HomeRoot>
  );
};

export default Home1;
