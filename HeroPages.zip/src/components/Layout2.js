import styled from "styled-components";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Header = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Number1 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const ListItem = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  min-width: 192px;
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-5xl);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
    min-width: 100%;
  }
`;
const PlaceholderImage = styled.img`
  height: 640px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 400px;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1200px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1050px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Layout2 = () => {
  return (
    <LayoutRoot>
      <Content1>
        <SectionTitle>
          <Subheading>Customer Stories</Subheading>
          <Content>
            <Heading>Headline highlighting customer results</Heading>
            <Header>
              Emphasise time-saving and use numbers to maximise credibility.
            </Header>
          </Content>
        </SectionTitle>
        <Content>
          <Row>
            <ListItem>
              <Number1>10x</Number1>
              <Text1>Increase in productivity</Text1>
            </ListItem>
            <ListItem>
              <Number1>300%</Number1>
              <Text1>Return on investment</Text1>
            </ListItem>
          </Row>
          <Row>
            <ListItem>
              <Number1>5k+</Number1>
              <Text1>Happy customers</Text1>
            </ListItem>
            <ListItem>
              <Number1>100+</Number1>
              <Text1>5-star reviews</Text1>
            </ListItem>
          </Row>
        </Content>
      </Content1>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image-7@2x.png"
      />
    </LayoutRoot>
  );
};

export default Layout2;
