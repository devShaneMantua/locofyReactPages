import Content from "./Content";
import MenuList from "./MenuList";
import styled from "styled-components";
import BlogItem from "./BlogItem";

const Menu = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-13xl) var(--padding-13xl)
    var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  min-width: 546px;
  max-width: 100%;
  @media screen and (max-width: 1125px) {
    padding-left: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
    padding-top: var(--padding-2xl);
    padding-bottom: var(--padding-2xl);
    box-sizing: border-box;
  }
`;
const FeaturedFromBlog = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  font-weight: 600;
`;
const BlogList = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Blog = styled.div`
  width: 600px;
  background-color: var(--light-grey);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-77xl) var(--padding-13xl)
    var(--padding-13xl);
  box-sizing: border-box;
  gap: var(--gap-base);
  min-width: 600px;
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex: 1;
  }
  @media screen and (max-width: 800px) {
    padding-right: var(--padding-29xl);
    box-sizing: border-box;
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-2xl);
    padding-right: var(--padding-xl);
    padding-bottom: var(--padding-2xl);
    box-sizing: border-box;
  }
`;
const MegaMenu = styled.div`
  align-self: stretch;
  background-color: var(--white);
  box-shadow: 0px -1px 0px #000 inset;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  row-gap: 20px;
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex-wrap: wrap;
  }
`;
const NavbarRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Navbar4 = () => {
  return (
    <NavbarRoot>
      <Content
        button="Log in"
        button1="Get started"
        buttonWidth="220px"
        buttonWidth1="86px"
        buttonWidth2="47.56px"
        buttonDisplay="inline-block"
        propFlex="1"
      />
      <MegaMenu>
        <Menu>
          <MenuList
            pageGroupOne="Page group one"
            pageOne="Page One"
            pageTwo="Page Two"
            pageThree="Page Three"
            pageFour="Page Four"
          />
          <MenuList
            pageGroupOne="Page group two"
            pageOne="Page Five"
            pageTwo="Page Six"
            pageThree="Page Seven"
            pageFour="Page Eight"
          />
        </Menu>
        <Blog>
          <FeaturedFromBlog>Featured from Blog</FeaturedFromBlog>
          <BlogList>
            <BlogItem />
            <BlogItem />
          </BlogList>
          <Button1>
            <Button>See all articles</Button>
            <IconChevronRight alt="" src="/icon--chevron-right.svg" />
          </Button1>
        </Blog>
      </MegaMenu>
    </NavbarRoot>
  );
};

export default Navbar4;
