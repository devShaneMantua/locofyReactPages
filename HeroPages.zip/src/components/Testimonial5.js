import Actions from "./Actions";
import styled from "styled-components";

const Dot = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--black);
`;
const Dot1 = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--neutral-gray);
`;
const SliderDots = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Icon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xs);
  background-color: transparent;
  height: 48px;
  width: 48px;
  border-radius: var(--br-31xl);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const TextBlock = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-mini);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--gap-xl);
`;
const TestimonialRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const Testimonial5 = () => {
  return (
    <TestimonialRoot>
      <Actions
        placeholderImage="/placeholder--image-32@2x.png"
        aCustomerTestimonialThatH={`"A customer testimonial that highlights features and answers potential customer doubts about your product or service. Showcase testimonials from a similar demographic to your customers."`}
      />
      <Content>
        <SliderDots>
          <Dot />
          <Dot1 />
        </SliderDots>
        <TextBlock>
          <Button>
            <Icon alt="" src="/icon.svg" />
          </Button>
          <Button>
            <Icon alt="" src="/icon-1.svg" />
          </Button>
        </TextBlock>
      </Content>
    </TestimonialRoot>
  );
};

export default Testimonial5;
