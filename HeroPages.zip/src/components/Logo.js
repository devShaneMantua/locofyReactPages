import styled from "styled-components";

const Heading = styled.h3`
  margin: 0;
  height: 102px;
  width: 320px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  flex-shrink: 0;
  min-width: 320px;
  @media screen and (max-width: 1225px) {
    flex: 1;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const RelumeBlack = styled.img`
  align-self: stretch;
  width: 140px;
  position: relative;
  max-height: 100%;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 56px;
`;
const RowContent = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 1050px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;
const LogoRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1225px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 750px) {
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const Logo = () => {
  return (
    <LogoRoot>
      <Heading>
        Trusted by the world's best companies [social proof to build
        credibility]
      </Heading>
      <RowContent>
        <WebflowBlack loading="eager" alt="" src="/webflow--black.svg" />
        <RelumeBlack loading="eager" alt="" src="/relume--black.svg" />
        <WebflowBlack alt="" src="/webflow--black.svg" />
        <RelumeBlack alt="" src="/relume--black.svg" />
        <WebflowBlack alt="" src="/webflow--black.svg" />
      </RowContent>
    </LogoRoot>
  );
};

export default Logo;
