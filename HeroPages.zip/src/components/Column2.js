import styled from "styled-components";
import Check from "./Check";

const Heading = styled.b`
  position: relative;
  line-height: 140%;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 22px;
  }
`;
const Subheading = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Heading1 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const HeadingWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  border-top: 1px solid var(--black);
  box-sizing: border-box;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs);
  background-color: var(--black);
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Check1 = styled.input`
  margin: 0;
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const ListItemText = styled.div`
  position: relative;
  line-height: 150%;
`;
const ListItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const List = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-base);
  text-align: left;
  font-size: var(--text-regular-normal-size);
`;
const ColumnRoot = styled.div`
  width: 416px;
  border: 1px solid var(--black);
  box-sizing: border-box;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-12xl) var(--padding-93xl);
  gap: var(--gap-13xl);
  text-align: center;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    padding-top: var(--padding-2xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;

const Column2 = () => {
  return (
    <ColumnRoot>
      <HeadingWrapper>
        <Heading1>
          <Heading>Basic plan</Heading>
          <Subheading>Lorem ipsum dolor sit amet</Subheading>
        </Heading1>
      </HeadingWrapper>
      <Divider />
      <Check prop="$19" text="or $199 yearly" />
      <Button1>
        <Button>Get started</Button>
      </Button1>
      <Divider />
      <List>
        <ListItem>
          <Check1 type="checkbox" />
          <ListItemText>Feature text goes here</ListItemText>
        </ListItem>
        <ListItem>
          <Check1 type="checkbox" />
          <ListItemText>Feature text goes here</ListItemText>
        </ListItem>
        <ListItem>
          <Check1 type="checkbox" />
          <ListItemText>Feature text goes here</ListItemText>
        </ListItem>
      </List>
    </ColumnRoot>
  );
};

export default Column2;
