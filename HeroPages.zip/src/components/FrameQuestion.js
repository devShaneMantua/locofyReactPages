import styled from "styled-components";

const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Question = styled.b`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  min-width: 153px;
  max-width: 100%;
`;
const Icon = styled.img`
  height: 32px;
  width: 32px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const ContentFrameQuestionOption = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
  flex-wrap: ${(p) => p.propFlexWrap};
`;
const ContentFrameQuestionOption1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
  flex-wrap: ${(p) => p.propFlexWrap1};
`;
const ContentFrameQuestionOption2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
  flex-wrap: ${(p) => p.propFlexWrap2};
`;
const ContentFrameQuestionOption3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
  flex-wrap: ${(p) => p.propFlexWrap3};
`;
const ContentFrameQuestionOption4 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
  flex-wrap: ${(p) => p.propFlexWrap4};
`;
const FrameQuestionRoot = styled.div`width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  width: ${(p) => p.propWidth}
  flex: ${(p) => p.propFlex}
  min-width: ${(p) => p.propMinWidth}
`;

const FrameQuestion = ({
  propWidth,
  propFlex,
  propMinWidth,
  propFlexWrap,
  propFlexWrap1,
  propFlexWrap2,
  propFlexWrap3,
  propFlexWrap4,
}) => {
  return (
    <FrameQuestionRoot
      propWidth={propWidth}
      propFlex={propFlex}
      propMinWidth={propMinWidth}
    >
      <Divider />
      <ContentFrameQuestionOption propFlexWrap={propFlexWrap}>
        <Question>Question text goes here</Question>
        <Icon loading="eager" alt="" src="/icon-3.svg" />
      </ContentFrameQuestionOption>
      <Divider />
      <ContentFrameQuestionOption1 propFlexWrap1={propFlexWrap1}>
        <Question>Question text goes here</Question>
        <Icon loading="eager" alt="" src="/icon-3.svg" />
      </ContentFrameQuestionOption1>
      <Divider />
      <ContentFrameQuestionOption2 propFlexWrap2={propFlexWrap2}>
        <Question>Question text goes here</Question>
        <Icon loading="eager" alt="" src="/icon-3.svg" />
      </ContentFrameQuestionOption2>
      <Divider />
      <ContentFrameQuestionOption3 propFlexWrap3={propFlexWrap3}>
        <Question>Question text goes here</Question>
        <Icon loading="eager" alt="" src="/icon-3.svg" />
      </ContentFrameQuestionOption3>
      <Divider />
      <ContentFrameQuestionOption4 propFlexWrap4={propFlexWrap4}>
        <Question>Question text goes here</Question>
        <Icon loading="eager" alt="" src="/icon-3.svg" />
      </ContentFrameQuestionOption4>
      <Divider />
    </FrameQuestionRoot>
  );
};

export default FrameQuestion;
