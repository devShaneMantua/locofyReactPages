import styled from "styled-components";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const ButtonText = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Placeholder = styled.input`
  width: 100%;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  flex: 1;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
  min-width: 200px;
  max-width: 100%;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-smi) var(--padding-xs)
    var(--padding-2xs);
  min-width: 232px;
  max-width: 100%;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xl);
  background-color: var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const ByClickingSign = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Actions = styled.div`
  width: 513px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--text-tiny-normal-size);
`;
const Content1 = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const RelumeBlack = styled.img`
  align-self: stretch;
  width: 140px;
  position: relative;
  max-height: 100%;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 56px;
`;
const Logos = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-29xl);
  @media screen and (max-width: 1200px) {
    flex-wrap: wrap;
    justify-content: center;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-29xl);
  }
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-normal-size);
`;
const CtaRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-29xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-29xl);
    padding: var(--padding-54xl) var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const CTA = () => {
  return (
    <CtaRoot>
      <Content1>
        <Content>
          <Heading>
            Call to action that invites visitor to try the product for free
          </Heading>
          <ButtonText>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique.
          </ButtonText>
        </Content>
        <Actions>
          <Form>
            <TextInput>
              <Placeholder placeholder="Enter your email" type="text" />
            </TextInput>
            <Button1>
              <Button>Try it for free</Button>
            </Button1>
          </Form>
          <ByClickingSign>
            By clicking Sign Up you're confirming that you agree with our Terms
            and Conditions.
          </ByClickingSign>
        </Actions>
      </Content1>
      <Content2>
        <ByClickingSign>
          Trusted by the world's best companies [social proof to build
          credibility]
        </ByClickingSign>
        <Logos>
          <WebflowBlack loading="eager" alt="" src="/webflow--black.svg" />
          <RelumeBlack loading="eager" alt="" src="/relume--black.svg" />
          <WebflowBlack loading="eager" alt="" src="/webflow--black.svg" />
          <RelumeBlack loading="eager" alt="" src="/relume--black.svg" />
          <WebflowBlack loading="eager" alt="" src="/webflow--black.svg" />
          <RelumeBlack loading="eager" alt="" src="/relume--black.svg" />
        </Logos>
      </Content2>
    </CtaRoot>
  );
};

export default CTA;
