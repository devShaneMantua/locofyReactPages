import styled from "styled-components";

const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const RelumeBlack = styled.img`
  align-self: stretch;
  width: 140px;
  position: relative;
  max-height: 100%;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 56px;
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-29xl);
  @media screen and (max-width: 1200px) {
    flex-wrap: wrap;
    justify-content: center;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-29xl);
  }
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
const LogoRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  gap: var(--gap-5xl);
  text-align: center;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const Logo1 = () => {
  return (
    <LogoRoot>
      <Heading>
        Trusted by the world's best companies [social proof to build
        credibility]
      </Heading>
      <Content>
        <Row>
          <WebflowBlack loading="eager" alt="" src="/webflow--black.svg" />
          <RelumeBlack loading="eager" alt="" src="/relume--black.svg" />
          <WebflowBlack loading="eager" alt="" src="/webflow--black.svg" />
          <RelumeBlack loading="eager" alt="" src="/relume--black.svg" />
          <WebflowBlack loading="eager" alt="" src="/webflow--black.svg" />
          <RelumeBlack loading="eager" alt="" src="/relume--black.svg" />
        </Row>
      </Content>
    </LogoRoot>
  );
};

export default Logo1;
