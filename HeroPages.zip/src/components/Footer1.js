import styled from "styled-components";

const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Placeholder = styled.input`
  width: 100%;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  flex: 1;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
  min-width: 145px;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-smi) var(--padding-xs)
    var(--padding-2xs);
  min-width: 172px;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-4xl);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const BySubscribingYouContainer = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Actions = styled.div`
  width: 400px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--text-tiny-normal-size);
`;
const Newsletter = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 1200px) {
    flex-wrap: wrap;
  }
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Link = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 176px;
  max-width: 180px;
`;
const Links = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-21xl);
  }
`;
const LogoIcon = styled.img`
  height: 27px;
  width: 63px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Text2 = styled.div`
  position: relative;
  line-height: 150%;
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--gap-xl);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Column1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
  }
`;
const FooterRoot = styled.footer`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  z-index: 1;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1050px) {
    padding-top: var(--padding-33xl);
    padding-bottom: var(--padding-33xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-21xl);
    padding-right: var(--padding-21xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
    padding-top: var(--padding-15xl);
    padding-bottom: var(--padding-15xl);
    box-sizing: border-box;
  }
`;

const Footer1 = () => {
  return (
    <FooterRoot>
      <Newsletter>
        <Content>
          <Heading>Join our newsletter</Heading>
          <Text1>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          </Text1>
        </Content>
        <Actions>
          <Form>
            <TextInput>
              <Placeholder placeholder="Enter your email" type="text" />
            </TextInput>
            <Button1>
              <Button>Subscribe</Button>
            </Button1>
          </Form>
          <BySubscribingYouContainer>
            {`By subscribing you agree to with our `}
            <PrivacyPolicy>Privacy Policy</PrivacyPolicy>
          </BySubscribingYouContainer>
        </Actions>
      </Newsletter>
      <Divider />
      <Links>
        <Column>
          <Heading>Column One</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link One</Link>
            </Link1>
            <Link1>
              <Link>Link Two</Link>
            </Link1>
            <Link1>
              <Link>Link Three</Link>
            </Link1>
            <Link1>
              <Link>Link Four</Link>
            </Link1>
            <Link1>
              <Link>Link Five</Link>
            </Link1>
          </FooterLinks>
        </Column>
        <Column>
          <Heading>Column Two</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Six</Link>
            </Link1>
            <Link1>
              <Link>Link Seven</Link>
            </Link1>
            <Link1>
              <Link>Link Eight</Link>
            </Link1>
            <Link1>
              <Link>Link Nine</Link>
            </Link1>
            <Link1>
              <Link>Link Ten</Link>
            </Link1>
          </FooterLinks>
        </Column>
        <Column>
          <Heading>Column Three</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Eleven</Link>
            </Link1>
            <Link1>
              <Link>Link Twelve</Link>
            </Link1>
            <Link1>
              <Link>Link Thirteen</Link>
            </Link1>
            <Link1>
              <Link>Link Fourteen</Link>
            </Link1>
            <Link1>
              <Link>Link Fifteen</Link>
            </Link1>
          </FooterLinks>
        </Column>
        <Column>
          <Heading>Column Four</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Sixteen</Link>
            </Link1>
            <Link1>
              <Link>Link Seventeen</Link>
            </Link1>
            <Link1>
              <Link>Link Eightteen</Link>
            </Link1>
            <Link1>
              <Link>Link Nineteen</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty</Link>
            </Link1>
          </FooterLinks>
        </Column>
        <Column>
          <Heading>Column Five</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Twenty One</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty Two</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty Three</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty Four</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty Five</Link>
            </Link1>
          </FooterLinks>
        </Column>
        <Column>
          <Heading>Column Six</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Twenty Six</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty Seven</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty Eight</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty Nine</Link>
            </Link1>
            <Link1>
              <Link>Link Thirty</Link>
            </Link1>
          </FooterLinks>
        </Column>
      </Links>
      <Column1>
        <Divider />
        <Row>
          <LogoIcon loading="eager" alt="" src="/logo.svg" />
          <Text2>© 2023 Relume. All rights reserved.</Text2>
        </Row>
      </Column1>
    </FooterRoot>
  );
};

export default Footer1;
