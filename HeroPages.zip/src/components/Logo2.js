import styled from "styled-components";

const Heading = styled.b`
  width: 610px;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
  padding-left: var(--padding-xl);
  padding-right: var(--padding-xl);
`;
const TwitterIcon = styled.img`
  position: absolute;
  top: calc(50% - 14.2px);
  left: calc(50% - 57px);
  width: 114px;
  height: 28.7px;
`;
const WebflowBlack = styled.div`
  height: 48px;
  width: 200px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const RelumeBlack = styled.img`
  align-self: stretch;
  width: 200px;
  position: relative;
  max-height: 100%;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 56px;
`;
const WebflowBlack1 = styled.img`
  height: 48px;
  width: 200px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const IconFacebook = styled.div`
  width: 1460px;
  overflow-x: auto;
  flex-shrink: 0;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: 0px var(--padding-xl) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Link = styled.div`
  width: 1492px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px 0px 0px;
  box-sizing: border-box;
  max-width: 104%;
  flex-shrink: 0;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px 0px 0px 0px;
  box-sizing: border-box;
  max-width: 100%;
`;
const LogoRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) 0px;
  box-sizing: border-box;
  gap: var(--gap-29xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-29xl);
  }
`;

const Logo2 = () => {
  return (
    <LogoRoot>
      <Heading>
        Trusted by the world's best companies [social proof to build
        credibility]
      </Heading>
      <FooterLinks>
        <Link>
          <IconFacebook>
            <WebflowBlack>
              <TwitterIcon loading="eager" alt="" src="/vector.svg" />
            </WebflowBlack>
            <RelumeBlack loading="eager" alt="" src="/relume--black1.svg" />
            <WebflowBlack1 loading="eager" alt="" src="/webflow--black1.svg" />
            <RelumeBlack loading="eager" alt="" src="/relume--black1.svg" />
            <WebflowBlack1 loading="eager" alt="" src="/webflow--black1.svg" />
            <RelumeBlack loading="eager" alt="" src="/relume--black1.svg" />
            <WebflowBlack1 loading="eager" alt="" src="/webflow--black1.svg" />
          </IconFacebook>
        </Link>
      </FooterLinks>
    </LogoRoot>
  );
};

export default Logo2;
