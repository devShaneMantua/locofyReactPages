import Content from "./Content";
import styled from "styled-components";
import BlogList from "./BlogList";

const BlogCategories = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  font-weight: 600;
`;
const CategoryOne = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Menu = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Menu1 = styled.div`
  width: 200px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Blog = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 702px;
  max-width: 100%;
  @media screen and (max-width: 1050px) {
    flex-wrap: wrap;
    min-width: 100%;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
  }
`;
const MegaMenu = styled.div`
  align-self: stretch;
  background-color: var(--white);
  box-shadow: 0px -1px 0px #000 inset;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-xl);
    padding-bottom: var(--padding-xl);
    box-sizing: border-box;
  }
`;
const NavbarRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Navbar = () => {
  return (
    <NavbarRoot>
      <Content button="Log in" button1="Start free trial" />
      <MegaMenu>
        <Menu1>
          <Menu>
            <BlogCategories>Blog categories</BlogCategories>
            <CategoryOne>Category One</CategoryOne>
            <CategoryOne>Category Two</CategoryOne>
            <CategoryOne>Category Three</CategoryOne>
            <CategoryOne>Category Four</CategoryOne>
            <CategoryOne>Category Five</CategoryOne>
          </Menu>
        </Menu1>
        <Blog>
          <BlogList />
          <BlogList />
        </Blog>
      </MegaMenu>
    </NavbarRoot>
  );
};

export default Navbar;
