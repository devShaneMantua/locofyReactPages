import styled from "styled-components";

const HighlightTheKey = styled.p`
  margin: 0;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 750px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const ButtonComponent = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const InputField = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const HeadingText = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Border = styled.div`
  height: 124px;
  width: 2px;
  position: relative;
  border-right: 2px solid var(--black);
  box-sizing: border-box;
  @media screen and (max-width: 750px) {
    width: 100%;
    height: 2px;
  }
`;
const Heading1 = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const LabeledText = styled.div`
  align-self: stretch;
  height: 72px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const ColumnLayout = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 380px;
  max-width: 100%;
  flex-shrink: 0;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const TabHorizontal = styled.div`
  align-self: stretch;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
    gap: var(--gap-13xl);
  }
`;
const Border1 = styled.div`
  height: 124px;
  width: 2px;
  position: relative;
  border-right: 2px solid var(--black);
  box-sizing: border-box;
  opacity: 0;
  @media screen and (max-width: 750px) {
    width: 100%;
    height: 2px;
  }
`;
const TabsMenu = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  box-sizing: border-box;
  gap: var(--gap-21xl);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-21xl);
    min-width: 100%;
  }
`;
const PlaceholderImage = styled.img`
  height: 640px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 400px;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const FrameCard = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  font-size: var(--heading-h5-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1225px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Layout1 = () => {
  return (
    <LayoutRoot>
      <HeadingText>
        <InputField>
          <Heading>
            <HighlightTheKey>Highlight the key benefits of</HighlightTheKey>
            <HighlightTheKey>using your product or service</HighlightTheKey>
          </Heading>
          <ButtonComponent>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</ButtonComponent>
        </InputField>
      </HeadingText>
      <FrameCard>
        <TabsMenu>
          <TabHorizontal>
            <Border />
            <ColumnLayout>
              <Heading1>Highlight benefit one</Heading1>
              <LabeledText>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla.
              </LabeledText>
            </ColumnLayout>
          </TabHorizontal>
          <TabHorizontal>
            <Border1 />
            <ColumnLayout>
              <Heading1>Highlight benefit two</Heading1>
              <LabeledText>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla.
              </LabeledText>
            </ColumnLayout>
          </TabHorizontal>
          <TabHorizontal>
            <Border1 />
            <ColumnLayout>
              <Heading1>Highlight benefit three</Heading1>
              <LabeledText>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla.
              </LabeledText>
            </ColumnLayout>
          </TabHorizontal>
        </TabsMenu>
        <PlaceholderImage alt="" src="/placeholder--image-7@2x.png" />
      </FrameCard>
    </LayoutRoot>
  );
};

export default Layout1;
