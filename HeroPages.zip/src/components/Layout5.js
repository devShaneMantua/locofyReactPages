import styled from "styled-components";
import Column5 from "./Column5";

const Heading = styled.h1`
  margin: 0;
  width: 768px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  max-width: 100%;
  @media screen and (max-width: 1050px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-29xl);
  max-width: 100%;
  font-size: var(--heading-h5-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-29xl);
  }
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h3-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
    padding: var(--padding-54xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Layout5 = () => {
  return (
    <LayoutRoot>
      <Heading>How it works</Heading>
      <Row>
        <Column5 heading="Short summary of step one" />
        <Column5
          heading="Short summary of step two"
          propTextAlign="center"
          propTextAlign1="center"
        />
        <Column5
          heading="Short summary of step three"
          propTextAlign="center"
          propTextAlign1="center"
        />
      </Row>
    </LayoutRoot>
  );
};

export default Layout5;
