import styled from "styled-components";

const HeadingFrameIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.b`
  align-self: stretch;
  height: 112px;
  position: relative;
  line-height: 140%;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 22px;
  }
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const Text1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Text2 = styled.div`
  position: relative;
  line-height: 150%;
`;
const TextParent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider = styled.div`
  height: 62px;
  width: 1px;
  position: relative;
  border-right: 1px solid var(--black);
  box-sizing: border-box;
  @media screen and (max-width: 750px) {
    width: 100%;
    height: 1px;
  }
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const FrameContainer = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xl);
  max-width: 100%;
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const HeaderGroupRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 395px;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
    min-width: 100%;
  }
`;

const HeaderGroup = () => {
  return (
    <HeaderGroupRoot>
      <Stars>
        <HeadingFrameIcon loading="eager" alt="" src="/placeholder-image.svg" />
        <HeadingFrameIcon loading="eager" alt="" src="/placeholder-image.svg" />
        <HeadingFrameIcon loading="eager" alt="" src="/placeholder-image.svg" />
        <HeadingFrameIcon alt="" src="/placeholder-image.svg" />
        <HeadingFrameIcon alt="" src="/placeholder-image.svg" />
      </Stars>
      <Quote>
        "A customer testimonial that highlights features and answers potential
        customer doubts about your product or service. Showcase testimonials
        from a similar demographic to your customers."
      </Quote>
      <FrameContainer>
        <AvatarImageIcon loading="eager" alt="" src="/avatar-image2@2x.png" />
        <TextParent>
          <Text1>Name Surname</Text1>
          <Text2>Position, Company name</Text2>
        </TextParent>
        <Divider />
        <WebflowBlack loading="eager" alt="" src="/webflow--black2.svg" />
      </FrameContainer>
    </HeaderGroupRoot>
  );
};

export default HeaderGroup;
