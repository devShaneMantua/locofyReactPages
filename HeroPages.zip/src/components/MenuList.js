import styled from "styled-components";

const PageGroupOne = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  font-weight: 600;
`;
const Icon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const PageOne = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const LoremIpsumDolor = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 208px;
`;
const MenuItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const MenuListRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 231px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const MenuList = ({ pageGroupOne, pageOne, pageTwo, pageThree, pageFour }) => {
  return (
    <MenuListRoot>
      <PageGroupOne>{pageGroupOne}</PageGroupOne>
      <MenuItem>
        <Icon loading="eager" alt="" src="/icon.svg" />
        <Content>
          <PageOne>{pageOne}</PageOne>
          <LoremIpsumDolor>
            Lorem ipsum dolor sit amet consectetur elit
          </LoremIpsumDolor>
        </Content>
      </MenuItem>
      <MenuItem>
        <Icon loading="eager" alt="" src="/icon.svg" />
        <Content>
          <PageOne>{pageTwo}</PageOne>
          <LoremIpsumDolor>
            Lorem ipsum dolor sit amet consectetur elit
          </LoremIpsumDolor>
        </Content>
      </MenuItem>
      <MenuItem>
        <Icon loading="eager" alt="" src="/icon.svg" />
        <Content>
          <PageOne>{pageThree}</PageOne>
          <LoremIpsumDolor>
            Lorem ipsum dolor sit amet consectetur elit
          </LoremIpsumDolor>
        </Content>
      </MenuItem>
      <MenuItem>
        <Icon loading="eager" alt="" src="/icon.svg" />
        <Content>
          <PageOne>{pageFour}</PageOne>
          <LoremIpsumDolor>
            Lorem ipsum dolor sit amet consectetur elit
          </LoremIpsumDolor>
        </Content>
      </MenuItem>
    </MenuListRoot>
  );
};

export default MenuList;
