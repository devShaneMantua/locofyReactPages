import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 176px;
  max-width: 180px;
`;
const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column1 = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 176px;
  max-width: 180px;
`;
const Links = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-21xl);
  }
`;
const FooterLinksContainerRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-29xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const FooterLinksContainer = () => {
  return (
    <FooterLinksContainerRoot>
      <Links>
        <Column>
          <LogoIcon loading="eager" alt="" src="/logo.svg" />
        </Column>
        <Column1>
          <Heading>Column One</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link One</Link>
            </Link1>
            <Link1>
              <Link>Link Two</Link>
            </Link1>
            <Link1>
              <Link>Link Three</Link>
            </Link1>
            <Link1>
              <Link>Link Four</Link>
            </Link1>
            <Link1>
              <Link>Link Five</Link>
            </Link1>
          </FooterLinks>
        </Column1>
        <Column1>
          <Heading>Column Two</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Six</Link>
            </Link1>
            <Link1>
              <Link>Link Seven</Link>
            </Link1>
            <Link1>
              <Link>Link Eight</Link>
            </Link1>
            <Link1>
              <Link>Link Nine</Link>
            </Link1>
            <Link1>
              <Link>Link Ten</Link>
            </Link1>
          </FooterLinks>
        </Column1>
        <Column1>
          <Heading>Column Three</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Eleven</Link>
            </Link1>
            <Link1>
              <Link>Link Twelve</Link>
            </Link1>
            <Link1>
              <Link>Link Thirteen</Link>
            </Link1>
            <Link1>
              <Link>Link Fourteen</Link>
            </Link1>
            <Link1>
              <Link>Link Fifteen</Link>
            </Link1>
          </FooterLinks>
        </Column1>
        <Column1>
          <Heading>Column Four</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Sixteen</Link>
            </Link1>
            <Link1>
              <Link>Link Seventeen</Link>
            </Link1>
            <Link1>
              <Link>Link Eightteen</Link>
            </Link1>
            <Link1>
              <Link>Link Nineteen</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty</Link>
            </Link1>
          </FooterLinks>
        </Column1>
        <Column1>
          <Heading>Column Five</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Twenty One</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty Two</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty Three</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty Four</Link>
            </Link1>
            <Link1>
              <Link>Link Twenty Five</Link>
            </Link1>
          </FooterLinks>
        </Column1>
      </Links>
    </FooterLinksContainerRoot>
  );
};

export default FooterLinksContainer;
