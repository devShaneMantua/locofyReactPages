import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 105px;
  width: 160px;
  position: relative;
  object-fit: cover;
  @media screen and (max-width: 750px) {
    flex: 1;
  }
`;
const ArticleTitle = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const LoremIpsumDolor = styled.div`
  align-self: stretch;
  height: 42px;
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  display: inline-block;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const ReadMore = styled.div`
  position: relative;
  font-size: var(--text-small-link-size);
  text-decoration: underline;
  line-height: 150%;
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  min-width: 221px;
  max-width: 100%;
`;
const BlogItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  box-sizing: border-box;
  gap: var(--gap-5xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const BlogListRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  min-width: 341px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;

const BlogList = () => {
  return (
    <BlogListRoot>
      <BlogItem>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image@2x.png"
        />
        <Content1>
          <Content>
            <ArticleTitle>Article Title</ArticleTitle>
            <LoremIpsumDolor>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit
            </LoremIpsumDolor>
          </Content>
          <ReadMore>Read more</ReadMore>
        </Content1>
      </BlogItem>
      <BlogItem>
        <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
        <Content1>
          <Content>
            <ArticleTitle>Article Title</ArticleTitle>
            <LoremIpsumDolor>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit
            </LoremIpsumDolor>
          </Content>
          <ReadMore>Read more</ReadMore>
        </Content1>
      </BlogItem>
      <BlogItem>
        <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
        <Content1>
          <Content>
            <ArticleTitle>Article Title</ArticleTitle>
            <LoremIpsumDolor>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit
            </LoremIpsumDolor>
          </Content>
          <ReadMore>Read more</ReadMore>
        </Content1>
      </BlogItem>
    </BlogListRoot>
  );
};

export default BlogList;
