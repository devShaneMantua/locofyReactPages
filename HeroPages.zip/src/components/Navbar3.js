import styled from "styled-components";

const LogoIcon = styled.img`
  height: 27px;
  width: 63px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Link = styled.div`
  position: relative;
  line-height: 150%;
  white-space: nowrap;
`;
const ChevronDownIcon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const NavLinkDropdown = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-9xs);
`;
const Column1 = styled.div`
  width: 390px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-mid);
  background-color: var(--black);
  width: 120px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
  width: ${(p) => p.buttonWidth};
`;
const Column2 = styled.div`
  flex: 1;
  background-color: var(--white);
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: center;
  max-width: 100%;
  overflow: ${(p) => p.buttonOverflow};
`;
const Container = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
  }
  overflow: ${(p) => p.columnOverflow};
`;
const NavbarRoot = styled.header`
  align-self: stretch;
  height: 72px;
  background-color: var(--white);
  box-shadow: 0px -1px 0px #000 inset;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0px var(--padding-45xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const Navbar3 = ({ button, columnOverflow, buttonOverflow, buttonWidth }) => {
  return (
    <NavbarRoot>
      <Container columnOverflow={columnOverflow}>
        <Column>
          <LogoIcon loading="eager" alt="" src="/logo.svg" />
        </Column>
        <Column1>
          <Link>Link One</Link>
          <Link>Link Two</Link>
          <Link>Link Three</Link>
          <NavLinkDropdown>
            <Link>Link Four</Link>
            <ChevronDownIcon alt="" src="/chevron-down.svg" />
          </NavLinkDropdown>
        </Column1>
        <Column2 buttonOverflow={buttonOverflow}>
          <Button1 buttonWidth={buttonWidth}>
            <Button>{button}</Button>
          </Button1>
        </Column2>
      </Container>
    </NavbarRoot>
  );
};

export default Navbar3;
