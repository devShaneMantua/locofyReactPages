import styled from "styled-components";
import HeaderGroup from "./HeaderGroup";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const ContentFrameQuestion = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const QuestionTextRowsQuestionTe = styled.div`
  width: 560px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  flex-shrink: 0;
`;
const FooterFrameLogoandNewslette = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  flex-shrink: 0;
  font-size: var(--heading-h6-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-45xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;
const TestimonialRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-77xl) var(--padding-93xl)
    var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
    padding: var(--padding-54xl) var(--padding-29xl) var(--padding-54xl)
      var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
    padding-right: var(--padding-xl);
    box-sizing: border-box;
  }
`;

const Testimonial6 = () => {
  return (
    <TestimonialRoot>
      <QuestionTextRowsQuestionTe>
        <Heading>Customer testimonials</Heading>
        <ContentFrameQuestion>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        </ContentFrameQuestion>
      </QuestionTextRowsQuestionTe>
      <FooterFrameLogoandNewslette>
        <HeaderGroup />
        <HeaderGroup />
      </FooterFrameLogoandNewslette>
    </TestimonialRoot>
  );
};

export default Testimonial6;
