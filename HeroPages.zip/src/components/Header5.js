import styled from "styled-components";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 134px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-26xl);
    line-height: 54px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const PrivacyPolicyLink = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xl);
  background-color: var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Actions = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
`;
const Column1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 400px;
  max-width: 100%;
  font-size: var(--text-medium-normal-size);
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const Content = styled.div`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const HeaderRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h1-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1200px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Header5 = () => {
  return (
    <HeaderRoot>
      <Content>
        <Column>
          <Heading>Headline that highlights the Value Proposition</Heading>
        </Column>
        <Column1>
          <PrivacyPolicyLink>
            Describe exactly what your product or service does and how it makes
            your customer's lives better. Avoid using verbose words or phrases.
          </PrivacyPolicyLink>
          <Actions>
            <Button1>
              <Button>Book a demo</Button>
            </Button1>
          </Actions>
        </Column1>
      </Content>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image-6@2x.png"
      />
    </HeaderRoot>
  );
};

export default Header5;
