import styled from "styled-components";
import BlogRowCard from "./BlogRowCard";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Horizontalseparator = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Textcontentquestion = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Questiongroupframe = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Question = styled.b`
  width: 500px;
  position: relative;
  line-height: 150%;
  display: inline-block;
  flex-shrink: 0;
  max-width: 100%;
`;
const Linkcolumn = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  min-width: 486px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const Textcontentquestion1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-45xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  font-size: var(--text-medium-normal-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-29xl);
  }
`;
const FaqRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1200px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const FAQ4 = () => {
  return (
    <FaqRoot>
      <Questiongroupframe>
        <Textcontentquestion>
          <Heading>Frequently asked questions</Heading>
          <Horizontalseparator>
            Frequently asked questions ordered by popularity. Remember that if
            the visitor has not committed to the call to action, they may still
            have questions (doubts) that can be answered.
          </Horizontalseparator>
        </Textcontentquestion>
      </Questiongroupframe>
      <Content>
        <Row>
          <Divider />
          <Textcontentquestion1>
            <Question>Question text goes here</Question>
            <Linkcolumn>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique. Duis cursus,
              mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam
              libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum
              lorem imperdiet. Nunc ut sem vitae risus tristique posuere.
            </Linkcolumn>
          </Textcontentquestion1>
        </Row>
        <Row>
          <Divider />
          <Textcontentquestion1>
            <Question>Question text goes here</Question>
            <Linkcolumn>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique. Duis cursus,
              mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam
              libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum
              lorem imperdiet. Nunc ut sem vitae risus tristique posuere.
            </Linkcolumn>
          </Textcontentquestion1>
        </Row>
        <Row>
          <Divider />
          <Textcontentquestion1>
            <Question>Question text goes here</Question>
            <Linkcolumn>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique. Duis cursus,
              mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam
              libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum
              lorem imperdiet. Nunc ut sem vitae risus tristique posuere.
            </Linkcolumn>
          </Textcontentquestion1>
        </Row>
        <Row>
          <Divider />
          <Textcontentquestion1>
            <Question>Question text goes here</Question>
            <Linkcolumn>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique. Duis cursus,
              mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam
              libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum
              lorem imperdiet. Nunc ut sem vitae risus tristique posuere.
            </Linkcolumn>
          </Textcontentquestion1>
        </Row>
      </Content>
      <Questiongroupframe>
        <BlogRowCard
          button="Contact us"
          propTextAlign="left"
          propTextAlign1="left"
          propPadding="var(--padding-xs) var(--padding-lgi) var(--padding-xs) var(--padding-4xl)"
        />
      </Questiongroupframe>
    </FaqRoot>
  );
};

export default FAQ4;
