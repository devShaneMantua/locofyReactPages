import styled from "styled-components";

const IconRelume = styled.input`
  margin: 0;
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Divider = styled.div`
  width: 50px;
  flex: 1;
  position: relative;
  border-right: 2px solid var(--black);
  box-sizing: border-box;
`;
const Divider1 = styled.div`
  height: 164px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 22px;
  }
`;
const FrameText = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const FrameHeading = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-3xs);
  min-width: 343px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const LogoRowRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
    gap: var(--gap-21xl);
  }
`;

const LogoRow = ({ heading }) => {
  return (
    <LogoRowRoot>
      <Divider1>
        <IconRelume type="checkbox" />
        <Divider />
      </Divider1>
      <FrameHeading>
        <Heading>{heading}</Heading>
        <FrameText>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique.
        </FrameText>
      </FrameHeading>
    </LogoRowRoot>
  );
};

export default LogoRow;
