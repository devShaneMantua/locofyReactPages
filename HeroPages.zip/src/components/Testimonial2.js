import styled from "styled-components";
import IconFacebook from "./IconFacebook";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const LoremIpsumDolor = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Newsletter = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  flex-shrink: 0;
`;
const RowContainerIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const CustomerName = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const PositionCompanyName = styled.div`
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Column = styled.div`
  width: 416px;
  border: 1px solid var(--black);
  box-sizing: border-box;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-12xl);
  gap: var(--gap-13xl);
  min-width: 270px;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;
const SocialIcons = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-12xs) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-12xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-12xl);
  }
`;
const Dot = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--black);
`;
const Dot1 = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--neutral-gray);
`;
const SliderDots = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const CreditsText = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-18xl);
  max-width: 100%;
  flex-shrink: 0;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-18xl);
  }
`;
const TestimonialRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-17xl) var(--padding-93xl)
    var(--padding-18xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1050px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Testimonial2 = () => {
  return (
    <TestimonialRoot>
      <Newsletter>
        <Heading>Customer testimonials</Heading>
        <LoremIpsumDolor>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        </LoremIpsumDolor>
      </Newsletter>
      <CreditsText>
        <SocialIcons>
          <IconFacebook icon="/icon.svg" />
          <Column>
            <Stars>
              <RowContainerIcon alt="" src="/placeholder-image.svg" />
              <RowContainerIcon alt="" src="/placeholder-image.svg" />
              <RowContainerIcon alt="" src="/placeholder-image.svg" />
              <RowContainerIcon alt="" src="/placeholder-image.svg" />
              <RowContainerIcon alt="" src="/placeholder-image.svg" />
            </Stars>
            <Quote>
              "A customer testimonial that highlights features and answers
              potential customer doubts about your product or service. Showcase
              testimonials from a similar demographic to your customers."
            </Quote>
            <Avatar>
              <AvatarImageIcon
                loading="eager"
                alt=""
                src="/avatar-image@2x.png"
              />
              <AvatarContent>
                <CustomerName>Customer Name</CustomerName>
                <PositionCompanyName>
                  Position, Company name
                </PositionCompanyName>
              </AvatarContent>
            </Avatar>
          </Column>
          <IconFacebook icon="/icon-1.svg" propLeft="0px" propLeft1="388px" />
        </SocialIcons>
        <SliderDots>
          <Dot />
          <Dot1 />
          <Dot1 />
          <Dot1 />
          <Dot1 />
        </SliderDots>
      </CreditsText>
    </TestimonialRoot>
  );
};

export default Testimonial2;
