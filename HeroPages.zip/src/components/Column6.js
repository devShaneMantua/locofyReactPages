import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 240px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const ContentColumn = styled.div`
  align-self: stretch;
  height: 96px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
`;
const ColumnRoot = styled.div`
  width: 405.3px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;

const Column6 = ({ placeholderImage, heading }) => {
  return (
    <ColumnRoot>
      <PlaceholderImage loading="eager" alt="" src={placeholderImage} />
      <Content1>
        <Content>
          <Heading>{heading}</Heading>
          <ContentColumn>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla.
          </ContentColumn>
        </Content>
      </Content1>
    </ColumnRoot>
  );
};

export default Column6;
