import Content from "./Content";
import MenuItem from "./MenuItem";
import styled from "styled-components";

const MenuList = styled.div`
  width: 1344px;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
  }
`;
const Menu = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-end;
  padding: var(--padding-13xl) var(--padding-13xl) var(--padding-13xl)
    var(--padding-45xl);
  box-sizing: border-box;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
    padding-left: var(--padding-13xl);
    box-sizing: border-box;
  }
`;
const LookingForA = styled.div`
  position: relative;
  line-height: 150%;
`;
const GetInTouch = styled.input`
  width: 86px;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const Content1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Content2 = styled.div`
  align-self: stretch;
  background-color: var(--light-grey);
  box-shadow: 0px -1px 0px #000 inset;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  padding: var(--padding-base) var(--padding-45xl);
  gap: var(--gap-base);
  @media screen and (max-width: 450px) {
    padding-left: var(--padding-xl);
    padding-right: var(--padding-xl);
    box-sizing: border-box;
  }
`;
const MegaMenu = styled.div`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const NavbarRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Navbar5 = () => {
  return (
    <NavbarRoot>
      <Content
        button="Call us 1800 123 456"
        button1="Book a consultation"
        buttonWidth="unset"
        buttonWidth1="unset"
        buttonWidth2="unset"
        buttonDisplay="inline-block"
        propFlex="unset"
      />
      <MegaMenu>
        <Menu>
          <MenuList>
            <MenuItem pageOne="Page One" />
            <MenuItem pageOne="Page Two" />
            <MenuItem pageOne="Page Three" />
            <MenuItem pageOne="Page Four" />
          </MenuList>
        </Menu>
        <Content2>
          <Content1>
            <LookingForA>Looking for a new career?</LookingForA>
            <GetInTouch placeholder="Get in touch" type="text" />
          </Content1>
        </Content2>
      </MegaMenu>
    </NavbarRoot>
  );
};

export default Navbar5;
