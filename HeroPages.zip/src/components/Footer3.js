import Content1 from "./Content1";
import styled from "styled-components";

const ContentWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-29xl);
  box-sizing: border-box;
  max-width: 100%;
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const HeaderFooterRow = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const Link1 = styled.div`
  flex: 1;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
  min-width: 68px;
`;
const ColumnWithLinks = styled.div`
  width: 345px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const FooterRoot = styled.footer`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
    padding: var(--padding-33xl) var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const Footer3 = () => {
  return (
    <FooterRoot>
      <ContentWrapper>
        <Content1 />
      </ContentWrapper>
      <Divider />
      <Row>
        <HeaderFooterRow>© 2023 Relume. All rights reserved.</HeaderFooterRow>
        <ColumnWithLinks>
          <Link>Privacy Policy</Link>
          <Link1>Terms of Service</Link1>
          <Link1>Cookies Settings</Link1>
        </ColumnWithLinks>
      </Row>
    </FooterRoot>
  );
};

export default Footer3;
