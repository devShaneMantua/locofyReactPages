import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const WelcomeTo = styled.p`
  margin: 0;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 134px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-26xl);
    line-height: 54px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const CardPlaceholderImage = styled.div`
  align-self: stretch;
  height: 81px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xl);
  background-color: var(--black);
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Button2 = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Button3 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xl);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Actions = styled.div`
  width: 262px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-base);
`;
const Column1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 400px;
  max-width: 100%;
  font-size: var(--text-medium-normal-size);
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const Content = styled.div`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 1200px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
  }
`;
const HeaderRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h1-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Header6 = () => {
  return (
    <HeaderRoot>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image2@2x.png"
      />
      <Content>
        <Column>
          <Heading>
            <WelcomeTo>Welcome to</WelcomeTo>
            <WelcomeTo>[restuarant name]</WelcomeTo>
          </Heading>
        </Column>
        <Column1>
          <CardPlaceholderImage>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla, ut commodo diam libero
            vitae erat.
          </CardPlaceholderImage>
          <Actions>
            <Button1>
              <Button>Book now</Button>
            </Button1>
            <Button3>
              <Button2>View menu</Button2>
            </Button3>
          </Actions>
        </Column1>
      </Content>
    </HeaderRoot>
  );
};

export default Header6;
