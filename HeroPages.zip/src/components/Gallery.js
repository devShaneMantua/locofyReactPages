import styled from "styled-components";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const InfoFrame = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 416px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 312px;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;
const PlaceholderImage1 = styled.img`
  align-self: stretch;
  height: 234px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
  }
`;
const GalleryRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1200px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Gallery = () => {
  return (
    <GalleryRoot>
      <SectionTitle>
        <Heading>Our food [gallery]</Heading>
        <InfoFrame>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        </InfoFrame>
      </SectionTitle>
      <Content>
        <Column>
          <PlaceholderImage
            loading="eager"
            alt=""
            src="/placeholder--image-22@2x.png"
          />
          <PlaceholderImage
            loading="eager"
            alt=""
            src="/placeholder--image-22@2x.png"
          />
        </Column>
        <Column>
          <PlaceholderImage1
            loading="eager"
            alt=""
            src="/placeholder--image-43@2x.png"
          />
          <PlaceholderImage1
            loading="eager"
            alt=""
            src="/placeholder--image-43@2x.png"
          />
          <PlaceholderImage
            loading="eager"
            alt=""
            src="/placeholder--image-22@2x.png"
          />
        </Column>
        <Column>
          <PlaceholderImage
            loading="eager"
            alt=""
            src="/placeholder--image-22@2x.png"
          />
          <PlaceholderImage
            loading="eager"
            alt=""
            src="/placeholder--image-22@2x.png"
          />
        </Column>
      </Content>
    </GalleryRoot>
  );
};

export default Gallery;
