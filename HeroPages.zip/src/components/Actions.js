import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 640px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 400px;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const LinksIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const ACustomerTestimonial = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 136px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Icon = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Frame = styled.div`
  position: relative;
  line-height: 150%;
`;
const SocialLinks = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider = styled.div`
  height: 62px;
  width: 1px;
  position: relative;
  border-right: 1px solid var(--black);
  box-sizing: border-box;
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 1px;
  }
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xl);
  max-width: 100%;
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Text1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  box-sizing: border-box;
  gap: var(--gap-13xl);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
    min-width: 100%;
  }
`;
const ActionsRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Actions = ({ placeholderImage, aCustomerTestimonialThatH }) => {
  return (
    <ActionsRoot>
      <PlaceholderImage loading="eager" alt="" src={placeholderImage} />
      <Text1>
        <Stars>
          <LinksIcon loading="eager" alt="" src="/placeholder-image.svg" />
          <LinksIcon loading="eager" alt="" src="/placeholder-image.svg" />
          <LinksIcon loading="eager" alt="" src="/placeholder-image.svg" />
          <LinksIcon loading="eager" alt="" src="/placeholder-image.svg" />
          <LinksIcon loading="eager" alt="" src="/placeholder-image.svg" />
        </Stars>
        <ACustomerTestimonial>{aCustomerTestimonialThatH}</ACustomerTestimonial>
        <Heading>
          <SocialLinks>
            <Icon>Name Surname</Icon>
            <Frame>Position, Company name</Frame>
          </SocialLinks>
          <Divider />
          <WebflowBlack loading="eager" alt="" src="/webflow--black2.svg" />
        </Heading>
      </Text1>
    </ActionsRoot>
  );
};

export default Actions;
