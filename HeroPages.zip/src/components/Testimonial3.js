import styled from "styled-components";

const CTAContainer = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 102px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const HeaderContainer = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const CTA = styled.div`
  position: relative;
  line-height: 150%;
`;
const FacebookIcon = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider = styled.div`
  height: 62px;
  width: 1px;
  position: relative;
  border-right: 1px solid var(--black);
  box-sizing: border-box;
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 1px;
  }
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const AvatarImageParent = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content = styled.div`
  width: 768px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;
const TestimonialRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1050px) {
    padding-left: var(--padding-37xl);
    padding-right: var(--padding-37xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-29xl);
    padding: var(--padding-54xl) var(--padding-9xl);
    box-sizing: border-box;
  }
`;

const Testimonial3 = () => {
  return (
    <TestimonialRoot>
      <Content>
        <Stars>
          <CTAContainer loading="eager" alt="" src="/placeholder-image.svg" />
          <CTAContainer loading="eager" alt="" src="/placeholder-image.svg" />
          <CTAContainer loading="eager" alt="" src="/placeholder-image.svg" />
          <CTAContainer loading="eager" alt="" src="/placeholder-image.svg" />
          <CTAContainer loading="eager" alt="" src="/placeholder-image.svg" />
        </Stars>
        <Quote>
          "A customer testimonial that highlights features and answers potential
          customer doubts about your product or service. Showcase testimonials
          from a similar demographic to your customers."
        </Quote>
        <AvatarImageParent>
          <AvatarImageIcon
            loading="eager"
            alt=""
            src="/avatar-image-1@2x.png"
          />
          <FacebookIcon>
            <HeaderContainer>Customer Name</HeaderContainer>
            <CTA>Position, Company name</CTA>
          </FacebookIcon>
          <Divider />
          <WebflowBlack loading="eager" alt="" src="/webflow--black2.svg" />
        </AvatarImageParent>
      </Content>
    </TestimonialRoot>
  );
};

export default Testimonial3;
