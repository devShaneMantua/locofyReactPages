import styled from "styled-components";

const Icon = styled.input`
  margin: 0;
  height: 48px;
  width: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h5-size);
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const ContentContainer = styled.div`
  align-self: stretch;
  height: 48px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
  white-space: nowrap;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const RowContainer = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px 0px;
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 354px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const ListItemRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;

const ListItem = ({ heading }) => {
  return (
    <ListItemRoot>
      <Icon type="checkbox" />
      <Content>
        <Heading>{heading}</Heading>
        <ContentContainer>
          Highlight Unique Selling Propositions with a short summary of the key
          feature and how it benefits customers.
        </ContentContainer>
        <RowContainer>
          <Button1>
            <Button>Learn more</Button>
            <IconChevronRight
              loading="eager"
              alt=""
              src="/icon--chevron-right.svg"
            />
          </Button1>
        </RowContainer>
      </Content>
    </ListItemRoot>
  );
};

export default ListItem;
