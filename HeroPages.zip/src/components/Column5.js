import styled from "styled-components";

const IconRelume = styled.input`
  margin: 0;
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
  text-align: ${(p) => p.propTextAlign};
`;
const ColumnGroup = styled.div`
  align-self: stretch;
  height: 96px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  display: inline-block;
  text-align: ${(p) => p.propTextAlign1};
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const ColumnRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 304px;
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Column5 = ({ heading, propTextAlign, propTextAlign1 }) => {
  return (
    <ColumnRoot>
      <IconRelume type="checkbox" />
      <SectionTitle>
        <Heading propTextAlign={propTextAlign}>{heading}</Heading>
        <ColumnGroup propTextAlign1={propTextAlign1}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla.
        </ColumnGroup>
      </SectionTitle>
    </ColumnRoot>
  );
};

export default Column5;
