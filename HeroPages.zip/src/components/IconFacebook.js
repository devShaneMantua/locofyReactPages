import styled from "styled-components";

const IconLinkedIn = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const CustomerName = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const PositionCompanyName = styled.div`
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Column = styled.div`
  position: absolute;
  top: 0px;
  left: 28px;
  border: 1px solid var(--black);
  box-sizing: border-box;
  width: 416px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-12xl);
  gap: var(--gap-13xl);
  max-width: 100%;
  left: ${(p) => p.propLeft};
`;
const Icon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-base) var(--padding-mini);
  background-color: var(--white);
  position: absolute;
  top: 141px;
  left: 0px;
  border-radius: var(--br-31xl);
  box-sizing: border-box;
  width: 56px;
  height: 56px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  z-index: 1;
  left: ${(p) => p.propLeft1};
`;
const IconFacebookRoot = styled.div`
  height: 338px;
  width: 444px;
  position: relative;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 450px) {
    height: auto;
    min-height: 338;
  }
`;

const IconFacebook = ({ icon, propLeft, propLeft1 }) => {
  return (
    <IconFacebookRoot>
      <Column propLeft={propLeft}>
        <Stars>
          <IconLinkedIn loading="eager" alt="" src="/placeholder-image.svg" />
          <IconLinkedIn loading="eager" alt="" src="/placeholder-image.svg" />
          <IconLinkedIn alt="" src="/placeholder-image.svg" />
          <IconLinkedIn alt="" src="/placeholder-image.svg" />
          <IconLinkedIn alt="" src="/placeholder-image.svg" />
        </Stars>
        <Quote>
          "A customer testimonial that highlights features and answers potential
          customer doubts about your product or service. Showcase testimonials
          from a similar demographic to your customers."
        </Quote>
        <Avatar>
          <AvatarImageIcon loading="eager" alt="" src="/avatar-image@2x.png" />
          <AvatarContent>
            <CustomerName>Customer Name</CustomerName>
            <PositionCompanyName>Position, Company name</PositionCompanyName>
          </AvatarContent>
        </Avatar>
      </Column>
      <Button propLeft1={propLeft1}>
        <Icon alt="" src={icon} />
      </Button>
    </IconFacebookRoot>
  );
};

export default IconFacebook;
