import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  position: relative;
  height: 27px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const LinkOne = styled.div`
  position: relative;
  line-height: 150%;
`;
const ChevronDownIcon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const NavLinkDropdown = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-9xs);
`;
const Column1 = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Button = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-xl);
`;
const Button1 = styled.div`
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-xl);
  color: var(--white);
`;
const Column2 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-base);
`;
const Column3 = styled.div`
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-13xl);
`;
const Container = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;
const Navbar = styled.div`
  width: 1440px;
  background-color: var(--white);
  box-shadow: 0px -1px 0px #000 inset;
  height: 72px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0px var(--padding-45xl);
  box-sizing: border-box;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const FirstName = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Placeholder = styled.div`
  width: 341px;
  position: relative;
  line-height: 150%;
  display: none;
`;
const TextInput = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
  color: var(--color-dimgray);
`;
const Input = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Inputs = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const SelectOne = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Select = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
  gap: var(--gap-base);
  color: var(--color-dimgray);
`;
const Input1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Radio = styled.div`
  width: 20px;
  position: relative;
  border-radius: var(--br-81xl);
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  height: 20px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Radio1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
`;
const Column4 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-sm);
`;
const Radios = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) 0px;
  gap: var(--gap-base);
`;
const TypeYourMessage = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  z-index: 0;
`;
const TextAreaChild = styled.img`
  width: 2px;
  position: absolute;
  margin: 0 !important;
  right: 2px;
  bottom: 1.8px;
  height: 2px;
  object-fit: contain;
  z-index: 1;
`;
const TextAreaItem = styled.img`
  width: 6px;
  position: absolute;
  margin: 0 !important;
  right: 2px;
  bottom: 2px;
  height: 6px;
  object-fit: contain;
  z-index: 2;
`;
const TextArea = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  height: 182px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xs);
  position: relative;
  color: var(--color-dimgray);
`;
const Checkbox = styled.div`
  width: 20px;
  position: relative;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  height: 20px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Terms = styled.span`
  text-decoration: underline;
`;
const Checkbox1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-base);
  gap: var(--gap-xs);
  font-size: var(--text-small-link-size);
`;
const Button2 = styled.div`
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--white);
`;
const Form = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--text-regular-normal-size);
`;
const Contact = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-29xl);
  text-align: center;
  font-size: var(--heading-h2-size);
`;
const TextInput1 = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Button3 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--black);
`;
const Form1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-xs);
  line-height: 150%;
  color: var(--black);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  color: var(--color-dimgray);
`;
const Newsletter = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const ColumnOne = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column5 = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-xs);
`;
const Column6 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Links = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
`;
const Content = styled.div`
  width: 1312px;
  height: 248px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-109xl);
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  background-color: var(--black);
  height: 1px;
`;
const Link2 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const FooterLinks1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
`;
const Credits = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
`;
const Footer = styled.div`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  gap: var(--gap-61xl);
`;
const ContactRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const Contact11 = () => {
  return (
    <ContactRoot>
      <Navbar>
        <Container>
          <Column>
            <LogoIcon alt="" src="/logo.svg" />
          </Column>
          <Column3>
            <Column1>
              <LinkOne>Link One</LinkOne>
              <LinkOne>Link Two</LinkOne>
              <LinkOne>Link Three</LinkOne>
              <NavLinkDropdown>
                <LinkOne>Link Four</LinkOne>
                <ChevronDownIcon alt="" src="/chevron-down.svg" />
              </NavLinkDropdown>
            </Column1>
            <Column2>
              <Button>
                <LinkOne>Log in</LinkOne>
              </Button>
              <Button1>
                <LinkOne>Get started</LinkOne>
              </Button1>
            </Column2>
          </Column3>
        </Container>
      </Navbar>
      <Contact>
        <SectionTitle>
          <Heading>Contact us</Heading>
          <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
        </SectionTitle>
        <Form>
          <Inputs>
            <Input>
              <FirstName>First name</FirstName>
              <TextInput>
                <Placeholder>Placeholder</Placeholder>
              </TextInput>
            </Input>
            <Input>
              <FirstName>Last name</FirstName>
              <TextInput>
                <Placeholder>Placeholder</Placeholder>
              </TextInput>
            </Input>
          </Inputs>
          <Inputs>
            <Input>
              <FirstName>Email</FirstName>
              <TextInput>
                <Placeholder>Placeholder</Placeholder>
              </TextInput>
            </Input>
            <Input>
              <FirstName>Phone number</FirstName>
              <TextInput>
                <Placeholder>Placeholder</Placeholder>
              </TextInput>
            </Input>
          </Inputs>
          <Input1>
            <FirstName>Choose a topic</FirstName>
            <Select>
              <SelectOne>Select one...</SelectOne>
              <ChevronDownIcon alt="" src="/icon--chevron-down.svg" />
            </Select>
          </Input1>
          <Radios>
            <LinkOne>Which best describes you?</LinkOne>
            <Inputs>
              <Column4>
                <Radio1>
                  <Radio />
                  <LinkOne>First choice</LinkOne>
                </Radio1>
                <Radio1>
                  <Radio />
                  <LinkOne>Third choice</LinkOne>
                </Radio1>
                <Radio1>
                  <Radio />
                  <LinkOne>Fifth choice</LinkOne>
                </Radio1>
              </Column4>
              <Column4>
                <Radio1>
                  <Radio />
                  <LinkOne>Second choice</LinkOne>
                </Radio1>
                <Radio1>
                  <Radio />
                  <LinkOne>Fourth choice</LinkOne>
                </Radio1>
                <Radio1>
                  <Radio />
                  <LinkOne>Other</LinkOne>
                </Radio1>
              </Column4>
            </Inputs>
          </Radios>
          <Input1>
            <FirstName>Message</FirstName>
            <TextArea>
              <TypeYourMessage>Type your message...</TypeYourMessage>
              <TextAreaChild alt="" />
              <TextAreaItem alt="" />
            </TextArea>
          </Input1>
          <Checkbox1>
            <Checkbox />
            <LinkOne>
              {`I accept the `}
              <Terms>Terms</Terms>
            </LinkOne>
          </Checkbox1>
          <Button2>
            <LinkOne>Submit</LinkOne>
          </Button2>
        </Form>
      </Contact>
      <Footer>
        <Content>
          <Newsletter>
            <LogoIcon alt="" src="/logo.svg" />
            <FirstName>
              Join our newsletter to stay up to date on features and releases.
            </FirstName>
            <Actions>
              <Form1>
                <TextInput1>
                  <SelectOne>Enter your email</SelectOne>
                </TextInput1>
                <Button3>
                  <LinkOne>Subscribe</LinkOne>
                </Button3>
              </Form1>
              <Text2>
                {`By subscribing you agree to with our `}
                <Terms>Privacy Policy</Terms> and provide consent to receive
                updates from our company.
              </Text2>
            </Actions>
          </Newsletter>
          <Links>
            <Column5>
              <ColumnOne>Column One</ColumnOne>
              <FooterLinks>
                <Link>
                  <SelectOne>Link One</SelectOne>
                </Link>
                <Link>
                  <SelectOne>Link Two</SelectOne>
                </Link>
                <Link>
                  <SelectOne>Link Three</SelectOne>
                </Link>
                <Link>
                  <SelectOne>Link Four</SelectOne>
                </Link>
                <Link>
                  <SelectOne>Link Five</SelectOne>
                </Link>
              </FooterLinks>
            </Column5>
            <Column5>
              <ColumnOne>Column Two</ColumnOne>
              <FooterLinks>
                <Link>
                  <SelectOne>Link Six</SelectOne>
                </Link>
                <Link>
                  <SelectOne>Link Seven</SelectOne>
                </Link>
                <Link>
                  <SelectOne>Link Eight</SelectOne>
                </Link>
                <Link>
                  <SelectOne>Link Nine</SelectOne>
                </Link>
                <Link>
                  <SelectOne>Link Ten</SelectOne>
                </Link>
              </FooterLinks>
            </Column5>
            <Column6>
              <ColumnOne>Follow Us</ColumnOne>
              <FooterLinks>
                <Link1>
                  <ChevronDownIcon alt="" src="/icon--facebook.svg" />
                  <LinkOne>Facebook</LinkOne>
                </Link1>
                <Link1>
                  <ChevronDownIcon alt="" src="/icon--instagram.svg" />
                  <LinkOne>Instagram</LinkOne>
                </Link1>
                <Link1>
                  <ChevronDownIcon alt="" src="/icon--twitter.svg" />
                  <LinkOne>Twitter</LinkOne>
                </Link1>
                <Link1>
                  <ChevronDownIcon alt="" src="/icon--linkedin.svg" />
                  <LinkOne>LinkedIn</LinkOne>
                </Link1>
              </FooterLinks>
            </Column6>
          </Links>
        </Content>
        <Credits>
          <Divider />
          <Row>
            <LinkOne>© 2023 Relume. All rights reserved.</LinkOne>
            <FooterLinks1>
              <Link2>Privacy Policy</Link2>
              <Link2>Terms of Service</Link2>
              <Link2>Cookies Settings</Link2>
            </FooterLinks1>
          </Row>
        </Credits>
      </Footer>
    </ContactRoot>
  );
};

export default Contact11;
