import styled from "styled-components";
import Contact5 from "../components/Contact5";
import Content1 from "../components/Content1";
import Contact3 from "../components/Contact3";
import Footer from "../components/Footer";

const LogoIcon = styled.img`
  height: 27px;
  width: 63px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const LinkOne = styled.div`
  position: relative;
  line-height: 150%;
  white-space: nowrap;
`;
const ChevronDownIcon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const NavLinkDropdown = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-9xs);
`;
const Column1 = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    display: none;
  }
`;
const Button = styled.div`
  width: 44px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
  display: inline-block;
  white-space: nowrap;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-mid);
  background-color: transparent;
  width: 86px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Button2 = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--white);
  text-align: left;
`;
const Button3 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-mid);
  background-color: var(--black);
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Column2 = styled.div`
  width: 220px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-base);
`;
const Column3 = styled.div`
  width: 642px;
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    width: 252px;
    gap: var(--gap-13xl);
  }
`;
const Container = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
`;
const Navbar = styled.header`
  align-self: stretch;
  height: 72px;
  background-color: var(--white);
  box-shadow: 0px -1px 0px #000 inset;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0px var(--padding-45xl);
  box-sizing: border-box;
  top: 0;
  z-index: 99;
  position: sticky;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 800px) {
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
`;
const Contact = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-29xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-29xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;
const ContactRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Contact2 = () => {
  return (
    <ContactRoot>
      <Navbar>
        <Container>
          <Column>
            <LogoIcon loading="eager" alt="" src="/logo.svg" />
          </Column>
          <Column3>
            <Column1>
              <LinkOne>Link One</LinkOne>
              <LinkOne>Link Two</LinkOne>
              <LinkOne>Link Three</LinkOne>
              <NavLinkDropdown>
                <LinkOne>Link Four</LinkOne>
                <ChevronDownIcon alt="" src="/chevron-down.svg" />
              </NavLinkDropdown>
            </Column1>
            <Column2>
              <Button1>
                <Button>Log in</Button>
              </Button1>
              <Button3>
                <Button2>Get started</Button2>
              </Button3>
            </Column2>
          </Column3>
        </Container>
      </Navbar>
      <Contact5 />
      <Contact>
        <Content1
          iconEmail="/icon--email1.svg"
          heading="Email"
          link="hello@relume.io"
        />
        <Content1
          iconEmail="/icon--live-chat.svg"
          heading="Live Chat"
          link="+1 (555) 000-0000"
        />
        <Content1
          iconEmail="/icon--phone1.svg"
          heading="Phone"
          link="123 Sample St, Sydney NSW 2000 AU"
        />
      </Contact>
      <Contact3 />
      <Footer propWidth1="unset" />
    </ContactRoot>
  );
};

export default Contact2;
