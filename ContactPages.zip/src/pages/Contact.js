import styled from "styled-components";
import FrameFirstnamelastname from "../components/FrameFirstnamelastname";
import Content from "../components/Content";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h2-size);
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  text-align: left;
  @media screen and (max-width: 750px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const SubheadingParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const ColumnRadio = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: left;
`;
const FrameParent = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Contact6Inner = styled.section`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  @media screen and (max-width: 675px) {
    flex-wrap: wrap;
  }
`;
const IconPin = styled.img`
  width: 32px;
  height: 32px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading1 = styled.b`
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h6-size);
  line-height: 140%;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 22px;
  }
`;
const ContactInfoContent = styled.div`
  align-self: stretch;
  height: 48px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
`;
const ContactInfo = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Content1 = styled.div`
  width: 240px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Content2 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 675px) {
    gap: var(--gap-21xl);
    min-width: 100%;
  }
`;
const MessageArea = styled.section`
  width: 1312px;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 675px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const ContactRoot = styled.div`
  width: 100%;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-29xl);
  letter-spacing: normal;
  @media screen and (max-width: 675px) {
    gap: var(--gap-29xl);
  }
`;

const Contact = () => {
  return (
    <ContactRoot>
      <Contact6Inner>
        <FrameParent>
          <SubheadingParent>
            <Subheading>Tagline</Subheading>
            <Heading>Contact us</Heading>
          </SubheadingParent>
          <ColumnRadio>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</ColumnRadio>
        </FrameParent>
      </Contact6Inner>
      <MessageArea>
        <FrameFirstnamelastname />
        <Content2>
          <Row>
            <Content
              iconEmail="/icon--email.svg"
              heading="Email"
              link="hello@relume.io"
            />
            <Content
              iconEmail="/icon--phone.svg"
              heading="Phone"
              link="+1 (555) 000-0000"
            />
          </Row>
          <Content1>
            <IconPin loading="eager" alt="" src="/icon--pin.svg" />
            <ContactInfo>
              <Heading1>Office</Heading1>
              <ContactInfoContent>
                123 Sample St, Sydney NSW 2000 AU
              </ContactInfoContent>
              <Actions>
                <Button1>
                  <Button>Get Directions</Button>
                  <IconChevronRight
                    loading="eager"
                    alt=""
                    src="/icon--chevron-right.svg"
                  />
                </Button1>
              </Actions>
            </ContactInfo>
          </Content1>
        </Content2>
      </MessageArea>
    </ContactRoot>
  );
};

export default Contact;
