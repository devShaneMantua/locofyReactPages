import Navbar1 from "../components/Navbar1";
import styled from "styled-components";
import FrameComponent from "../components/FrameComponent";
import Footer from "../components/Footer";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const IconEmail = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Text2 = styled.div`
  position: relative;
  line-height: 150%;
  white-space: nowrap;
`;
const Row = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Text3 = styled.div`
  position: relative;
  line-height: 150%;
`;
const Content = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-base);
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
    min-width: 100%;
  }
`;
const Contact = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 1325px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;
const ContactRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Contact1 = () => {
  return (
    <ContactRoot>
      <Navbar1 />
      <Contact>
        <Content1>
          <SectionTitle>
            <Heading>Contact us</Heading>
            <Text1>Our friendly team would love to hear from you.</Text1>
          </SectionTitle>
          <Content>
            <Row>
              <IconEmail loading="eager" alt="" src="/icon--email2.svg" />
              <Text2>hello@relume.io</Text2>
            </Row>
            <Row>
              <IconEmail loading="eager" alt="" src="/icon--phone2.svg" />
              <Text3>+1 (555) 000-0000</Text3>
            </Row>
            <Row>
              <IconEmail loading="eager" alt="" src="/icon--pin2.svg" />
              <Text3>123 Sample St, Sydney NSW 2000 AU</Text3>
            </Row>
          </Content>
        </Content1>
        <FrameComponent />
      </Contact>
      <Footer />
    </ContactRoot>
  );
};

export default Contact1;
