import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  position: relative;
  height: 27px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const LinkOne = styled.div`
  position: relative;
  line-height: 150%;
`;
const ChevronDownIcon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const NavLinkDropdown = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-9xs);
`;
const Column1 = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Button = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-xl);
`;
const Button1 = styled.div`
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-xl);
  color: var(--white);
`;
const Column2 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-base);
`;
const Column3 = styled.div`
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-13xl);
`;
const Container = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;
const Navbar = styled.div`
  width: 1440px;
  background-color: var(--white);
  box-shadow: 0px -1px 0px #000 inset;
  height: 72px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0px var(--padding-45xl);
  box-sizing: border-box;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Name1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Placeholder = styled.div`
  width: 341px;
  position: relative;
  line-height: 150%;
  display: none;
`;
const TextInput = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
  color: var(--color-dimgray);
`;
const Input = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const TypeYourMessage = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  z-index: 0;
`;
const TextAreaChild = styled.img`
  width: 2px;
  position: absolute;
  margin: 0 !important;
  right: 2px;
  bottom: 1.8px;
  height: 2px;
  object-fit: contain;
  z-index: 1;
`;
const TextAreaItem = styled.img`
  width: 6px;
  position: absolute;
  margin: 0 !important;
  right: 2px;
  bottom: 2px;
  height: 6px;
  object-fit: contain;
  z-index: 2;
`;
const TextArea = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  height: 182px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xs);
  position: relative;
  color: var(--color-dimgray);
`;
const Checkbox = styled.div`
  width: 20px;
  position: relative;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  height: 20px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Terms = styled.span`
  text-decoration: underline;
`;
const Checkbox1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-base);
  gap: var(--gap-xs);
  font-size: var(--text-small-link-size);
`;
const Button2 = styled.div`
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--white);
`;
const Form = styled.div`
  width: 616px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--text-regular-normal-size);
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const Contact = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  font-size: var(--heading-h2-size);
`;
const Heading1 = styled.b`
  width: 320px;
  position: relative;
  line-height: 140%;
  display: inline-block;
  flex-shrink: 0;
`;
const WebflowBlack = styled.img`
  width: 120px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const RelumeBlack = styled.img`
  width: 140px;
  position: relative;
  height: 56px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-end;
  gap: var(--gap-13xl);
`;
const Logo = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-45xl);
  font-size: var(--heading-h5-size);
`;
const IconEmail = styled.img`
  width: 48px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading2 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 130%;
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Link = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  text-decoration: underline;
  line-height: 150%;
`;
const Content3 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Contact1 = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  font-size: var(--heading-h4-size);
`;
const Placeholder1 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TextInput1 = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Button3 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--black);
`;
const Form1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Text3 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-xs);
  line-height: 150%;
  color: var(--black);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  color: var(--color-dimgray);
`;
const Newsletter = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const ColumnOne = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column4 = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Link2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-xs);
`;
const Column5 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Links = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
`;
const Content4 = styled.div`
  width: 1312px;
  height: 248px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-109xl);
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  background-color: var(--black);
  height: 1px;
`;
const Link3 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const FooterLinks1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
`;
const Credits = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
`;
const Footer = styled.div`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  gap: var(--gap-61xl);
`;
const ContactRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const Contact4 = () => {
  return (
    <ContactRoot>
      <Navbar>
        <Container>
          <Column>
            <LogoIcon alt="" src="/logo.svg" />
          </Column>
          <Column3>
            <Column1>
              <LinkOne>Link One</LinkOne>
              <LinkOne>Link Two</LinkOne>
              <LinkOne>Link Three</LinkOne>
              <NavLinkDropdown>
                <LinkOne>Link Four</LinkOne>
                <ChevronDownIcon alt="" src="/chevron-down.svg" />
              </NavLinkDropdown>
            </Column1>
            <Column2>
              <Button>
                <LinkOne>Log in</LinkOne>
              </Button>
              <Button1>
                <LinkOne>Get started</LinkOne>
              </Button1>
            </Column2>
          </Column3>
        </Container>
      </Navbar>
      <Contact>
        <Content>
          <SectionTitle>
            <Heading>Contact us</Heading>
            <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
          </SectionTitle>
          <Form>
            <Input>
              <Name1>Name</Name1>
              <TextInput>
                <Placeholder>Placeholder</Placeholder>
              </TextInput>
            </Input>
            <Input>
              <Name1>Email</Name1>
              <TextInput>
                <Placeholder>Placeholder</Placeholder>
              </TextInput>
            </Input>
            <Input>
              <Name1>Message</Name1>
              <TextArea>
                <TypeYourMessage>Type your message...</TypeYourMessage>
                <TextAreaChild alt="" />
                <TextAreaItem alt="" />
              </TextArea>
            </Input>
            <Checkbox1>
              <Checkbox />
              <LinkOne>
                {`I accept the `}
                <Terms>Terms</Terms>
              </LinkOne>
            </Checkbox1>
            <Button2>
              <LinkOne>Submit</LinkOne>
            </Button2>
          </Form>
        </Content>
        <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
      </Contact>
      <Logo>
        <Heading1>
          Trusted by the world's best companies [social proof to build
          credibility]
        </Heading1>
        <Content1>
          <WebflowBlack alt="" src="/webflow--black.svg" />
          <RelumeBlack alt="" src="/relume--black.svg" />
          <WebflowBlack alt="" src="/webflow--black.svg" />
          <RelumeBlack alt="" src="/relume--black.svg" />
          <WebflowBlack alt="" src="/webflow--black.svg" />
        </Content1>
      </Logo>
      <Contact1>
        <Content3>
          <IconEmail alt="" src="/icon--email1.svg" />
          <SectionTitle>
            <Content2>
              <Heading2>Email</Heading2>
              <Text2>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in ero.
              </Text2>
            </Content2>
            <Link>hello@relume.io</Link>
          </SectionTitle>
        </Content3>
        <Content3>
          <IconEmail alt="" src="/icon--live-chat.svg" />
          <SectionTitle>
            <Content2>
              <Heading2>Live chat</Heading2>
              <Text2>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in ero.
              </Text2>
            </Content2>
            <Link>Start new chat</Link>
          </SectionTitle>
        </Content3>
        <Content3>
          <IconEmail alt="" src="/icon--phone1.svg" />
          <SectionTitle>
            <Content2>
              <Heading2>Phone</Heading2>
              <Text2>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in ero.
              </Text2>
            </Content2>
            <Link>+1 (555) 000-0000</Link>
          </SectionTitle>
        </Content3>
        <Content3>
          <IconEmail alt="" src="/icon--pin1.svg" />
          <SectionTitle>
            <Content2>
              <Heading2>Office</Heading2>
              <Text2>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in ero.
              </Text2>
            </Content2>
            <Link>123 Sample St, Sydney NSW 2000 AU</Link>
          </SectionTitle>
        </Content3>
      </Contact1>
      <Footer>
        <Content4>
          <Newsletter>
            <LogoIcon alt="" src="/logo.svg" />
            <Name1>
              Join our newsletter to stay up to date on features and releases.
            </Name1>
            <Actions>
              <Form1>
                <TextInput1>
                  <Placeholder1>Enter your email</Placeholder1>
                </TextInput1>
                <Button3>
                  <LinkOne>Subscribe</LinkOne>
                </Button3>
              </Form1>
              <Text3>
                {`By subscribing you agree to with our `}
                <Terms>Privacy Policy</Terms> and provide consent to receive
                updates from our company.
              </Text3>
            </Actions>
          </Newsletter>
          <Links>
            <Column4>
              <ColumnOne>Column One</ColumnOne>
              <FooterLinks>
                <Link1>
                  <Placeholder1>Link One</Placeholder1>
                </Link1>
                <Link1>
                  <Placeholder1>Link Two</Placeholder1>
                </Link1>
                <Link1>
                  <Placeholder1>Link Three</Placeholder1>
                </Link1>
                <Link1>
                  <Placeholder1>Link Four</Placeholder1>
                </Link1>
                <Link1>
                  <Placeholder1>Link Five</Placeholder1>
                </Link1>
              </FooterLinks>
            </Column4>
            <Column4>
              <ColumnOne>Column Two</ColumnOne>
              <FooterLinks>
                <Link1>
                  <Placeholder1>Link Six</Placeholder1>
                </Link1>
                <Link1>
                  <Placeholder1>Link Seven</Placeholder1>
                </Link1>
                <Link1>
                  <Placeholder1>Link Eight</Placeholder1>
                </Link1>
                <Link1>
                  <Placeholder1>Link Nine</Placeholder1>
                </Link1>
                <Link1>
                  <Placeholder1>Link Ten</Placeholder1>
                </Link1>
              </FooterLinks>
            </Column4>
            <Column5>
              <ColumnOne>Follow Us</ColumnOne>
              <FooterLinks>
                <Link2>
                  <ChevronDownIcon alt="" src="/icon--facebook.svg" />
                  <LinkOne>Facebook</LinkOne>
                </Link2>
                <Link2>
                  <ChevronDownIcon alt="" src="/icon--instagram.svg" />
                  <LinkOne>Instagram</LinkOne>
                </Link2>
                <Link2>
                  <ChevronDownIcon alt="" src="/icon--twitter.svg" />
                  <LinkOne>Twitter</LinkOne>
                </Link2>
                <Link2>
                  <ChevronDownIcon alt="" src="/icon--linkedin.svg" />
                  <LinkOne>LinkedIn</LinkOne>
                </Link2>
              </FooterLinks>
            </Column5>
          </Links>
        </Content4>
        <Credits>
          <Divider />
          <Row>
            <LinkOne>© 2023 Relume. All rights reserved.</LinkOne>
            <FooterLinks1>
              <Link3>Privacy Policy</Link3>
              <Link3>Terms of Service</Link3>
              <Link3>Cookies Settings</Link3>
            </FooterLinks1>
          </Row>
        </Credits>
      </Footer>
    </ContactRoot>
  );
};

export default Contact4;
