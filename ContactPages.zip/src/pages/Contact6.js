import styled from "styled-components";
import Layout from "../components/Layout";
import Contact7 from "../components/Contact7";

const LogoIcon = styled.img`
  height: 27px;
  width: 63px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  height: 27px;
  width: 63px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const LinkOne = styled.div`
  height: 24px;
  width: 62px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const LinkTwo = styled.div`
  height: 24px;
  width: 64px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const LinkThree = styled.div`
  height: 24px;
  width: 74px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const LinkFour = styled.div`
  height: 24px;
  width: 69.56px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const ChevronDownIcon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const NavLinkDropdown = styled.div`
  height: 24px;
  width: 94px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-9xs);
`;
const Column1 = styled.div`
  height: 24px;
  width: 390px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Button = styled.div`
  height: 24px;
  width: 47.56px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-xl);
  background-color: transparent;
  height: 42px;
  width: 86px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Button2 = styled.div`
  height: 24px;
  width: 83.56px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--white);
  text-align: left;
  display: inline-block;
`;
const Button3 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-xl);
  background-color: var(--black);
  height: 42px;
  width: 122px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Column2 = styled.div`
  height: 40px;
  width: 220px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-base);
`;
const Column3 = styled.div`
  height: 40px;
  width: 642px;
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-13xl);
`;
const Container = styled.div`
  width: 1312px;
  height: 40px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;
const Navbar = styled.header`
  width: 1440px;
  height: 72px;
  background-color: var(--white);
  box-shadow: 0px -1px 0px #000 inset;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0px var(--padding-45xl);
  box-sizing: border-box;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;
const Heading = styled.h3`
  margin: 0;
  width: 768px;
  height: 34px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const Hellocompanynamecom = styled.span`
  text-decoration: underline;
`;
const ContactText = styled.div`
  width: 768px;
  height: 54px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const Header = styled.section`
  width: 1440px;
  height: ;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
  text-align: center;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;
const LogoIcon1 = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const TextInputForm = styled.div`
  width: 500px;
  height: 24px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Placeholder = styled.input`
  width: 341px;
  border: none;
  outline: none;
  font-family: var(--text-regular-normal);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
`;
const TextInput = styled.div`
  height: 50px;
  width: 367px;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Button4 = styled.div`
  height: 24px;
  width: 71px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const Button5 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-5xl);
  background-color: transparent;
  height: 50px;
  width: 121px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Form = styled.div`
  width: 500px;
  height: 48px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const NavLinkDropdownContainer = styled.div`
  width: 500px;
  height: 36px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Actions = styled.div`
  width: 500px;
  height: 100px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--font-size-xs);
`;
const Newsletter = styled.div`
  height: ;
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const ColumnOne = styled.div`
  width: 201.3px;
  height: 24px;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
`;
const Link = styled.div`
  height: 21px;
  width: 201.3px;
  position: relative;
  line-height: 150%;
  display: inline-block;
  flex-shrink: 0;
`;
const Link1 = styled.div`
  width: 201.3px;
  height: 37px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  box-sizing: border-box;
`;
const FooterLinks = styled.div`
  width: 201.3px;
  height: 185px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column4 = styled.div`
  height: 225px;
  width: 201.3px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Facebook = styled.div`
  height: 21px;
  width: 61px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Link2 = styled.div`
  width: 201.3px;
  height: 40px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  box-sizing: border-box;
  gap: var(--gap-xs);
`;
const Instagram = styled.div`
  height: 21px;
  width: 64px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Twitter = styled.div`
  height: 21px;
  width: 44px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Linkedin = styled.div`
  height: 21px;
  width: 53px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const SocialLinks = styled.div`
  width: 201.3px;
  height: 160px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column5 = styled.div`
  height: 200px;
  width: 201.3px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Links = styled.div`
  height: 225px;
  width: 684px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
`;
const Content = styled.div`
  width: 1312px;
  height: 248px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-109xl);
`;
const Divider = styled.div`
  width: 1312px;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const ColumnOneFooter = styled.div`
  height: 21px;
  width: 220px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Link3 = styled.div`
  height: 21px;
  width: 87px;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
`;
const Link4 = styled.div`
  height: 21px;
  width: 105px;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
`;
const LinkParent = styled.div`
  height: 21px;
  width: 345px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  width: 1312px;
  height: 21px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 747px;
`;
const FrameLinkLinkLink = styled.div`
  width: 1312px;
  height: 54px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
`;
const Footer = styled.footer`
  width: 1440px;
  height: 542px;
  background-color: var(--white);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;
const ContactRoot = styled.div`
  width: 100%;
  height: 2588px;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;

const Contact6 = () => {
  return (
    <ContactRoot>
      <Navbar>
        <Container>
          <Column>
            <LogoIcon loading="eager" alt="" src="/logo.svg" />
          </Column>
          <Column3>
            <Column1>
              <LinkOne>Link One</LinkOne>
              <LinkTwo>Link Two</LinkTwo>
              <LinkThree>Link Three</LinkThree>
              <NavLinkDropdown>
                <LinkFour>Link Four</LinkFour>
                <ChevronDownIcon alt="" src="/chevron-down.svg" />
              </NavLinkDropdown>
            </Column1>
            <Column2>
              <Button1>
                <Button>Log in</Button>
              </Button1>
              <Button3>
                <Button2>Get started</Button2>
              </Button3>
            </Column2>
          </Column3>
        </Container>
      </Navbar>
      <Layout />
      <Header>
        <Heading>General enquiries</Heading>
        <ContactText>
          {`For general queries, including partnership opportunities, please email `}
          <Hellocompanynamecom>hello@companyname.com</Hellocompanynamecom>
        </ContactText>
      </Header>
      <Contact7 />
      <Footer>
        <Content>
          <Newsletter>
            <LogoIcon1 loading="eager" alt="" src="/logo.svg" />
            <TextInputForm>
              Join our newsletter to stay up to date on features and releases.
            </TextInputForm>
            <Actions>
              <Form>
                <TextInput>
                  <Placeholder placeholder="Enter your email" type="text" />
                </TextInput>
                <Button5>
                  <Button4>Subscribe</Button4>
                </Button5>
              </Form>
              <NavLinkDropdownContainer>
                {`By subscribing you agree to with our `}
                <Hellocompanynamecom>Privacy Policy</Hellocompanynamecom> and
                provide consent to receive updates from our company.
              </NavLinkDropdownContainer>
            </Actions>
          </Newsletter>
          <Links>
            <Column4>
              <ColumnOne>Column One</ColumnOne>
              <FooterLinks>
                <Link1>
                  <Link>Link One</Link>
                </Link1>
                <Link1>
                  <Link>Link Two</Link>
                </Link1>
                <Link1>
                  <Link>Link Three</Link>
                </Link1>
                <Link1>
                  <Link>Link Four</Link>
                </Link1>
                <Link1>
                  <Link>Link Five</Link>
                </Link1>
              </FooterLinks>
            </Column4>
            <Column4>
              <ColumnOne>Column Two</ColumnOne>
              <FooterLinks>
                <Link1>
                  <Link>Link Six</Link>
                </Link1>
                <Link1>
                  <Link>Link Seven</Link>
                </Link1>
                <Link1>
                  <Link>Link Eight</Link>
                </Link1>
                <Link1>
                  <Link>Link Nine</Link>
                </Link1>
                <Link1>
                  <Link>Link Ten</Link>
                </Link1>
              </FooterLinks>
            </Column4>
            <Column5>
              <ColumnOne>Follow Us</ColumnOne>
              <SocialLinks>
                <Link2>
                  <ChevronDownIcon
                    loading="eager"
                    alt=""
                    src="/icon--facebook.svg"
                  />
                  <Facebook>Facebook</Facebook>
                </Link2>
                <Link2>
                  <ChevronDownIcon
                    loading="eager"
                    alt=""
                    src="/icon--instagram.svg"
                  />
                  <Instagram>Instagram</Instagram>
                </Link2>
                <Link2>
                  <ChevronDownIcon
                    loading="eager"
                    alt=""
                    src="/icon--twitter.svg"
                  />
                  <Twitter>Twitter</Twitter>
                </Link2>
                <Link2>
                  <ChevronDownIcon
                    loading="eager"
                    alt=""
                    src="/icon--linkedin.svg"
                  />
                  <Linkedin>LinkedIn</Linkedin>
                </Link2>
              </SocialLinks>
            </Column5>
          </Links>
        </Content>
        <FrameLinkLinkLink>
          <Divider />
          <Row>
            <ColumnOneFooter>
              © 2023 Relume. All rights reserved.
            </ColumnOneFooter>
            <LinkParent>
              <Link3>Privacy Policy</Link3>
              <Link4>Terms of Service</Link4>
              <Link4>Cookies Settings</Link4>
            </LinkParent>
          </Row>
        </FrameLinkLinkLink>
      </Footer>
    </ContactRoot>
  );
};

export default Contact6;
