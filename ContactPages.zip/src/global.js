import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--text-regular-normal: Roboto;

/* font sizes */
--text-regular-normal-size: 16px;
--heading-h6-size: 20px;
--text-small-link-size: 14px;
--text-medium-normal-size: 18px;
--heading-h2-size: 48px;
--font-size-10xl: 29px;
--font-size-19xl: 38px;
--font-size-xs: 12px;
--heading-h4-size: 32px;
--heading-h5-size: 24px;
--font-size-lgi: 19px;
--font-size-7xl: 26px;

/* Colors */
--white: #fff;
--black: #000;
--color-darkslategray-100: #333;
--color-darkslategray-200: rgba(51, 51, 51, 0.09);
--color-dimgray: #505050;

/* Gaps */
--gap-29xl: 48px;
--gap-61xl: 80px;
--gap-21xl: 40px;
--gap-base: 16px;
--gap-5xs: 8px;
--gap-5xl: 24px;
--gap-xs: 12px;
--gap-sm: 14px;
--gap-13xl: 32px;
--gap-xl: 20px;
--gap-9xs: 4px;
--gap-109xl: 128px;
--gap-45xl: 64px;

/* Paddings */
--padding-93xl: 112px;
--padding-xl: 20px;
--padding-base: 16px;
--padding-xs: 12px;
--padding-2xs: 11px;
--padding-smi: 13px;
--padding-61xl: 80px;
--padding-45xl: 64px;
--padding-33xl: 52px;
--padding-13xl: 32px;
--padding-5xs: 8px;
--padding-4xl: 23px;
--padding-28xl: 47px;
--padding-54xl: 73px;
--padding-mid: 17px;
--padding-5xl: 24px;

/* Border radiuses */
--br-81xl: 100px;

}
`;
