import styled from "styled-components";

const LogoIcon = styled.img`
  height: 27px;
  width: 63px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const LinkOne = styled.div`
  position: relative;
  line-height: 150%;
  white-space: nowrap;
`;
const ChevronDownIcon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const NavLinkDropdown = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-9xs);
`;
const Column1 = styled.nav`
  margin: 0;
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 800px) {
    display: none;
  }
`;
const Button = styled.div`
  width: 47.56px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
  display: inline-block;
  white-space: nowrap;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-mid);
  background-color: transparent;
  width: 86px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Button2 = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--white);
  text-align: left;
`;
const Button3 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-mid);
  background-color: var(--black);
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Column2 = styled.div`
  width: 220px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-base);
`;
const Column3 = styled.div`
  width: 642px;
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    width: 252px;
    gap: var(--gap-13xl);
  }
`;
const Container = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
`;
const NavbarRoot = styled.header`
  align-self: stretch;
  height: 72px;
  background-color: var(--white);
  box-shadow: 0px -1px 0px #000 inset;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0px var(--padding-45xl);
  box-sizing: border-box;
  top: 0;
  z-index: 99;
  position: sticky;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const Navbar1 = () => {
  return (
    <NavbarRoot>
      <Container>
        <Column>
          <LogoIcon loading="eager" alt="" src="/logo.svg" />
        </Column>
        <Column3>
          <Column1>
            <LinkOne>Link One</LinkOne>
            <LinkOne>Link Two</LinkOne>
            <LinkOne>Link Three</LinkOne>
            <NavLinkDropdown>
              <LinkOne>Link Four</LinkOne>
              <ChevronDownIcon alt="" src="/chevron-down.svg" />
            </NavLinkDropdown>
          </Column1>
          <Column2>
            <Button1>
              <Button>Log in</Button>
            </Button1>
            <Button3>
              <Button2>Get started</Button2>
            </Button3>
          </Column2>
        </Column3>
      </Container>
    </NavbarRoot>
  );
};

export default Navbar1;
