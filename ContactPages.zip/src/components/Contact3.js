import styled from "styled-components";

const OurOffices = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const FrameNewYork = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Border = styled.div`
  height: 124px;
  width: 2px;
  position: relative;
  border-right: 2px solid var(--black);
  box-sizing: border-box;
  @media screen and (max-width: 800px) {
    width: 100%;
    height: 2px;
  }
`;
const Sydney = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const SydneyLink = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Link = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-weight: 600;
`;
const Content2 = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-5xl);
`;
const TabHorizontal = styled.div`
  align-self: stretch;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
    gap: var(--gap-13xl);
  }
`;
const Border1 = styled.div`
  height: 124px;
  width: 2px;
  position: relative;
  border-right: 2px solid var(--black);
  box-sizing: border-box;
  opacity: 0;
  @media screen and (max-width: 800px) {
    width: 100%;
    height: 2px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
`;
const TabsMenu = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  min-width: 500px;
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex: 1;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
    min-width: 100%;
  }
`;
const PlaceholderImage = styled.img`
  height: 440px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 476px;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const Content3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  text-align: left;
  font-size: var(--heading-h5-size);
`;
const ContactRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Contact3 = () => {
  return (
    <ContactRoot>
      <SectionTitle>
        <OurOffices>Our offices</OurOffices>
        <Content>
          <Heading>Locations</Heading>
          <FrameNewYork>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</FrameNewYork>
        </Content>
      </SectionTitle>
      <Content3>
        <TabsMenu>
          <TabHorizontal>
            <Border />
            <Content2>
              <Content1>
                <Sydney>Sydney</Sydney>
                <SydneyLink>123 Sample St, Sydney NSW 2000 AU</SydneyLink>
              </Content1>
              <Link>View Map</Link>
            </Content2>
          </TabHorizontal>
          <TabHorizontal>
            <Border1 />
            <Content2>
              <Content1>
                <Sydney>New York</Sydney>
                <Text1>123 Sample St, New York NY 10000 USA</Text1>
              </Content1>
              <Link>View Map</Link>
            </Content2>
          </TabHorizontal>
          <TabHorizontal>
            <Border1 />
            <Content2>
              <Content1>
                <Sydney>London</Sydney>
                <SydneyLink>
                  123 Sample St, London W1C 1DE, United Kingdom
                </SydneyLink>
              </Content1>
              <Link>View Map</Link>
            </Content2>
          </TabHorizontal>
        </TabsMenu>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-1@2x.png"
        />
      </Content3>
    </ContactRoot>
  );
};

export default Contact3;
