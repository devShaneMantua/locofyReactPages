import styled from "styled-components";

const FirstName = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.input`
  border: 1px solid var(--black);
  outline: none;
  background-color: var(--white);
  align-self: stretch;
  height: 50px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
  min-width: 178px;
`;
const FirstLastInputFrame = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  min-width: 192px;
`;
const FirstLastInputFrameParentRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;

const FrameComponent3 = () => {
  return (
    <FirstLastInputFrameParentRoot>
      <FirstLastInputFrame>
        <FirstName>First name</FirstName>
        <TextInput type="text" />
      </FirstLastInputFrame>
      <FirstLastInputFrame>
        <FirstName>Last name</FirstName>
        <TextInput type="text" />
      </FirstLastInputFrame>
    </FirstLastInputFrameParentRoot>
  );
};

export default FrameComponent3;
