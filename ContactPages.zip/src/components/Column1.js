import styled from "styled-components";

const PlaceholderImage = styled.img`
  width: 624px;
  height: 384px;
  position: relative;
  object-fit: cover;
`;
const Heading = styled.h1`
  margin: 0;
  width: 624px;
  height: 42px;
  position: relative;
  font-size: var(--heading-h4-size);
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const ChevronRightIcon = styled.div`
  width: 624px;
  height: 24px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Button = styled.div`
  height: 24px;
  width: 103.56px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button1 = styled.div`
  width: 133px;
  height: 24px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  text-align: left;
`;
const Content = styled.div`
  width: 624px;
  height: 138px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const ColumnRoot = styled.div`
  height: 554px;
  width: 624px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const Column1 = ({ heading, chevronRightIcon }) => {
  return (
    <ColumnRoot>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image2@2x.png"
      />
      <Content>
        <Heading>{heading}</Heading>
        <ChevronRightIcon>{chevronRightIcon}</ChevronRightIcon>
        <Button1>
          <Button>Get Directions</Button>
          <IconChevronRight
            loading="eager"
            alt=""
            src="/icon--chevron-right.svg"
          />
        </Button1>
      </Content>
    </ColumnRoot>
  );
};

export default Column1;
