import styled from "styled-components";

const Email = styled.div`
  width: 296px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const TextInput = styled.input`
  border: 1px solid var(--black);
  outline: none;
  background-color: var(--white);
  width: 298px;
  height: 50px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const ChooseATopic = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const TextInputParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const EmailPhonePinRow = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  max-width: 100%;
`;
const TextInput1 = styled.input`
  border: 1px solid var(--black);
  outline: none;
  background-color: var(--white);
  align-self: stretch;
  height: 50px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
  min-width: 178px;
`;
const Chooseatopicframe = styled.div`
  width: 296px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  margin-left: -296px;
`;
const EmailPhonePinRowParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const SelectOne = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: calc(100% - 40px);
`;
const IconChevronDown = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Select = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-smi) var(--padding-xs)
    var(--padding-2xs);
  gap: var(--gap-base);
  max-width: 100%;
  color: var(--color-dimgray);
`;
const FrameParentRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  min-height: 200px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const FrameComponent2 = () => {
  return (
    <FrameParentRoot>
      <EmailPhonePinRowParent>
        <EmailPhonePinRow>
          <Email>Email</Email>
          <TextInputParent>
            <TextInput type="text" />
            <ChooseATopic>Choose a topic</ChooseATopic>
          </TextInputParent>
        </EmailPhonePinRow>
        <Chooseatopicframe>
          <ChooseATopic>Phone number</ChooseATopic>
          <TextInput1 type="text" />
        </Chooseatopicframe>
      </EmailPhonePinRowParent>
      <Select>
        <SelectOne>Select one...</SelectOne>
        <IconChevronDown alt="" src="/icon--chevron-down.svg" />
      </Select>
    </FrameParentRoot>
  );
};

export default FrameComponent2;
