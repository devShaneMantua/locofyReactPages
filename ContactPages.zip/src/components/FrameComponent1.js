import styled from "styled-components";

const WhichBestDescribes = styled.div`
  position: relative;
  line-height: 150%;
`;
const Radio = styled.input`
  cursor: pointer;
  margin: 0;
  height: 20px;
  width: 20px;
  position: relative;
  border-radius: var(--br-81xl);
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  overflow: hidden;
  flex-shrink: 0;
`;
const Radio1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-sm);
  min-width: 192px;
`;
const RadioColumn = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const Message = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const ColumnRadioLabelColumns = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
  }
`;
const SocialLinksColumn = styled.img`
  width: 2px;
  height: 2px;
  position: absolute;
  margin: 0 !important;
  right: 0px;
  bottom: -0.2px;
  object-fit: contain;
`;
const ButtonInstanceIcon = styled.img`
  width: 6px;
  height: 6px;
  position: absolute;
  margin: 0 !important;
  right: 0px;
  bottom: 0px;
  object-fit: contain;
  z-index: 1;
`;
const TextArea = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-2xs);
  position: relative;
  min-height: 180px;
  color: var(--color-dimgray);
`;
const LabelColumn = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const WhichBestDescribesYouParentRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const FrameComponent1 = ({ socialLinksColumn, buttonInstance }) => {
  return (
    <WhichBestDescribesYouParentRoot>
      <WhichBestDescribes>Which best describes you?</WhichBestDescribes>
      <LabelColumn>
        <ColumnRadioLabelColumns>
          <RadioColumn>
            <Column>
              <Radio1>
                <Radio type="radio" name="radioGroup-1" />
                <WhichBestDescribes>First choice</WhichBestDescribes>
              </Radio1>
              <Radio1>
                <Radio type="radio" name="radioGroup-1" />
                <WhichBestDescribes>Third choice</WhichBestDescribes>
              </Radio1>
              <Radio1>
                <Radio type="radio" name="radioGroup-1" />
                <WhichBestDescribes>Fifth choice</WhichBestDescribes>
              </Radio1>
            </Column>
            <Column>
              <Radio1>
                <Radio type="radio" name="radioGroup-2" />
                <WhichBestDescribes>Second choice</WhichBestDescribes>
              </Radio1>
              <Radio1>
                <Radio type="radio" name="radioGroup-2" />
                <WhichBestDescribes>Fourth choice</WhichBestDescribes>
              </Radio1>
              <Radio1>
                <Radio type="radio" name="radioGroup-2" />
                <WhichBestDescribes>Other</WhichBestDescribes>
              </Radio1>
            </Column>
          </RadioColumn>
          <Message>Message</Message>
        </ColumnRadioLabelColumns>
        <TextArea>
          <Message>Type your message...</Message>
          <SocialLinksColumn loading="eager" alt="" src={socialLinksColumn} />
          <ButtonInstanceIcon alt="" src={buttonInstance} />
        </TextArea>
      </LabelColumn>
    </WhichBestDescribesYouParentRoot>
  );
};

export default FrameComponent1;
