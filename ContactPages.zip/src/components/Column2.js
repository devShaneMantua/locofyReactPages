import styled from "styled-components";

const IconRelume = styled.input`
  margin: 0;
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.h1`
  margin: 0;
  width: 405.3px;
  height: 42px;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const LogoFrame = styled.div`
  width: 405.3px;
  height: 48px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const SectionTitle = styled.div`
  width: 405.3px;
  height: 114px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Button = styled.div`
  height: 24px;
  width: 101.56px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
  display: inline-block;
  width: ${(p) => p.propWidth1};
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-5xl);
  background-color: transparent;
  width: 148px;
  height: 50px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  width: ${(p) => p.propWidth};
`;
const ColumnRoot = styled.div`
  height: 258px;
  width: 405.3px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: center;
  font-size: var(--heading-h4-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const Column2 = ({ heading, button, propWidth, propWidth1 }) => {
  return (
    <ColumnRoot>
      <IconRelume type="checkbox" />
      <SectionTitle>
        <Heading>{heading}</Heading>
        <LogoFrame>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in ero.
        </LogoFrame>
      </SectionTitle>
      <Button1 propWidth={propWidth}>
        <Button propWidth1={propWidth1}>{button}</Button>
      </Button1>
    </ColumnRoot>
  );
};

export default Column2;
