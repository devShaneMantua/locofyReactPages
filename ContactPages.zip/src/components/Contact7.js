import styled from "styled-components";
import Column1 from "./Column1";

const Heading = styled.h1`
  margin: 0;
  width: 768px;
  height: 58px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const HeadingText = styled.div`
  width: 768px;
  height: 27px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const SectionTitle = styled.div`
  width: 768px;
  height: ;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  width: 1312px;
  height: 554px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  font-size: var(--text-regular-normal-size);
`;
const ContactRoot = styled.section`
  width: 1440px;
  height: ;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const Contact7 = () => {
  return (
    <ContactRoot>
      <SectionTitle>
        <Heading>Our locations</Heading>
        <HeadingText>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</HeadingText>
      </SectionTitle>
      <Row>
        <Column1
          heading="Sydney"
          chevronRightIcon="123 Sample St, Sydney NSW 2000 AU"
        />
        <Column1
          heading="New York"
          chevronRightIcon="123 Sample St, New York NY 10000 USA"
        />
      </Row>
    </ContactRoot>
  );
};

export default Contact7;
