import styled from "styled-components";

const IconEmail = styled.img`
  width: 32px;
  height: 32px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h6-size);
  line-height: 140%;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 22px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Link = styled.div`
  align-self: stretch;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  white-space: nowrap;
`;
const ContactInfo = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const ContentRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 192px;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const Content = ({ iconEmail, heading, link }) => {
  return (
    <ContentRoot>
      <IconEmail loading="eager" alt="" src={iconEmail} />
      <ContactInfo>
        <Heading>{heading}</Heading>
        <Text1>Lorem ipsum dolor sit amet.</Text1>
        <Link>{link}</Link>
      </ContactInfo>
    </ContentRoot>
  );
};

export default Content;
