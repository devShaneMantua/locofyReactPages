import styled from "styled-components";

const IconEmail = styled.img`
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const NewYork = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Link = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  text-decoration: underline;
  line-height: 150%;
  white-space: nowrap;
`;
const ContactInfo = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const ContentRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 304px;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h4-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const Content1 = ({ iconEmail, heading, link }) => {
  return (
    <ContentRoot>
      <IconEmail loading="eager" alt="" src={iconEmail} />
      <ContactInfo>
        <Content>
          <Heading>{heading}</Heading>
          <NewYork>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in ero.
          </NewYork>
        </Content>
        <Link>{link}</Link>
      </ContactInfo>
    </ContentRoot>
  );
};

export default Content1;
