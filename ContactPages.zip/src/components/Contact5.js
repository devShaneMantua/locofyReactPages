import styled from "styled-components";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const FrameContentIcon = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Name1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.input`
  border: 1px solid var(--black);
  outline: none;
  background-color: var(--white);
  align-self: stretch;
  height: ;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
  min-width: 250px;
`;
const Input = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const TypeYourMessage = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  z-index: 0;
`;
const TextAreaChild = styled.img`
  height: 2px;
  width: 2px;
  position: absolute;
  margin: 0 !important;
  right: 2px;
  bottom: 1.8px;
  object-fit: contain;
  z-index: 1;
`;
const HeadingIcon = styled.img`
  height: 6px;
  width: 6px;
  position: absolute;
  margin: 0 !important;
  right: 2px;
  bottom: 2px;
  object-fit: contain;
  z-index: 2;
`;
const TextArea = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-2xs);
  position: relative;
  min-height: 180px;
  color: var(--color-dimgray);
`;
const Checkbox = styled.input`
  margin: 0;
  height: 20px;
  width: 20px;
  position: relative;
  border: 1px solid var(--black);
  box-sizing: border-box;
  overflow: hidden;
  flex-shrink: 0;
`;
const Terms = styled.span`
  text-decoration: underline;
`;
const Label = styled.div`
  position: relative;
  line-height: 150%;
`;
const Checkbox1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-base);
  gap: var(--gap-xs);
  font-size: var(--text-small-link-size);
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-5xl);
  background-color: var(--black);
  width: 101px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Form = styled.div`
  width: 616px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--text-regular-normal-size);
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const PlaceholderImage = styled.img`
  height: ;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 400px;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const ContactRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 1325px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Contact5 = () => {
  return (
    <ContactRoot>
      <Content>
        <SectionTitle>
          <Heading>Contact us</Heading>
          <FrameContentIcon>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</FrameContentIcon>
        </SectionTitle>
        <Form>
          <Input>
            <Name1>Name</Name1>
            <TextInput type="text" />
          </Input>
          <Input>
            <Name1>Email</Name1>
            <TextInput type="text" />
          </Input>
          <Input>
            <Name1>Message</Name1>
            <TextArea>
              <TypeYourMessage>Type your message...</TypeYourMessage>
              <TextAreaChild loading="eager" alt="" />
              <HeadingIcon alt="" />
            </TextArea>
          </Input>
          <Checkbox1>
            <Checkbox type="checkbox" />
            <Label>
              {`I accept the `}
              <Terms>Terms</Terms>
            </Label>
          </Checkbox1>
          <Button1>
            <Button>Submit</Button>
          </Button1>
        </Form>
      </Content>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image1@2x.png"
      />
    </ContactRoot>
  );
};

export default Contact5;
