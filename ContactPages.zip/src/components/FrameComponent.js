import FrameComponent3 from "./FrameComponent3";
import FrameComponent2 from "./FrameComponent2";
import FrameComponent1 from "./FrameComponent1";
import styled from "styled-components";

const Checkbox = styled.input`
  margin: 0;
  height: 20px;
  width: 20px;
  position: relative;
  border: 1px solid var(--black);
  box-sizing: border-box;
  overflow: hidden;
  flex-shrink: 0;
`;
const Terms = styled.span`
  text-decoration: underline;
`;
const Label = styled.div`
  position: relative;
  line-height: 150%;
`;
const Checkbox1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-base);
  gap: var(--gap-xs);
  font-size: var(--text-small-link-size);
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs);
  background-color: var(--black);
  width: 101px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const FrameParentRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 400px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;

const FrameComponent = () => {
  return (
    <FrameParentRoot>
      <FrameComponent3 />
      <FrameComponent2 />
      <FrameComponent1
        socialLinksColumn="pending_I6302:3621;2378:117"
        buttonInstance="pending_I6302:3621;2378:118"
      />
      <Checkbox1>
        <Checkbox type="checkbox" />
        <Label>
          {`I accept the `}
          <Terms>Terms</Terms>
        </Label>
      </Checkbox1>
      <Button1>
        <Button>Submit</Button>
      </Button1>
    </FrameParentRoot>
  );
};

export default FrameComponent;
