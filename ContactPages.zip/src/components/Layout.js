import styled from "styled-components";
import Column2 from "./Column2";

const Heading = styled.h1`
  margin: 0;
  width: 768px;
  height: 58px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const ColumnPlaceholder = styled.div`
  width: 768px;
  height: 27px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const Content = styled.div`
  width: 768px;
  height: ;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  width: 1312px;
  height: 258px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-29xl);
  font-size: var(--heading-h4-size);
`;
const LayoutRoot = styled.section`
  width: 1440px;
  height: ;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const Layout = () => {
  return (
    <LayoutRoot>
      <Content>
        <Heading>Contact us</Heading>
        <ColumnPlaceholder>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in ero.
        </ColumnPlaceholder>
      </Content>
      <Row>
        <Column2 heading="Sales" button="Contact sales" />
        <Column2
          heading={`Help & Support`}
          button="Get support"
          propWidth="134px"
          propWidth1="87.56px"
        />
        <Column2
          heading={`Media & Press`}
          button="Get press kit"
          propWidth="140px"
          propWidth1="93.56px"
        />
      </Row>
    </LayoutRoot>
  );
};

export default Layout;
