import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Contact from "./pages/Contact";
import Contact1 from "./pages/Contact3";
import Contact6 from "./pages/Contact6";
import Contact2 from "./pages/Contact2";
import Contact11 from "./pages/Contact1";
import Contact4 from "./pages/Contact4";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/contact-1":
        title = "";
        metaDescription = "";
        break;
      case "/contact-2":
        title = "";
        metaDescription = "";
        break;
      case "/contact-3":
        title = "";
        metaDescription = "";
        break;
      case "/contact-4":
        title = "";
        metaDescription = "";
        break;
      case "/contact-5":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<Contact />} />
      <Route path="/contact-1" element={<Contact1 />} />
      <Route path="/contact-2" element={<Contact6 />} />
      <Route path="/contact-3" element={<Contact2 />} />
      <Route path="/contact-4" element={<Contact11 />} />
      <Route path="/contact-5" element={<Contact4 />} />
    </Routes>
  );
}
export default App;
