import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--text-small-link: Roboto;
--font-inter: Inter;

/* font sizes */
--text-small-link-size: 14px;
--text-regular-semi-bold-size: 16px;
--text-tiny-normal-size: 12px;
--heading-h5-size: 24px;
--font-size-lgi: 19px;
--text-medium-normal-size: 18px;
--heading-h2-size: 48px;
--font-size-19xl: 38px;
--font-size-10xl: 29px;
--heading-h3-size: 40px;
--heading-h4-size: 32px;
--font-size-7xl: 26px;
--heading-h1-size: 56px;
--font-size-26xl: 45px;
--font-size-15xl: 34px;
--heading-h6-size: 20px;

/* Colors */
--white: #fff;
--black: #000;
--color-darkslategray-100: #333;
--color-darkslategray-200: rgba(51, 51, 51, 0.09);
--color-dimgray: #505050;
--light-grey: #f4f4f4;
--color-gainsboro: #dbdbdb;

/* Gaps */
--gap-61xl: 80px;
--gap-13xl: 32px;
--gap-xl: 20px;
--gap-5xl: 24px;
--gap-21xl: 40px;
--gap-base: 16px;
--gap-xs: 12px;
--gap-29xl: 48px;
--gap-45xl: 64px;
--gap-5xs: 8px;
--gap-9xs: 4px;
--gap-69xl: 88px;
--gap-49xl: 68px;
--gap-19xl: 38px;
--gap-411xl: 430px;
--gap-47xl: 66px;

/* Paddings */
--padding-61xl: 80px;
--padding-45xl: 64px;
--padding-33xl: 52px;
--padding-13xl: 32px;
--padding-5xs: 8px;
--padding-xs: 12px;
--padding-4xl: 23px;
--padding-smi: 13px;
--padding-2xs: 11px;
--padding-93xl: 112px;
--padding-28xl: 47px;
--padding-54xl: 73px;
--padding-9xs: 4px;
--padding-2xl: 21px;
--padding-77xl: 96px;
--padding-12xl: 31px;
--padding-29xl: 48px;
--padding-xl: 20px;
--padding-base: 16px;
--padding-mid: 17px;
--padding-sm: 14px;
--padding-5xl: 24px;
--padding-8xs: 5px;
--padding-109xl: 128px;
--padding-35xl: 54px;
--padding-64xl: 83px;
--padding-16xl: 35px;
--padding-14xl: 33px;
--padding-3xs: 10px;
--padding-25xl: 44px;

/* Border radiuses */
--br-45xl: 64px;

}
`;
