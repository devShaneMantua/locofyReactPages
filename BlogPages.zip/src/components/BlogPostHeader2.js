import styled from "styled-components";

const Blog = styled.div`
  position: relative;
  line-height: 150%;
`;
const Icon = styled.img`
  height: 16px;
  width: 16px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Category = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Breadcrumbs = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const BlogTitleHeading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h2-size);
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  text-align: left;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Content = styled.div`
  align-self: stretch;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const PlaceholderImage = styled.img`
  height: 48px;
  width: 48px;
  position: relative;
  object-fit: cover;
  min-height: 48px;
`;
const Div = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content1 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const IconLink = styled.img`
  width: 24px;
  height: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const ShareButton = styled.div`
  height: 32px;
  width: 32px;
  border-radius: var(--br-45xl);
  background-color: var(--light-grey);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-9xs);
  box-sizing: border-box;
`;
const ShareButtons = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--gap-xl);
  text-align: left;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const BlogHeader = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    gap: var(--gap-29xl);
  }
`;
const PlaceholderImage1 = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const Content3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const BlogPostHeaderRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const BlogPostHeader2 = () => {
  return (
    <BlogPostHeaderRoot>
      <Content3>
        <BlogHeader>
          <Content>
            <Breadcrumbs>
              <Blog>Blog</Blog>
              <Icon loading="eager" alt="" src="/icon.svg" />
              <Category>Category</Category>
            </Breadcrumbs>
            <BlogTitleHeading>Blog title heading will go here</BlogTitleHeading>
          </Content>
          <Content2>
            <Avatar>
              <PlaceholderImage
                loading="eager"
                alt=""
                src="/placeholder--image3@2x.png"
              />
              <Content1>
                <Category>Full name</Category>
                <Breadcrumbs>
                  <Blog>11 Jan 2022</Blog>
                  <Div>•</Div>
                  <Blog>5 min read</Blog>
                </Breadcrumbs>
              </Content1>
            </Avatar>
            <ShareButtons>
              <ShareButton>
                <IconLink loading="eager" alt="" src="/icon--link.svg" />
              </ShareButton>
              <ShareButton>
                <IconLink loading="eager" alt="" src="/icon--linkedin.svg" />
              </ShareButton>
              <ShareButton>
                <IconLink loading="eager" alt="" src="/icon--twitter.svg" />
              </ShareButton>
              <ShareButton>
                <IconLink loading="eager" alt="" src="/icon--facebook.svg" />
              </ShareButton>
            </ShareButtons>
          </Content2>
        </BlogHeader>
        <PlaceholderImage1 alt="" src="/placeholder--image1@2x.png" />
      </Content3>
    </BlogPostHeaderRoot>
  );
};

export default BlogPostHeader2;
