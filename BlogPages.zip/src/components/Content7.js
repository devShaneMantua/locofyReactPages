import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 300px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const ButtonText = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h2`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h5-size);
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const PlaceholderImage1 = styled.img`
  height: 48px;
  width: 48px;
  position: relative;
  object-fit: cover;
  min-height: 48px;
`;
const Text2 = styled.div`
  position: relative;
  line-height: 150%;
`;
const Div = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 7px;
  }
`;
const Time = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 229px;
  max-width: 100%;
`;
const Avatar = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Card = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Row = styled.div`
  align-self: stretch;
  display: grid;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  grid-template-columns: repeat(3, minmax(312px, 1fr));
  @media screen and (max-width: 1125px) {
    justify-content: center;
    grid-template-columns: repeat(2, minmax(312px, 541px));
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
    grid-template-columns: minmax(312px, 1fr);
  }
`;
const ContentRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-45xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;

const Content7 = () => {
  return (
    <ContentRoot>
      <Row>
        <Card>
          <PlaceholderImage
            loading="eager"
            alt=""
            src="/placeholder--image-21@2x.png"
          />
          <Content>
            <ButtonText>Category</ButtonText>
            <Heading>Blog title heading will go here</Heading>
            <Text1>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </Text1>
          </Content>
          <Avatar>
            <PlaceholderImage1
              loading="eager"
              alt=""
              src="/placeholder--image3@2x.png"
            />
            <Content1>
              <ButtonText>Full name</ButtonText>
              <Time>
                <Text2>11 Jan 2022</Text2>
                <Div>•</Div>
                <Text2>5 min read</Text2>
              </Time>
            </Content1>
          </Avatar>
        </Card>
        <Card>
          <PlaceholderImage
            loading="eager"
            alt=""
            src="/placeholder--image-21@2x.png"
          />
          <Content>
            <ButtonText>Category</ButtonText>
            <Heading>Blog title heading will go here</Heading>
            <Text1>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </Text1>
          </Content>
          <Avatar>
            <PlaceholderImage1
              loading="eager"
              alt=""
              src="/placeholder--image3@2x.png"
            />
            <Content1>
              <ButtonText>Full name</ButtonText>
              <Time>
                <Text2>11 Jan 2022</Text2>
                <Div>•</Div>
                <Text2>5 min read</Text2>
              </Time>
            </Content1>
          </Avatar>
        </Card>
        <Card>
          <PlaceholderImage
            loading="eager"
            alt=""
            src="/placeholder--image-21@2x.png"
          />
          <Content>
            <ButtonText>Category</ButtonText>
            <Heading>Blog title heading will go here</Heading>
            <Text1>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </Text1>
          </Content>
          <Avatar>
            <PlaceholderImage1
              loading="eager"
              alt=""
              src="/placeholder--image3@2x.png"
            />
            <Content1>
              <ButtonText>Full name</ButtonText>
              <Time>
                <Text2>11 Jan 2022</Text2>
                <Div>•</Div>
                <Text2>5 min read</Text2>
              </Time>
            </Content1>
          </Avatar>
        </Card>
      </Row>
    </ContentRoot>
  );
};

export default Content7;
