import styled from "styled-components";

const Contributors = styled.b`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const FullName = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const JobTitleCompany = styled.div`
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--text-regular-semi-bold-size);
`;
const DividerIcon = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const SubscribeToNewsletter = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Placeholder = styled.input`
  width: 100%;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-semi-bold-size);
  background-color: transparent;
  height: 24px;
  flex: 1;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
  min-width: 238px;
  max-width: 100%;
`;
const TextInput = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-3xs) var(--padding-smi) var(--padding-3xs)
    var(--padding-2xs);
  max-width: 100%;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-xl);
  background-color: var(--black);
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const BySubscribingYou = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-tiny-normal-size);
  line-height: 150%;
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const ShareThisPost = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const IconLink = styled.img`
  width: 24px;
  height: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const ShareButton = styled.div`
  height: 32px;
  width: 32px;
  border-radius: var(--br-45xl);
  background-color: var(--light-grey);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-9xs);
  box-sizing: border-box;
`;
const ShareButtons = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Share = styled.div`
  width: 152px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const ContentRoot = styled.div`
  width: 420px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  min-width: 420px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
    flex: 1;
  }
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-29xl);
  }
`;

const Content = () => {
  return (
    <ContentRoot>
      <Content1>
        <Contributors>Contributors</Contributors>
        <Avatar>
          <AvatarImageIcon loading="eager" alt="" src="/avatar-image@2x.png" />
          <AvatarContent>
            <FullName>Full Name</FullName>
            <JobTitleCompany>Job title, Company name</JobTitleCompany>
          </AvatarContent>
        </Avatar>
        <Avatar>
          <AvatarImageIcon loading="eager" alt="" src="/avatar-image@2x.png" />
          <AvatarContent>
            <FullName>Full Name</FullName>
            <JobTitleCompany>Job title, Company name</JobTitleCompany>
          </AvatarContent>
        </Avatar>
        <Avatar>
          <AvatarImageIcon loading="eager" alt="" src="/avatar-image@2x.png" />
          <AvatarContent>
            <FullName>Full Name</FullName>
            <JobTitleCompany>Job title, Company name</JobTitleCompany>
          </AvatarContent>
        </Avatar>
      </Content1>
      <DividerIcon loading="eager" alt="" src="/divider.svg" />
      <Form>
        <SubscribeToNewsletter>Subscribe to newsletter</SubscribeToNewsletter>
        <TextInput>
          <Placeholder placeholder="Enter your email" type="text" />
        </TextInput>
        <Button1>
          <Button>Subscribe</Button>
        </Button1>
        <BySubscribingYou>
          By subscribing you agree to with our Privacy Policy.
        </BySubscribingYou>
      </Form>
      <DividerIcon loading="eager" alt="" src="/divider.svg" />
      <Share>
        <ShareThisPost>Share this post</ShareThisPost>
        <ShareButtons>
          <ShareButton>
            <IconLink loading="eager" alt="" src="/icon--link.svg" />
          </ShareButton>
          <ShareButton>
            <IconLink loading="eager" alt="" src="/icon--linkedin.svg" />
          </ShareButton>
          <ShareButton>
            <IconLink loading="eager" alt="" src="/icon--twitter.svg" />
          </ShareButton>
          <ShareButton>
            <IconLink loading="eager" alt="" src="/icon--facebook.svg" />
          </ShareButton>
        </ShareButtons>
      </Share>
    </ContentRoot>
  );
};

export default Content;
