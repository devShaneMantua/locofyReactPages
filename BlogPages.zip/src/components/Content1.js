import styled from "styled-components";

const PlaceholderImage = styled.img`
  position: absolute;
  top: 320px;
  left: 0px;
  width: 768px;
  height: 400px;
  object-fit: cover;
`;
const Introduction = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const MiTinciduntElit = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const MiTinciduntElitIdQuisqueParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-semi-bold-size);
`;
const IntroductionParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Link = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xl) 0px 0px;
  box-sizing: border-box;
  min-width: 768px;
  max-width: 100%;
  @media screen and (max-width: 1150px) {
    flex: 1;
    min-width: 100%;
  }
`;
const SubscribeToNewsletter = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 22px;
  }
`;
const SubscribeToReceive = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Placeholder = styled.input`
  width: 100%;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-semi-bold-size);
  background-color: transparent;
  height: 24px;
  flex: 1;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
  min-width: 226px;
  max-width: 100%;
`;
const TextInput = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-3xs) var(--padding-smi) var(--padding-3xs)
    var(--padding-2xs);
  max-width: 100%;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-xl);
  background-color: var(--black);
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const BySubscribingYou = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-tiny-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const Form = styled.div`
  width: 464px;
  border: 1px solid var(--black);
  box-sizing: border-box;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-14xl) var(--padding-13xl)
    var(--padding-12xl);
  min-width: 302px;
  max-width: 100%;
  font-size: var(--heading-h6-size);
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 1150px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const FrameChild = styled.div`
  height: 21px;
  width: 2px;
  position: relative;
  background-color: var(--black);
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 2px;
  }
`;
const ImageCaptionGoes = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  min-width: 121px;
  max-width: 100%;
`;
const RectangleParent = styled.div`
  width: 788px;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-xl) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-5xs);
  max-width: 100%;
  font-size: var(--text-small-link-size);
`;
const ColumnOne = styled.div`
  position: absolute;
  top: 0px;
  left: 0px;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-411xl);
  height: 100%;
  max-width: 100%;
  @media screen and (max-width: 1350px) {
    gap: var(--gap-411xl);
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-411xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-411xl);
  }
`;
const PrivacyPolicy = styled.div`
  width: 1312px;
  height: 757px;
  position: relative;
  max-width: 100%;
  @media screen and (max-width: 1350px) {
    width: calc(100% - 40px);
  }
  @media screen and (max-width: 1150px) {
    height: auto;
    min-height: 757;
  }
`;
const DolorEnimEuTortorUrnaSedParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Divider = styled.div`
  height: 84px;
  width: 2px;
  position: relative;
  background-color: var(--black);
  @media screen and (max-width: 800px) {
    width: 100%;
    height: 2px;
  }
`;
const IpsumSitMattis = styled.i`
  flex: 1;
  position: relative;
  line-height: 28px;
  display: inline-block;
  min-width: 482px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 22px;
  }
`;
const DividerParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const TristiqueOdioSenectus = styled.div`
  align-self: stretch;
  height: 96px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  display: inline-block;
`;
const FrameGroup = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  font-family: var(--font-inter);
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;
const Conclusion = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const NuncSedFaucibus = styled.div`
  align-self: stretch;
  height: 72px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const ConclusionParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xl);
  font-size: var(--heading-h4-size);
`;
const FrameParent = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-19xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    gap: var(--gap-19xl);
  }
`;
const Content31Inner = styled.div`
  width: 1352px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-xl);
  box-sizing: border-box;
  max-width: 100%;
  font-size: var(--heading-h6-size);
`;
const ContentRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-109xl);
  box-sizing: border-box;
  gap: var(--gap-49xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h3-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1350px) {
    padding-bottom: var(--padding-64xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1150px) {
    padding-bottom: var(--padding-35xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-49xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-49xl);
    padding-bottom: var(--padding-16xl);
    box-sizing: border-box;
  }
`;

const Content1 = () => {
  return (
    <ContentRoot>
      <PrivacyPolicy>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-11@2x.png"
        />
        <ColumnOne>
          <FooterLinks>
            <Link>
              <IntroductionParent>
                <Introduction>Introduction</Introduction>
                <MiTinciduntElitIdQuisqueParent>
                  <MiTinciduntElit>
                    Mi tincidunt elit, id quisque ligula ac diam, amet. Vel
                    etiam suspendisse morbi eleifend faucibus eget vestibulum
                    felis. Dictum quis montes, sit sit. Tellus aliquam enim
                    urna, etiam. Mauris posuere vulputate arcu amet, vitae nisi,
                    tellus tincidunt. At feugiat sapien varius id.
                  </MiTinciduntElit>
                  <MiTinciduntElit>
                    Eget quis mi enim, leo lacinia pharetra, semper. Eget in
                    volutpat mollis at volutpat lectus velit, sed auctor.
                    Porttitor fames arcu quis fusce augue enim. Quis at habitant
                    diam at. Suscipit tristique risus, at donec. In turpis vel
                    et quam imperdiet. Ipsum molestie aliquet sodales id est ac
                    volutpat.
                  </MiTinciduntElit>
                </MiTinciduntElitIdQuisqueParent>
              </IntroductionParent>
            </Link>
            <Form>
              <Content>
                <SubscribeToNewsletter>
                  Subscribe to newsletter
                </SubscribeToNewsletter>
                <SubscribeToReceive>
                  Subscribe to receive the latest blog posts to your inbox every
                  week.
                </SubscribeToReceive>
                <TextInput>
                  <Placeholder placeholder="Enter your email" type="text" />
                </TextInput>
                <Button1>
                  <Button>Subscribe</Button>
                </Button1>
                <BySubscribingYou>
                  By subscribing you agree to with our Privacy Policy.
                </BySubscribingYou>
              </Content>
            </Form>
          </FooterLinks>
          <RectangleParent>
            <FrameChild />
            <ImageCaptionGoes>Image caption goes here</ImageCaptionGoes>
          </RectangleParent>
        </ColumnOne>
      </PrivacyPolicy>
      <Content31Inner>
        <FrameParent>
          <DolorEnimEuTortorUrnaSedParent>
            <SubscribeToNewsletter>
              Dolor enim eu tortor urna sed duis nulla. Aliquam vestibulum,
              nulla odio nisl vitae. In aliquet pellentesque aenean hac
              vestibulum turpis mi bibendum diam. Tempor integer aliquam in
              vitae malesuada fringilla.
            </SubscribeToNewsletter>
            <SubscribeToReceive>
              Elit nisi in eleifend sed nisi. Pulvinar at orci, proin imperdiet
              commodo consectetur convallis risus. Sed condimentum enim
              dignissim adipiscing faucibus consequat, urna. Viverra purus et
              erat auctor aliquam. Risus, volutpat vulputate posuere purus sit
              congue convallis aliquet. Arcu id augue ut feugiat donec porttitor
              neque. Mauris, neque ultricies eu vestibulum, bibendum quam lorem
              id. Dolor lacus, eget nunc lectus in tellus, pharetra, porttitor.
            </SubscribeToReceive>
          </DolorEnimEuTortorUrnaSedParent>
          <FrameGroup>
            <DividerParent>
              <Divider />
              <IpsumSitMattis>
                "Ipsum sit mattis nulla quam nulla. Gravida id gravida ac enim
                mauris id. Non pellentesque congue eget consectetur turpis.
                Sapien, dictum molestie sem tempor. Diam elit, orci, tincidunt
                aenean tempus."
              </IpsumSitMattis>
            </DividerParent>
            <TristiqueOdioSenectus>
              Tristique odio senectus nam posuere ornare leo metus, ultricies.
              Blandit duis ultricies vulputate morbi feugiat cras placerat elit.
              Aliquam tellus lorem sed ac. Montes, sed mattis pellentesque
              suscipit accumsan. Cursus viverra aenean magna risus elementum
              faucibus molestie pellentesque. Arcu ultricies sed mauris
              vestibulum.
            </TristiqueOdioSenectus>
          </FrameGroup>
          <ConclusionParent>
            <Conclusion>Conclusion</Conclusion>
            <MiTinciduntElitIdQuisqueParent>
              <MiTinciduntElit>
                Morbi sed imperdiet in ipsum, adipiscing elit dui lectus. Tellus
                id scelerisque est ultricies ultricies. Duis est sit sed leo
                nisl, blandit elit sagittis. Quisque tristique consequat quam
                sed. Nisl at scelerisque amet nulla purus habitasse.
              </MiTinciduntElit>
              <NuncSedFaucibus>
                Nunc sed faucibus bibendum feugiat sed interdum. Ipsum egestas
                condimentum mi massa. In tincidunt pharetra consectetur sed duis
                facilisis metus. Etiam egestas in nec sed et. Quis lobortis at
                sit dictum eget nibh tortor commodo cursus.
              </NuncSedFaucibus>
              <MiTinciduntElit>
                Odio felis sagittis, morbi feugiat tortor vitae feugiat fusce
                aliquet. Nam elementum urna nisi aliquet erat dolor enim. Ornare
                id morbi eget ipsum. Aliquam senectus neque ut id eget
                consectetur dictum. Donec posuere pharetra odio consequat
                scelerisque et, nunc tortor. Nulla adipiscing erat a erat.
                Condimentum lorem posuere gravida enim posuere cursus diam.
              </MiTinciduntElit>
            </MiTinciduntElitIdQuisqueParent>
          </ConclusionParent>
        </FrameParent>
      </Content31Inner>
    </ContentRoot>
  );
};

export default Content1;
