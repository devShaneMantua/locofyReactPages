import styled from "styled-components";

const Blog = styled.div`
  position: relative;
  line-height: 150%;
`;
const Icon = styled.img`
  height: 16px;
  width: 16px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Category = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Content = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const BlogTitleHeading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const By = styled.span``;
const FullName = styled.span`
  font-weight: 600;
`;
const Div = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content1 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  text-align: left;
  font-size: var(--heading-h2-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-29xl);
  }
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  flex-shrink: 0;
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
  }
`;
const IconLink = styled.img`
  width: 24px;
  height: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const ShareButton = styled.div`
  height: 32px;
  width: 32px;
  border-radius: var(--br-45xl);
  background-color: var(--light-grey);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-9xs);
  box-sizing: border-box;
`;
const ShareButtons = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Social = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  text-align: left;
  font-size: var(--text-medium-normal-size);
`;
const SectionTitle = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: space-between;
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const PlaceholderImage = styled.img`
  height: 395px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 400px;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const Content3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const BlogPostHeaderRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding: var(--padding-54xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const BlogPostHeader1 = () => {
  return (
    <BlogPostHeaderRoot>
      <Content3>
        <SectionTitle>
          <Title>
            <Content>
              <Blog>Blog</Blog>
              <Icon loading="eager" alt="" src="/icon.svg" />
              <Category>Category</Category>
            </Content>
            <Content2>
              <BlogTitleHeading>
                Blog title heading will go here
              </BlogTitleHeading>
              <Content1>
                <Blog>
                  <By>By</By>
                  <FullName> Full name</FullName>
                </Blog>
                <Content>
                  <Blog>11 Jan 2022</Blog>
                  <Div>•</Div>
                  <Blog>5 min read</Blog>
                </Content>
              </Content1>
            </Content2>
          </Title>
          <Social>
            <Category>Share this post</Category>
            <ShareButtons>
              <ShareButton>
                <IconLink loading="eager" alt="" src="/icon--link.svg" />
              </ShareButton>
              <ShareButton>
                <IconLink loading="eager" alt="" src="/icon--linkedin.svg" />
              </ShareButton>
              <ShareButton>
                <IconLink loading="eager" alt="" src="/icon--twitter.svg" />
              </ShareButton>
              <ShareButton>
                <IconLink loading="eager" alt="" src="/icon--facebook.svg" />
              </ShareButton>
            </ShareButtons>
          </Social>
        </SectionTitle>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image2@2x.png"
        />
      </Content3>
    </BlogPostHeaderRoot>
  );
};

export default BlogPostHeader1;
