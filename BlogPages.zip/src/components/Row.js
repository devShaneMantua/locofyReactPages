import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 300px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const TextInputButton = styled.div`
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const TitleRow = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-5xs);
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  &:hover {
    background-color: var(--color-gainsboro);
  }
`;
const LogoLinkForm = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Info = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const LinkSet = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h5-size);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  font-size: var(--text-regular-semi-bold-size);
`;
const Card = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const RowRoot = styled.div`
  width: 976px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Row = () => {
  return (
    <RowRoot>
      <Card>
        <PlaceholderImage alt="" src="/placeholder--image-12@2x.png" />
        <Content>
          <Info>
            <TitleRow>
              <TextInputButton>Category</TextInputButton>
            </TitleRow>
            <LogoLinkForm>5 min read</LogoLinkForm>
          </Info>
          <Title>
            <Heading>Blog title heading will go here</Heading>
            <LinkSet>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </LinkSet>
          </Title>
        </Content>
        <Button1>
          <Button>Read more</Button>
          <IconChevronRight alt="" src="/icon--chevron-right.svg" />
        </Button1>
      </Card>
      <Card>
        <PlaceholderImage alt="" src="/placeholder--image-12@2x.png" />
        <Content>
          <Info>
            <TitleRow>
              <TextInputButton>Category</TextInputButton>
            </TitleRow>
            <LogoLinkForm>5 min read</LogoLinkForm>
          </Info>
          <Title>
            <Heading>Blog title heading will go here</Heading>
            <LinkSet>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </LinkSet>
          </Title>
        </Content>
        <Button1>
          <Button>Read more</Button>
          <IconChevronRight alt="" src="/icon--chevron-right.svg" />
        </Button1>
      </Card>
    </RowRoot>
  );
};

export default Row;
