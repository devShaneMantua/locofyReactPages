import styled from "styled-components";
import Row from "./Row";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 134px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-26xl);
    line-height: 54px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
`;
const SubscriptionFormContainer = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h1-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const Heading1 = styled.b`
  position: relative;
  line-height: 150%;
`;
const ColumnOne = styled.input`
  width: 100%;
  border: none;
  outline: none;
  background-color: var(--light-grey);
  align-self: stretch;
  height: 48px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-base);
  box-sizing: border-box;
  font-family: var(--text-small-link);
  font-weight: 600;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  min-width: 144px;
`;
const CategoryOne = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-base);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-regular-semi-bold-size);
`;
const Categories = styled.div`
  width: 240px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 450px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const ButtonComponent = styled.div`
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const TitleComponent = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-5xs);
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  &:hover {
    background-color: var(--color-gainsboro);
  }
`;
const Info = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Heading2 = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const FooterLink = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h4-size);
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  font-size: var(--text-regular-semi-bold-size);
`;
const Card = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Content3 = styled.div`
  width: 976px;
  overflow-x: auto;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  @media screen and (max-width: 1125px) {
    gap: var(--gap-45xl);
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-45xl);
  }
`;
const Blogs = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  min-width: 634px;
  max-width: 100%;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 1125px) {
    gap: var(--gap-45xl);
    min-width: 100%;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-45xl);
  }
`;
const Content4 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  font-size: var(--text-medium-normal-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-45xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;
const BlogRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-77xl) var(--padding-93xl)
    var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding: var(--padding-12xl) var(--padding-29xl) var(--padding-12xl)
      var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
    padding-right: var(--padding-xl);
    box-sizing: border-box;
  }
`;

const Blog2 = () => {
  return (
    <BlogRoot>
      <SectionTitle>
        <Subheading>Blog</Subheading>
        <Content>
          <Heading>Describe what your blog is about</Heading>
          <SubscriptionFormContainer>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</SubscriptionFormContainer>
        </Content>
      </SectionTitle>
      <Content4>
        <Categories>
          <Heading1>Blog categories</Heading1>
          <Content1>
            <ColumnOne placeholder="View all" type="text" />
            <Button>
              <CategoryOne>Category one</CategoryOne>
            </Button>
            <Button>
              <CategoryOne>Category two</CategoryOne>
            </Button>
            <Button>
              <CategoryOne>Category three</CategoryOne>
            </Button>
            <Button>
              <CategoryOne>Category four</CategoryOne>
            </Button>
          </Content1>
        </Categories>
        <Blogs>
          <Card>
            <PlaceholderImage
              loading="eager"
              alt=""
              src="/placeholder--image4@2x.png"
            />
            <Content2>
              <Info>
                <TitleComponent>
                  <ButtonComponent>Category</ButtonComponent>
                </TitleComponent>
                <Subheading>5 min read</Subheading>
              </Info>
              <Title>
                <Heading2>Blog title heading will go here</Heading2>
                <FooterLink>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros.
                </FooterLink>
              </Title>
            </Content2>
            <Button1>
              <CategoryOne>Read more</CategoryOne>
              <IconChevronRight
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button1>
          </Card>
          <Content3>
            <Row />
            <Row />
          </Content3>
        </Blogs>
      </Content4>
    </BlogRoot>
  );
};

export default Blog2;
