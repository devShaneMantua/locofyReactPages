import styled from "styled-components";

const Introduction = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const MiTinciduntElit = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-semi-bold-size);
`;
const TextInput = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 400px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const FrameChild = styled.div`
  height: 21px;
  width: 2px;
  position: relative;
  background-color: var(--black);
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 2px;
  }
`;
const ImageCaptionGoes = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  min-width: 121px;
  max-width: 100%;
`;
const RectangleParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  max-width: 100%;
`;
const Footer = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const DolorEnimEu = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 22px;
  }
`;
const ElitNisiIn = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const DolorEnimEuTortorUrnaSedParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Divider = styled.div`
  height: 84px;
  width: 2px;
  position: relative;
  background-color: var(--black);
  @media screen and (max-width: 800px) {
    width: 100%;
    height: 2px;
  }
`;
const IpsumSitMattis = styled.h3`
  margin: 0;
  flex: 1;
  position: relative;
  font-size: inherit;
  line-height: 28px;
  display: inline-block;
  font-style: italic;
  font-weight: 400;
  font-family: inherit;
  min-width: 482px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 22px;
  }
`;
const DividerParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const TristiqueOdioSenectus = styled.div`
  align-self: stretch;
  height: 96px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  display: inline-block;
`;
const FrameGroup = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  font-family: var(--font-inter);
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;
const Conclusion = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const NuncSedFaucibus = styled.div`
  align-self: stretch;
  height: 72px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const ConclusionParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xl);
  font-size: var(--heading-h4-size);
`;
const FrameParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-19xl);
  max-width: 100%;
  font-size: var(--heading-h6-size);
  @media screen and (max-width: 450px) {
    gap: var(--gap-19xl);
  }
`;
const PrivacyPolicyTermsOfServic = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-49xl);
  max-width: 100%;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-49xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-49xl);
  }
`;
const ShareThisPost = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const IconLink = styled.img`
  width: 24px;
  height: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const ShareButton = styled.div`
  height: 32px;
  width: 32px;
  border-radius: var(--br-45xl);
  background-color: var(--light-grey);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-9xs);
  box-sizing: border-box;
`;
const ShareButtons = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Share = styled.div`
  width: 152px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const TagOne = styled.div`
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Tag = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-8xs) var(--padding-9xs)
    var(--padding-5xs);
  background-color: var(--light-grey);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-gainsboro);
  }
`;
const Tag1 = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-8xs) var(--padding-9xs)
    var(--padding-5xs);
  background-color: var(--light-grey);
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-gainsboro);
  }
`;
const Tags = styled.div`
  width: 301px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: space-between;
  gap: var(--gap-xl);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const Divider1 = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const FullName = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const JobTitleCompany = styled.div`
  position: relative;
  line-height: 150%;
  z-index: 1;
`;
const JobTitleCompanyName = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const CTAFrame = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-semi-bold-size);
`;
const ContentParent = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  font-size: var(--text-medium-normal-size);
  @media screen and (max-width: 450px) {
    gap: var(--gap-29xl);
  }
`;
const ContentRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-5xl) var(--padding-5xl) var(--padding-93xl);
  box-sizing: border-box;
  gap: var(--gap-45xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h3-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
    padding-top: var(--padding-xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1125px) {
    gap: var(--gap-45xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    padding-bottom: var(--padding-12xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;

const Content4 = () => {
  return (
    <ContentRoot>
      <TextInput>
        <Introduction>Introduction</Introduction>
        <Form>
          <MiTinciduntElit>
            Mi tincidunt elit, id quisque ligula ac diam, amet. Vel etiam
            suspendisse morbi eleifend faucibus eget vestibulum felis. Dictum
            quis montes, sit sit. Tellus aliquam enim urna, etiam. Mauris
            posuere vulputate arcu amet, vitae nisi, tellus tincidunt. At
            feugiat sapien varius id.
          </MiTinciduntElit>
          <MiTinciduntElit>
            Eget quis mi enim, leo lacinia pharetra, semper. Eget in volutpat
            mollis at volutpat lectus velit, sed auctor. Porttitor fames arcu
            quis fusce augue enim. Quis at habitant diam at. Suscipit tristique
            risus, at donec. In turpis vel et quam imperdiet. Ipsum molestie
            aliquet sodales id est ac volutpat.
          </MiTinciduntElit>
        </Form>
      </TextInput>
      <PrivacyPolicyTermsOfServic>
        <Footer>
          <PlaceholderImage alt="" src="/placeholder--image-11@2x.png" />
          <RectangleParent>
            <FrameChild />
            <ImageCaptionGoes>Image caption goes here</ImageCaptionGoes>
          </RectangleParent>
        </Footer>
        <FrameParent>
          <DolorEnimEuTortorUrnaSedParent>
            <DolorEnimEu>
              Dolor enim eu tortor urna sed duis nulla. Aliquam vestibulum,
              nulla odio nisl vitae. In aliquet pellentesque aenean hac
              vestibulum turpis mi bibendum diam. Tempor integer aliquam in
              vitae malesuada fringilla.
            </DolorEnimEu>
            <ElitNisiIn>
              Elit nisi in eleifend sed nisi. Pulvinar at orci, proin imperdiet
              commodo consectetur convallis risus. Sed condimentum enim
              dignissim adipiscing faucibus consequat, urna. Viverra purus et
              erat auctor aliquam. Risus, volutpat vulputate posuere purus sit
              congue convallis aliquet. Arcu id augue ut feugiat donec porttitor
              neque. Mauris, neque ultricies eu vestibulum, bibendum quam lorem
              id. Dolor lacus, eget nunc lectus in tellus, pharetra, porttitor.
            </ElitNisiIn>
          </DolorEnimEuTortorUrnaSedParent>
          <FrameGroup>
            <DividerParent>
              <Divider />
              <IpsumSitMattis>
                "Ipsum sit mattis nulla quam nulla. Gravida id gravida ac enim
                mauris id. Non pellentesque congue eget consectetur turpis.
                Sapien, dictum molestie sem tempor. Diam elit, orci, tincidunt
                aenean tempus."
              </IpsumSitMattis>
            </DividerParent>
            <TristiqueOdioSenectus>
              Tristique odio senectus nam posuere ornare leo metus, ultricies.
              Blandit duis ultricies vulputate morbi feugiat cras placerat elit.
              Aliquam tellus lorem sed ac. Montes, sed mattis pellentesque
              suscipit accumsan. Cursus viverra aenean magna risus elementum
              faucibus molestie pellentesque. Arcu ultricies sed mauris
              vestibulum.
            </TristiqueOdioSenectus>
          </FrameGroup>
          <ConclusionParent>
            <Conclusion>Conclusion</Conclusion>
            <Form>
              <MiTinciduntElit>
                Morbi sed imperdiet in ipsum, adipiscing elit dui lectus. Tellus
                id scelerisque est ultricies ultricies. Duis est sit sed leo
                nisl, blandit elit sagittis. Quisque tristique consequat quam
                sed. Nisl at scelerisque amet nulla purus habitasse.
              </MiTinciduntElit>
              <NuncSedFaucibus>
                Nunc sed faucibus bibendum feugiat sed interdum. Ipsum egestas
                condimentum mi massa. In tincidunt pharetra consectetur sed duis
                facilisis metus. Etiam egestas in nec sed et. Quis lobortis at
                sit dictum eget nibh tortor commodo cursus.
              </NuncSedFaucibus>
              <MiTinciduntElit>
                Odio felis sagittis, morbi feugiat tortor vitae feugiat fusce
                aliquet. Nam elementum urna nisi aliquet erat dolor enim. Ornare
                id morbi eget ipsum. Aliquam senectus neque ut id eget
                consectetur dictum. Donec posuere pharetra odio consequat
                scelerisque et, nunc tortor. Nulla adipiscing erat a erat.
                Condimentum lorem posuere gravida enim posuere cursus diam.
              </MiTinciduntElit>
            </Form>
          </ConclusionParent>
        </FrameParent>
      </PrivacyPolicyTermsOfServic>
      <ContentParent>
        <Content>
          <Share>
            <ShareThisPost>Share this post</ShareThisPost>
            <ShareButtons>
              <ShareButton>
                <IconLink alt="" src="/icon--link.svg" />
              </ShareButton>
              <ShareButton>
                <IconLink alt="" src="/icon--linkedin.svg" />
              </ShareButton>
              <ShareButton>
                <IconLink alt="" src="/icon--twitter.svg" />
              </ShareButton>
              <ShareButton>
                <IconLink alt="" src="/icon--facebook.svg" />
              </ShareButton>
            </ShareButtons>
          </Share>
          <Tags>
            <Tag>
              <TagOne>Tag one</TagOne>
            </Tag>
            <Tag>
              <TagOne>Tag two</TagOne>
            </Tag>
            <Tag1>
              <TagOne>Tag three</TagOne>
            </Tag1>
            <Tag1>
              <TagOne>Tag four</TagOne>
            </Tag1>
          </Tags>
        </Content>
        <Divider1 />
        <CTAFrame>
          <AvatarImageIcon loading="eager" alt="" src="/avatar-image@2x.png" />
          <JobTitleCompanyName>
            <FullName>Full Name</FullName>
            <JobTitleCompany>Job title, Company name</JobTitleCompany>
          </JobTitleCompanyName>
        </CTAFrame>
      </ContentParent>
    </ContentRoot>
  );
};

export default Content4;
