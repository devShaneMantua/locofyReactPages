import styled from "styled-components";

const RelatedPosts = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const LoremIpsumDolor = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 300px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Category = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const BlogTitleHeading = styled.h2`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h5-size);
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const LoremIpsumDolor1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const PlaceholderImage1 = styled.img`
  height: 48px;
  width: 48px;
  position: relative;
  object-fit: cover;
  min-height: 48px;
`;
const Jan = styled.div`
  position: relative;
  line-height: 150%;
`;
const Div = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 7px;
  }
`;
const Time = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 229px;
  max-width: 100%;
`;
const Avatar = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const Card = styled.div`
  width: 416px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  width: 1312px;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
  }
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xl);
  background-color: transparent;
  width: 106px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Content2 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-45xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;
const BlogRoot = styled.section`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Blog11 = () => {
  return (
    <BlogRoot>
      <SectionTitle>
        <RelatedPosts>Related posts</RelatedPosts>
        <LoremIpsumDolor>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</LoremIpsumDolor>
      </SectionTitle>
      <Content2>
        <Row>
          <Card>
            <PlaceholderImage alt="" src="/placeholder--image-21@2x.png" />
            <Content>
              <Category>Category</Category>
              <BlogTitleHeading>
                Blog title heading will go here
              </BlogTitleHeading>
              <LoremIpsumDolor1>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros.
              </LoremIpsumDolor1>
            </Content>
            <Avatar>
              <PlaceholderImage1 alt="" src="/placeholder--image3@2x.png" />
              <Content1>
                <Category>Full name</Category>
                <Time>
                  <Jan>11 Jan 2022</Jan>
                  <Div>•</Div>
                  <Jan>5 min read</Jan>
                </Time>
              </Content1>
            </Avatar>
          </Card>
          <Card>
            <PlaceholderImage alt="" src="/placeholder--image-21@2x.png" />
            <Content>
              <Category>Category</Category>
              <BlogTitleHeading>
                Blog title heading will go here
              </BlogTitleHeading>
              <LoremIpsumDolor1>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros.
              </LoremIpsumDolor1>
            </Content>
            <Avatar>
              <PlaceholderImage1 alt="" src="/placeholder--image3@2x.png" />
              <Content1>
                <Category>Full name</Category>
                <Time>
                  <Jan>11 Jan 2022</Jan>
                  <Div>•</Div>
                  <Jan>5 min read</Jan>
                </Time>
              </Content1>
            </Avatar>
          </Card>
          <Card>
            <PlaceholderImage alt="" src="/placeholder--image-21@2x.png" />
            <Content>
              <Category>Category</Category>
              <BlogTitleHeading>
                Blog title heading will go here
              </BlogTitleHeading>
              <LoremIpsumDolor1>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros.
              </LoremIpsumDolor1>
            </Content>
            <Avatar>
              <PlaceholderImage1 alt="" src="/placeholder--image3@2x.png" />
              <Content1>
                <Category>Full name</Category>
                <Time>
                  <Jan>11 Jan 2022</Jan>
                  <Div>•</Div>
                  <Jan>5 min read</Jan>
                </Time>
              </Content1>
            </Avatar>
          </Card>
        </Row>
        <Button1>
          <Button>View all</Button>
        </Button1>
      </Content2>
    </BlogRoot>
  );
};

export default Blog11;
