import Title from "./Title";
import Card2 from "./Card";
import styled from "styled-components";

const Row = styled.div`
  align-self: stretch;
  display: grid;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  grid-template-columns: repeat(3, minmax(312px, 1fr));
  @media screen and (max-width: 1150px) {
    justify-content: center;
    grid-template-columns: repeat(2, minmax(312px, 541px));
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
    grid-template-columns: minmax(312px, 1fr);
  }
`;
const BlogRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1150px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Blog6 = () => {
  return (
    <BlogRoot>
      <Title />
      <Row>
        <Card2 />
        <Card2 />
        <Card2 />
      </Row>
    </BlogRoot>
  );
};

export default Blog6;
