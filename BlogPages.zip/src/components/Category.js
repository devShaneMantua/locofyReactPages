import styled from "styled-components";

const Introduction = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const MiTinciduntElit = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Nunc = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-semi-bold-size);
`;
const Button = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 450px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Frame = styled.div`
  height: 21px;
  width: 2px;
  position: relative;
  background-color: var(--black);
  @media screen and (max-width: 800px) {
    width: 100%;
    height: 2px;
  }
`;
const ImageCaptionGoes = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  min-width: 121px;
  max-width: 100%;
`;
const Info = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const ColumnCard = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--text-small-link-size);
`;
const DolorEnimEu = styled.b`
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h6-size);
  line-height: 140%;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 22px;
  }
`;
const ElitNisiIn = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
`;
const FrameInner = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-xl);
  box-sizing: border-box;
  max-width: 100%;
`;
const Divider = styled.div`
  height: 84px;
  width: 2px;
  position: relative;
  background-color: var(--black);
  @media screen and (max-width: 800px) {
    width: 100%;
    height: 2px;
  }
`;
const IpsumSitMattis = styled.i`
  flex: 1;
  position: relative;
  line-height: 28px;
  display: inline-block;
  min-width: 480px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 22px;
  }
`;
const ContentWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-height: 100px;
  max-width: 100%;
  font-size: var(--heading-h6-size);
  font-family: var(--font-inter);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const TristiqueOdioSenectus = styled.div`
  height: 96px;
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
`;
const FrameInner1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-5xl);
  box-sizing: border-box;
  max-width: 100%;
`;
const Conclusion = styled.h1`
  margin: 0;
  flex: 1;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const FrameInner2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-9xs);
  box-sizing: border-box;
  max-width: 100%;
  font-size: var(--heading-h4-size);
`;
const NuncSedFaucibus = styled.div`
  align-self: stretch;
  height: 72px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Blog = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--text-regular-semi-bold-size);
`;
const MinReadRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-47xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h3-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-47xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-47xl);
  }
`;

const Category = () => {
  return (
    <MinReadRoot>
      <Button>
        <Introduction>Introduction</Introduction>
        <Nunc>
          <MiTinciduntElit>
            Mi tincidunt elit, id quisque ligula ac diam, amet. Vel etiam
            suspendisse morbi eleifend faucibus eget vestibulum felis. Dictum
            quis montes, sit sit. Tellus aliquam enim urna, etiam. Mauris
            posuere vulputate arcu amet, vitae nisi, tellus tincidunt. At
            feugiat sapien varius id.
          </MiTinciduntElit>
          <MiTinciduntElit>
            Eget quis mi enim, leo lacinia pharetra, semper. Eget in volutpat
            mollis at volutpat lectus velit, sed auctor. Porttitor fames arcu
            quis fusce augue enim. Quis at habitant diam at. Suscipit tristique
            risus, at donec. In turpis vel et quam imperdiet. Ipsum molestie
            aliquet sodales id est ac volutpat.
          </MiTinciduntElit>
        </Nunc>
      </Button>
      <ColumnCard>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-1@2x.png"
        />
        <Info>
          <Frame />
          <ImageCaptionGoes>Image caption goes here</ImageCaptionGoes>
        </Info>
      </ColumnCard>
      <Blog>
        <DolorEnimEu>
          Dolor enim eu tortor urna sed duis nulla. Aliquam vestibulum, nulla
          odio nisl vitae. In aliquet pellentesque aenean hac vestibulum turpis
          mi bibendum diam. Tempor integer aliquam in vitae malesuada fringilla.
        </DolorEnimEu>
        <FrameInner>
          <ElitNisiIn>
            Elit nisi in eleifend sed nisi. Pulvinar at orci, proin imperdiet
            commodo consectetur convallis risus. Sed condimentum enim dignissim
            adipiscing faucibus consequat, urna. Viverra purus et erat auctor
            aliquam. Risus, volutpat vulputate posuere purus sit congue
            convallis aliquet. Arcu id augue ut feugiat donec porttitor neque.
            Mauris, neque ultricies eu vestibulum, bibendum quam lorem id. Dolor
            lacus, eget nunc lectus in tellus, pharetra, porttitor.
          </ElitNisiIn>
        </FrameInner>
        <ContentWrapper>
          <Divider />
          <IpsumSitMattis>
            "Ipsum sit mattis nulla quam nulla. Gravida id gravida ac enim
            mauris id. Non pellentesque congue eget consectetur turpis. Sapien,
            dictum molestie sem tempor. Diam elit, orci, tincidunt aenean
            tempus."
          </IpsumSitMattis>
        </ContentWrapper>
        <FrameInner1>
          <TristiqueOdioSenectus>
            Tristique odio senectus nam posuere ornare leo metus, ultricies.
            Blandit duis ultricies vulputate morbi feugiat cras placerat elit.
            Aliquam tellus lorem sed ac. Montes, sed mattis pellentesque
            suscipit accumsan. Cursus viverra aenean magna risus elementum
            faucibus molestie pellentesque. Arcu ultricies sed mauris
            vestibulum.
          </TristiqueOdioSenectus>
        </FrameInner1>
        <FrameInner2>
          <Conclusion>Conclusion</Conclusion>
        </FrameInner2>
        <MiTinciduntElit>
          Morbi sed imperdiet in ipsum, adipiscing elit dui lectus. Tellus id
          scelerisque est ultricies ultricies. Duis est sit sed leo nisl,
          blandit elit sagittis. Quisque tristique consequat quam sed. Nisl at
          scelerisque amet nulla purus habitasse.
        </MiTinciduntElit>
        <NuncSedFaucibus>
          Nunc sed faucibus bibendum feugiat sed interdum. Ipsum egestas
          condimentum mi massa. In tincidunt pharetra consectetur sed duis
          facilisis metus. Etiam egestas in nec sed et. Quis lobortis at sit
          dictum eget nibh tortor commodo cursus.
        </NuncSedFaucibus>
        <MiTinciduntElit>
          Odio felis sagittis, morbi feugiat tortor vitae feugiat fusce aliquet.
          Nam elementum urna nisi aliquet erat dolor enim. Ornare id morbi eget
          ipsum. Aliquam senectus neque ut id eget consectetur dictum. Donec
          posuere pharetra odio consequat scelerisque et, nunc tortor. Nulla
          adipiscing erat a erat. Condimentum lorem posuere gravida enim posuere
          cursus diam.
        </MiTinciduntElit>
      </Blog>
    </MinReadRoot>
  );
};

export default Category;
