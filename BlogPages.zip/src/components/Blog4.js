import Title from "./Title";
import Card from "./Card";
import styled from "styled-components";

const Row = styled.div`
  align-self: stretch;
  display: grid;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  grid-template-columns: repeat(3, minmax(312px, 1fr));
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 1125px) {
    justify-content: center;
    grid-template-columns: repeat(2, minmax(312px, 541px));
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
    grid-template-columns: minmax(312px, 1fr);
  }
`;
const BlogRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Blog4 = () => {
  return (
    <BlogRoot>
      <Title />
      <Row>
        <Card />
        <Card />
        <Card />
      </Row>
    </BlogRoot>
  );
};

export default Blog4;
