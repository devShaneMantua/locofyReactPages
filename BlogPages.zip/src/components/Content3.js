import styled from "styled-components";

const Icon = styled.img`
  height: 16px;
  width: 16px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: contain;
`;
const AllPosts = styled.div`
  position: relative;
  line-height: 150%;
`;
const Content = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Category = styled.div`
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Tag = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-5xs);
  background-color: var(--light-grey);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  &:hover {
    background-color: var(--color-gainsboro);
  }
`;
const MinRead = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Content1 = styled.div`
  width: 181px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const BlogTitleHeading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h2-size);
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Content2 = styled.div`
  align-self: stretch;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  text-align: left;
  font-size: var(--text-small-link-size);
`;
const ContentRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-29xl);
  }
`;

const Content3 = () => {
  return (
    <ContentRoot>
      <Content>
        <Icon loading="eager" alt="" src="/icon1.svg" />
        <AllPosts>All Posts</AllPosts>
      </Content>
      <Content2>
        <Content1>
          <Tag>
            <Category>Category</Category>
          </Tag>
          <MinRead>5 min read</MinRead>
        </Content1>
        <BlogTitleHeading>Blog title heading will go here</BlogTitleHeading>
      </Content2>
    </ContentRoot>
  );
};

export default Content3;
