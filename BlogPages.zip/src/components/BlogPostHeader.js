import styled from "styled-components";

const Blog = styled.div`
  position: relative;
  line-height: 150%;
`;
const Icon = styled.img`
  height: 16px;
  width: 16px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Category = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Content = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
`;
const TagOne = styled.div`
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Tag = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-8xs) var(--padding-9xs)
    var(--padding-5xs);
  background-color: var(--light-grey);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-gainsboro);
  }
`;
const Content1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const BlogTitleHeading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: var(--heading-h2-size);
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const PublishedOn = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Content3 = styled.div`
  width: 420px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 420px;
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex: 1;
  }
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;
const PlaceholderImage = styled.img`
  height: 450px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 528px;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const Content4 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const BlogPostHeaderRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding: var(--padding-54xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const BlogPostHeader = () => {
  return (
    <BlogPostHeaderRoot>
      <Content4>
        <Content3>
          <Content>
            <Blog>Blog</Blog>
            <Icon loading="eager" alt="" src="/icon.svg" />
            <Category>Category</Category>
          </Content>
          <Content2>
            <Content1>
              <Tag>
                <TagOne>Tag one</TagOne>
              </Tag>
              <Category>5 min read</Category>
            </Content1>
            <BlogTitleHeading>Blog title heading will go here</BlogTitleHeading>
          </Content2>
          <PublishedOn>Published on 11 Jan 2022</PublishedOn>
        </Content3>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image@2x.png"
        />
      </Content4>
    </BlogPostHeaderRoot>
  );
};

export default BlogPostHeader;
