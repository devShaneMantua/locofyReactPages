import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const WrittenBy = styled.div`
  position: relative;
  line-height: 150%;
`;
const FullName = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 500;
`;
const Column = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Content = styled.div`
  width: 242px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
`;
const IconLink = styled.img`
  width: 24px;
  height: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const ShareButton = styled.div`
  height: 32px;
  width: 32px;
  border-radius: var(--br-45xl);
  background-color: var(--light-grey);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-9xs);
  box-sizing: border-box;
`;
const ShareButtons = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const ContentRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
  }
`;

const Content2 = () => {
  return (
    <ContentRoot>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image1@2x.png"
      />
      <Content1>
        <Content>
          <Column>
            <WrittenBy>Written by</WrittenBy>
            <FullName>Full Name</FullName>
          </Column>
          <Column>
            <WrittenBy>Published on</WrittenBy>
            <FullName>22 January 2021</FullName>
          </Column>
        </Content>
        <ShareButtons>
          <ShareButton>
            <IconLink loading="eager" alt="" src="/icon--link.svg" />
          </ShareButton>
          <ShareButton>
            <IconLink loading="eager" alt="" src="/icon--linkedin.svg" />
          </ShareButton>
          <ShareButton>
            <IconLink loading="eager" alt="" src="/icon--twitter.svg" />
          </ShareButton>
          <ShareButton>
            <IconLink loading="eager" alt="" src="/icon--facebook.svg" />
          </ShareButton>
        </ShareButtons>
      </Content1>
    </ContentRoot>
  );
};

export default Content2;
