import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 500px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 426px;
  @media screen and (max-width: 1325px) {
    flex: 1;
  }
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h4-size);
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const Text2 = styled.div`
  align-self: stretch;
  height: 48px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  display: inline-block;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const PlaceholderImage1 = styled.img`
  height: 48px;
  width: 48px;
  position: relative;
  object-fit: cover;
  min-height: 48px;
`;
const Text3 = styled.div`
  position: relative;
  line-height: 150%;
`;
const Div = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 7px;
  }
`;
const Time = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 354px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const Avatar = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const Content2 = styled.div`
  flex: 0.9268;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px var(--padding-xl) var(--padding-29xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
  min-width: 426px;
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex: 1;
  }
  @media screen and (max-width: 800px) {
    padding-left: var(--padding-5xl);
    box-sizing: border-box;
    min-width: 100%;
  }
`;
const CardRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  row-gap: 20px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
    flex-wrap: wrap;
  }
`;

const Card1 = () => {
  return (
    <CardRoot>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image5@2x.png"
      />
      <Content2>
        <Content>
          <Text1>Category</Text1>
          <Heading>Blog title heading will go here</Heading>
          <Text2>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros.
          </Text2>
        </Content>
        <Avatar>
          <PlaceholderImage1 alt="" src="/placeholder--image-13@2x.png" />
          <Content1>
            <Text1>Full name</Text1>
            <Time>
              <Text3>11 Jan 2022</Text3>
              <Div>•</Div>
              <Text3>5 min read</Text3>
            </Time>
          </Content1>
        </Avatar>
      </Content2>
    </CardRoot>
  );
};

export default Card1;
