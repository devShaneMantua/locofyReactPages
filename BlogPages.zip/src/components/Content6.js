import styled from "styled-components";
import Content7 from "./Content7";

const ViewAll = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Button = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-smi);
  background-color: transparent;
  width: 88px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const CategoryOne = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-sm);
  box-sizing: border-box;
  min-width: 84px;
`;
const Button2 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-sm);
  box-sizing: border-box;
  min-width: 89px;
`;
const Categories = styled.div`
  width: 608px;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  row-gap: 20px;
  max-width: 100%;
`;
const ContentRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-45xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;

const Content6 = () => {
  return (
    <ContentRoot>
      <Categories>
        <Button>
          <ViewAll>View all</ViewAll>
        </Button>
        <Button1>
          <CategoryOne>Category one</CategoryOne>
        </Button1>
        <Button1>
          <CategoryOne>Category two</CategoryOne>
        </Button1>
        <Button2>
          <CategoryOne>Category three</CategoryOne>
        </Button2>
        <Button1>
          <CategoryOne>Category four</CategoryOne>
        </Button1>
      </Categories>
      <Content7 />
      <Content7 />
      <Content7 />
    </ContentRoot>
  );
};

export default Content6;
