import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 300px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Category = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h2`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h5-size);
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const SubText = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const PlaceholderImage1 = styled.img`
  height: 48px;
  width: 48px;
  position: relative;
  object-fit: cover;
  min-height: 48px;
`;
const DividerLine = styled.div`
  position: relative;
  line-height: 150%;
`;
const Div = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 7px;
  }
`;
const Time = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 369px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const Avatar = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const Card = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const RowRoot = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Row1 = () => {
  return (
    <RowRoot>
      <Card>
        <PlaceholderImage alt="" src="/placeholder--image-22@2x.png" />
        <Content>
          <Category>Category</Category>
          <Heading>Blog title heading will go here</Heading>
          <SubText>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros.
          </SubText>
        </Content>
        <Avatar>
          <PlaceholderImage1 alt="" src="/placeholder--image3@2x.png" />
          <Content1>
            <Category>Full name</Category>
            <Time>
              <DividerLine>11 Jan 2022</DividerLine>
              <Div>•</Div>
              <DividerLine>5 min read</DividerLine>
            </Time>
          </Content1>
        </Avatar>
      </Card>
      <Card>
        <PlaceholderImage alt="" src="/placeholder--image-22@2x.png" />
        <Content>
          <Category>Category</Category>
          <Heading>Blog title heading will go here</Heading>
          <SubText>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros.
          </SubText>
        </Content>
        <Avatar>
          <PlaceholderImage1 alt="" src="/placeholder--image3@2x.png" />
          <Content1>
            <Category>Full name</Category>
            <Time>
              <DividerLine>11 Jan 2022</DividerLine>
              <Div>•</Div>
              <DividerLine>5 min read</DividerLine>
            </Time>
          </Content1>
        </Avatar>
      </Card>
    </RowRoot>
  );
};

export default Row1;
