import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Blog3 from "./pages/Blog3";
import Blog5 from "./pages/Blog5";
import Blog1 from "./pages/Blog1";
import Blog21 from "./pages/Blog2";
import BlogPost from "./pages/BlogPost3";
import BlogPost1 from "./pages/BlogPost1";
import BlogPost2 from "./pages/BlogPost2";
import BlogPost3 from "./pages/BlogPost";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/blog-1":
        title = "";
        metaDescription = "";
        break;
      case "/blog-2":
        title = "";
        metaDescription = "";
        break;
      case "/blog-3":
        title = "";
        metaDescription = "";
        break;
      case "/blog-post-1":
        title = "";
        metaDescription = "";
        break;
      case "/blog-post-2":
        title = "";
        metaDescription = "";
        break;
      case "/blog-post-3":
        title = "";
        metaDescription = "";
        break;
      case "/blog-post-4":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<Blog3 />} />
      <Route path="/blog-1" element={<Blog5 />} />
      <Route path="/blog-2" element={<Blog1 />} />
      <Route path="/blog-3" element={<Blog21 />} />
      <Route path="/blog-post-1" element={<BlogPost />} />
      <Route path="/blog-post-2" element={<BlogPost1 />} />
      <Route path="/blog-post-3" element={<BlogPost2 />} />
      <Route path="/blog-post-4" element={<BlogPost3 />} />
    </Routes>
  );
}
export default App;
