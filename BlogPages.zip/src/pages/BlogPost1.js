import Navbar from "../components/Navbar";
import BlogPostHeader1 from "../components/BlogPostHeader1";
import Content4 from "../components/Content4";
import CTA from "../components/CTA";
import Blog4 from "../components/Blog4";
import Footer from "../components/Footer";
import styled from "styled-components";

const BlogPostRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const BlogPost1 = () => {
  return (
    <BlogPostRoot>
      <Navbar />
      <BlogPostHeader1 />
      <Content4 />
      <CTA />
      <Blog4 />
      <Footer />
    </BlogPostRoot>
  );
};

export default BlogPost1;
