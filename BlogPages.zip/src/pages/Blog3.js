import Navbar from "../components/Navbar";
import Blog2 from "../components/Blog2";
import CTA from "../components/CTA";
import Blog from "../components/Blog";
import Footer from "../components/Footer";
import styled from "styled-components";

const BlogRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Blog3 = () => {
  return (
    <BlogRoot>
      <Navbar />
      <Blog2 />
      <CTA />
      <Blog heading="Latest posts" />
      <Footer />
    </BlogRoot>
  );
};

export default Blog3;
