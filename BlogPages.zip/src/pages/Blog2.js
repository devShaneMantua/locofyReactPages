import Navbar from "../components/Navbar";
import styled from "styled-components";
import Card1 from "../components/Card1";
import Content5 from "../components/Content5";
import CTA1 from "../components/CTA1";
import Footer from "../components/Footer";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 134px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-26xl);
    line-height: 54px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
`;
const LinkFrame = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h1-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-69xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-69xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-69xl);
  }
`;
const Blog = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-45xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-45xl);
    padding: var(--padding-12xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;
const BlogRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Blog21 = () => {
  return (
    <BlogRoot>
      <Navbar />
      <Blog>
        <SectionTitle>
          <Subheading>Blog</Subheading>
          <Content>
            <Heading>Describe what your blog is about</Heading>
            <LinkFrame>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</LinkFrame>
          </Content>
        </SectionTitle>
        <Content1>
          <Card1 />
          <Content5 />
        </Content1>
      </Blog>
      <CTA1 />
      <Footer />
    </BlogRoot>
  );
};

export default Blog21;
