import styled from "styled-components";

const LogoIcon = styled.img`
  height: 27px;
  width: 63px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  height: 27px;
  width: 63px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const LinkOne = styled.div`
  height: 24px;
  width: 62px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const LinkTwo = styled.div`
  height: 24px;
  width: 64px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const LinkThree = styled.div`
  height: 24px;
  width: 74px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const LinkFour = styled.div`
  height: 24px;
  width: 69.56px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const ChevronDownIcon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const NavLinkDropdown = styled.div`
  height: 24px;
  width: 94px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-9xs);
`;
const Column1 = styled.div`
  height: 24px;
  width: 390px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Button = styled.div`
  height: 24px;
  width: 47.56px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-xl);
  background-color: transparent;
  height: 42px;
  width: 86px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Button2 = styled.div`
  height: 24px;
  width: 83.56px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
  display: inline-block;
`;
const Button3 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-xl);
  background-color: var(--black);
  height: 42px;
  width: 122px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Column2 = styled.div`
  height: 40px;
  width: 220px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-base);
`;
const Column3 = styled.div`
  height: 40px;
  width: 642px;
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-13xl);
`;
const Container = styled.div`
  width: 1312px;
  height: 40px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;
const Navbar = styled.header`
  width: 1440px;
  height: 72px;
  background-color: var(--white);
  box-shadow: 0px -1px 0px #000 inset;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0px var(--padding-45xl);
  box-sizing: border-box;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;
const Subheading = styled.div`
  width: 33px;
  height: 24px;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
`;
const Heading = styled.h1`
  margin: 0;
  width: 768px;
  height: 134px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const Text1 = styled.div`
  width: 768px;
  height: 27px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const Content = styled.div`
  width: 768px;
  height: 185px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h1-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  height: ;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-semi-bold-size);
`;
const Heading1 = styled.h2`
  margin: 0;
  width: 1312px;
  height: 34px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const PlaceholderImage = styled.img`
  width: 640px;
  height: 400px;
  position: relative;
  object-fit: cover;
`;
const Text2 = styled.div`
  height: 21px;
  width: 57px;
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const TextWrapper = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-5xs);
  background-color: var(--light-grey);
  height: 29px;
  width: 73px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  box-sizing: border-box;
`;
const Text3 = styled.div`
  height: 21px;
  width: 70.11px;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
`;
const Info = styled.div`
  width: 159.11px;
  height: 29px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Heading2 = styled.h1`
  margin: 0;
  width: 640px;
  height: 42px;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const Text4 = styled.div`
  width: 640px;
  height: 24px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  display: inline-block;
`;
const Title = styled.div`
  width: 640px;
  height: 74px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h4-size);
`;
const Content1 = styled.div`
  width: 640px;
  height: 119px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button4 = styled.div`
  height: 24px;
  width: 80.56px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Button5 = styled.div`
  width: 109px;
  height: 24px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  font-size: var(--text-regular-semi-bold-size);
`;
const Card = styled.div`
  height: 814px;
  width: 640px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const PlaceholderImage1 = styled.img`
  height: 250px;
  width: 250px;
  position: relative;
  object-fit: cover;
`;
const Text5 = styled.div`
  height: 21px;
  width: 57px;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
`;
const TextContainer = styled.div`
  height: 29px;
  width: 73px;
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-9xs) var(--padding-5xs);
  box-sizing: border-box;
`;
const Heading3 = styled.h2`
  margin: 0;
  width: 366px;
  height: 34px;
  position: relative;
  font-size: var(--heading-h5-size);
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const Content2 = styled.div`
  width: 366px;
  height: 79px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Content3 = styled.div`
  height: 119px;
  width: 366px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Card1 = styled.div`
  width: 640px;
  height: 250px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Blogs = styled.div`
  height: 814px;
  width: 640px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Content4 = styled.div`
  width: 1312px;
  height: 814px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
`;
const BlogHero = styled.div`
  width: 1312px;
  height: 888px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
`;
const PlaceholderImage2 = styled.img`
  width: 416px;
  height: 300px;
  position: relative;
  object-fit: cover;
`;
const Heading4 = styled.h2`
  margin: 0;
  width: 416px;
  height: 34px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const Text6 = styled.div`
  width: 416px;
  height: 48px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  display: inline-block;
`;
const Title1 = styled.div`
  width: 416px;
  height: 90px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h5-size);
`;
const Content5 = styled.div`
  width: 416px;
  height: 135px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Card2 = styled.div`
  height: 507px;
  width: 416px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Content6 = styled.div`
  width: 1312px;
  height: 1364px;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: 64px 32px;
  font-size: var(--text-small-link-size);
`;
const Blogs1 = styled.div`
  width: 1312px;
  height: 1152px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
`;
const Blog = styled.section`
  width: 1440px;
  height: ;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;
const Heading5 = styled.h1`
  margin: 0;
  width: 752px;
  height: 48px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const Text7 = styled.div`
  width: 752px;
  height: 27px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const Content7 = styled.div`
  height: 99px;
  width: 752px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Placeholder = styled.input`
  width: 321px;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-semi-bold-size);
  background-color: transparent;
  height: 24px;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
`;
const TextInput = styled.div`
  height: 50px;
  width: 347px;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Button6 = styled.div`
  height: 24px;
  width: 71px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
  display: inline-block;
`;
const Button7 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-5xl);
  background-color: var(--black);
  height: 50px;
  width: 121px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Form = styled.div`
  width: 480px;
  height: 48px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const TermsAndConditions = styled.span`
  text-decoration: underline;
`;
const Text8 = styled.div`
  width: 480px;
  height: 18px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Actions = styled.div`
  height: ;
  width: 480px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-tiny-normal-size);
`;
const Cta = styled.section`
  width: 1440px;
  height: ;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: left;
  font-size: var(--heading-h3-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;
const Heading6 = styled.h1`
  margin: 0;
  width: 768px;
  height: 58px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const SectionTitle1 = styled.div`
  height: ;
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Button8 = styled.div`
  height: 24px;
  width: 59.56px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const Button9 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-5xl);
  background-color: transparent;
  height: 50px;
  width: 106px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Title2 = styled.div`
  width: 1312px;
  height: 109px;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: space-between;
`;
const Title3 = styled.div`
  width: 416px;
  height: ;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h5-size);
`;
const Row = styled.div`
  width: 1312px;
  height: ;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
`;
const Blog2 = styled.section`
  width: 1440px;
  height: ;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;
const Heading7 = styled.h1`
  margin: 0;
  width: 616px;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
`;
const Text9 = styled.div`
  width: 616px;
  height: 54px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const Content8 = styled.div`
  width: 616px;
  height: 194px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Button10 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-5xl);
  background-color: var(--black);
  height: 50px;
  width: 130px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Button11 = styled.div`
  height: 24px;
  width: 84.56px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const Button12 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-5xl);
  background-color: transparent;
  height: 50px;
  width: 131px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Actions1 = styled.div`
  width: 273px;
  height: 64px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-base);
`;
const Column4 = styled.div`
  height: 282px;
  width: 616px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const PlaceholderImage3 = styled.img`
  height: 400px;
  width: 616px;
  position: relative;
  object-fit: cover;
`;
const Cta1 = styled.section`
  width: 1440px;
  height: ;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;
const LogoIcon1 = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Text10 = styled.div`
  width: 500px;
  height: 24px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Placeholder1 = styled.input`
  width: 341px;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-semi-bold-size);
  background-color: transparent;
  height: 24px;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
`;
const TextInput1 = styled.div`
  height: 50px;
  width: 367px;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Button13 = styled.div`
  height: 24px;
  width: 71px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const Button14 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-5xl);
  background-color: transparent;
  height: 50px;
  width: 121px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Form1 = styled.div`
  width: 500px;
  height: 48px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Text11 = styled.div`
  width: 500px;
  height: 36px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Actions2 = styled.div`
  width: 500px;
  height: 100px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-tiny-normal-size);
`;
const Newsletter = styled.div`
  height: ;
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const ColumnOne = styled.div`
  width: 201.3px;
  height: 24px;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
`;
const Link = styled.div`
  height: 21px;
  width: 201.3px;
  position: relative;
  line-height: 150%;
  display: inline-block;
  flex-shrink: 0;
`;
const Link1 = styled.div`
  width: 201.3px;
  height: 37px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  box-sizing: border-box;
`;
const FooterLinks = styled.div`
  width: 201.3px;
  height: 185px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column5 = styled.div`
  height: 225px;
  width: 201.3px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Facebook = styled.div`
  height: 21px;
  width: 61px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Link2 = styled.div`
  width: 201.3px;
  height: 40px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  box-sizing: border-box;
  gap: var(--gap-xs);
`;
const Instagram = styled.div`
  height: 21px;
  width: 64px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Twitter = styled.div`
  height: 21px;
  width: 44px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Linkedin = styled.div`
  height: 21px;
  width: 53px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const SocialLinks = styled.div`
  width: 201.3px;
  height: 160px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column6 = styled.div`
  height: 200px;
  width: 201.3px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Links = styled.div`
  height: 225px;
  width: 684px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
`;
const Content9 = styled.div`
  width: 1312px;
  height: 248px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 128px;
`;
const Divider = styled.div`
  width: 1312px;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Text12 = styled.div`
  height: 21px;
  width: 220px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Link3 = styled.div`
  height: 21px;
  width: 87px;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
`;
const Link4 = styled.div`
  height: 21px;
  width: 105px;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
`;
const LinkParent = styled.div`
  height: 21px;
  width: 345px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row1 = styled.div`
  width: 1312px;
  height: 21px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 747px;
`;
const DividerParent = styled.div`
  width: 1312px;
  height: 54px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
`;
const Footer = styled.footer`
  width: 1440px;
  height: 542px;
  background-color: var(--white);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;
const BlogRoot = styled.div`
  width: 100%;
  height: 6970px;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;

const Blog1 = () => {
  return (
    <BlogRoot>
      <Navbar>
        <Container>
          <Column>
            <LogoIcon loading="eager" alt="" src="/logo.svg" />
          </Column>
          <Column3>
            <Column1>
              <LinkOne>Link One</LinkOne>
              <LinkTwo>Link Two</LinkTwo>
              <LinkThree>Link Three</LinkThree>
              <NavLinkDropdown>
                <LinkFour>Link Four</LinkFour>
                <ChevronDownIcon alt="" src="/chevron-down.svg" />
              </NavLinkDropdown>
            </Column1>
            <Column2>
              <Button1>
                <Button>Log in</Button>
              </Button1>
              <Button3>
                <Button2>Get started</Button2>
              </Button3>
            </Column2>
          </Column3>
        </Container>
      </Navbar>
      <Blog>
        <SectionTitle>
          <Subheading>Blog</Subheading>
          <Content>
            <Heading>Describe what your blog is about</Heading>
            <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
          </Content>
        </SectionTitle>
        <BlogHero>
          <Heading1>Featured blog posts</Heading1>
          <Content4>
            <Card>
              <PlaceholderImage
                loading="eager"
                alt=""
                src="/placeholder--image6@2x.png"
              />
              <Content1>
                <Info>
                  <TextWrapper>
                    <Text2>Category</Text2>
                  </TextWrapper>
                  <Text3>5 min read</Text3>
                </Info>
                <Title>
                  <Heading2>Blog title heading will go here</Heading2>
                  <Text4>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros.
                  </Text4>
                </Title>
              </Content1>
              <Button5>
                <Button4>Read more</Button4>
                <ChevronDownIcon
                  loading="eager"
                  alt=""
                  src="/icon--chevron-right.svg"
                />
              </Button5>
            </Card>
            <Blogs>
              <Card1>
                <PlaceholderImage1
                  loading="eager"
                  alt=""
                  src="/placeholder--image-14@2x.png"
                />
                <Content3>
                  <Content2>
                    <Info>
                      <TextContainer>
                        <Text5>Category</Text5>
                      </TextContainer>
                      <Text3>5 min read</Text3>
                    </Info>
                    <Heading3>Blog title heading will go here</Heading3>
                  </Content2>
                  <Button5>
                    <Button4>Read more</Button4>
                    <ChevronDownIcon
                      loading="eager"
                      alt=""
                      src="/icon--chevron-right.svg"
                    />
                  </Button5>
                </Content3>
              </Card1>
              <Card1>
                <PlaceholderImage1
                  loading="eager"
                  alt=""
                  src="/placeholder--image-14@2x.png"
                />
                <Content3>
                  <Content2>
                    <Info>
                      <TextContainer>
                        <Text5>Category</Text5>
                      </TextContainer>
                      <Text3>5 min read</Text3>
                    </Info>
                    <Heading3>Blog title heading will go here</Heading3>
                  </Content2>
                  <Button5>
                    <Button4>Read more</Button4>
                    <ChevronDownIcon
                      loading="eager"
                      alt=""
                      src="/icon--chevron-right.svg"
                    />
                  </Button5>
                </Content3>
              </Card1>
              <Card1>
                <PlaceholderImage1
                  loading="eager"
                  alt=""
                  src="/placeholder--image-14@2x.png"
                />
                <Content3>
                  <Content2>
                    <Info>
                      <TextContainer>
                        <Text5>Category</Text5>
                      </TextContainer>
                      <Text3>5 min read</Text3>
                    </Info>
                    <Heading3>Blog title heading will go here</Heading3>
                  </Content2>
                  <Button5>
                    <Button4>Read more</Button4>
                    <ChevronDownIcon
                      loading="eager"
                      alt=""
                      src="/icon--chevron-right.svg"
                    />
                  </Button5>
                </Content3>
              </Card1>
            </Blogs>
          </Content4>
        </BlogHero>
        <Blogs1>
          <Heading1>Featured blog posts</Heading1>
          <Content6>
            <Card2>
              <PlaceholderImage2
                loading="eager"
                alt=""
                src="/placeholder--image-21@2x.png"
              />
              <Content5>
                <Info>
                  <TextWrapper>
                    <Text2>Category</Text2>
                  </TextWrapper>
                  <Text3>5 min read</Text3>
                </Info>
                <Title1>
                  <Heading4>Blog title heading will go here</Heading4>
                  <Text6>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros.
                  </Text6>
                </Title1>
              </Content5>
              <Button5>
                <Button4>Read more</Button4>
                <ChevronDownIcon
                  loading="eager"
                  alt=""
                  src="/icon--chevron-right.svg"
                />
              </Button5>
            </Card2>
            <Card2>
              <PlaceholderImage2
                loading="eager"
                alt=""
                src="/placeholder--image-21@2x.png"
              />
              <Content5>
                <Info>
                  <TextWrapper>
                    <Text2>Category</Text2>
                  </TextWrapper>
                  <Text3>5 min read</Text3>
                </Info>
                <Title1>
                  <Heading4>Blog title heading will go here</Heading4>
                  <Text6>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros.
                  </Text6>
                </Title1>
              </Content5>
              <Button5>
                <Button4>Read more</Button4>
                <ChevronDownIcon alt="" src="/icon--chevron-right.svg" />
              </Button5>
            </Card2>
            <Card2>
              <PlaceholderImage2
                loading="eager"
                alt=""
                src="/placeholder--image-21@2x.png"
              />
              <Content5>
                <Info>
                  <TextWrapper>
                    <Text2>Category</Text2>
                  </TextWrapper>
                  <Text3>5 min read</Text3>
                </Info>
                <Title1>
                  <Heading4>Blog title heading will go here</Heading4>
                  <Text6>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros.
                  </Text6>
                </Title1>
              </Content5>
              <Button5>
                <Button4>Read more</Button4>
                <ChevronDownIcon alt="" src="/icon--chevron-right.svg" />
              </Button5>
            </Card2>
            <Card2>
              <PlaceholderImage2
                loading="eager"
                alt=""
                src="/placeholder--image-21@2x.png"
              />
              <Content5>
                <Info>
                  <TextWrapper>
                    <Text2>Category</Text2>
                  </TextWrapper>
                  <Text3>5 min read</Text3>
                </Info>
                <Title1>
                  <Heading4>Blog title heading will go here</Heading4>
                  <Text6>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros.
                  </Text6>
                </Title1>
              </Content5>
              <Button5>
                <Button4>Read more</Button4>
                <ChevronDownIcon alt="" src="/icon--chevron-right.svg" />
              </Button5>
            </Card2>
            <Card2>
              <PlaceholderImage2
                loading="eager"
                alt=""
                src="/placeholder--image-21@2x.png"
              />
              <Content5>
                <Info>
                  <TextWrapper>
                    <Text2>Category</Text2>
                  </TextWrapper>
                  <Text3>5 min read</Text3>
                </Info>
                <Title1>
                  <Heading4>Blog title heading will go here</Heading4>
                  <Text6>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros.
                  </Text6>
                </Title1>
              </Content5>
              <Button5>
                <Button4>Read more</Button4>
                <ChevronDownIcon alt="" src="/icon--chevron-right.svg" />
              </Button5>
            </Card2>
            <Card2>
              <PlaceholderImage2
                loading="eager"
                alt=""
                src="/placeholder--image-21@2x.png"
              />
              <Content5>
                <Info>
                  <TextWrapper>
                    <Text2>Category</Text2>
                  </TextWrapper>
                  <Text3>5 min read</Text3>
                </Info>
                <Title1>
                  <Heading4>Blog title heading will go here</Heading4>
                  <Text6>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros.
                  </Text6>
                </Title1>
              </Content5>
              <Button5>
                <Button4>Read more</Button4>
                <ChevronDownIcon alt="" src="/icon--chevron-right.svg" />
              </Button5>
            </Card2>
          </Content6>
        </Blogs1>
      </Blog>
      <Cta>
        <Content7>
          <Heading5>Sign up for our newsletter</Heading5>
          <Text7>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text7>
        </Content7>
        <Actions>
          <Form>
            <TextInput>
              <Placeholder placeholder="Enter your email" type="text" />
            </TextInput>
            <Button7>
              <Button6>Subscribe</Button6>
            </Button7>
          </Form>
          <Text8>
            {`By clicking Sign Up you're confirming that you agree with our `}
            <TermsAndConditions>Terms and Conditions</TermsAndConditions>.
          </Text8>
        </Actions>
      </Cta>
      <Blog2>
        <Title2>
          <SectionTitle1>
            <Heading6>Category name</Heading6>
            <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
          </SectionTitle1>
          <Button9>
            <Button8>View all</Button8>
          </Button9>
        </Title2>
        <Row>
          <Card2>
            <PlaceholderImage2
              loading="eager"
              alt=""
              src="/placeholder--image-21@2x.png"
            />
            <Content5>
              <Info>
                <TextWrapper>
                  <Text2>Category</Text2>
                </TextWrapper>
                <Text3>5 min read</Text3>
              </Info>
              <Title3>
                <Heading4>Blog title heading will go here</Heading4>
                <Text6>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros.
                </Text6>
              </Title3>
            </Content5>
            <Button5>
              <Button4>Read more</Button4>
              <ChevronDownIcon
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button5>
          </Card2>
          <Card2>
            <PlaceholderImage2
              loading="eager"
              alt=""
              src="/placeholder--image-21@2x.png"
            />
            <Content5>
              <Info>
                <TextWrapper>
                  <Text2>Category</Text2>
                </TextWrapper>
                <Text3>5 min read</Text3>
              </Info>
              <Title3>
                <Heading4>Blog title heading will go here</Heading4>
                <Text6>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros.
                </Text6>
              </Title3>
            </Content5>
            <Button5>
              <Button4>Read more</Button4>
              <ChevronDownIcon
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button5>
          </Card2>
          <Card2>
            <PlaceholderImage2
              loading="eager"
              alt=""
              src="/placeholder--image-21@2x.png"
            />
            <Content5>
              <Info>
                <TextWrapper>
                  <Text2>Category</Text2>
                </TextWrapper>
                <Text3>5 min read</Text3>
              </Info>
              <Title3>
                <Heading4>Blog title heading will go here</Heading4>
                <Text6>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros.
                </Text6>
              </Title3>
            </Content5>
            <Button5>
              <Button4>Read more</Button4>
              <ChevronDownIcon alt="" src="/icon--chevron-right.svg" />
            </Button5>
          </Card2>
        </Row>
      </Blog2>
      <Blog2>
        <Title2>
          <SectionTitle1>
            <Heading6>Category name</Heading6>
            <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
          </SectionTitle1>
          <Button9>
            <Button8>View all</Button8>
          </Button9>
        </Title2>
        <Row>
          <Card2>
            <PlaceholderImage2
              loading="eager"
              alt=""
              src="/placeholder--image-21@2x.png"
            />
            <Content5>
              <Info>
                <TextWrapper>
                  <Text2>Category</Text2>
                </TextWrapper>
                <Text3>5 min read</Text3>
              </Info>
              <Title3>
                <Heading4>Blog title heading will go here</Heading4>
                <Text6>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros.
                </Text6>
              </Title3>
            </Content5>
            <Button5>
              <Button4>Read more</Button4>
              <ChevronDownIcon
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button5>
          </Card2>
          <Card2>
            <PlaceholderImage2
              loading="eager"
              alt=""
              src="/placeholder--image-21@2x.png"
            />
            <Content5>
              <Info>
                <TextWrapper>
                  <Text2>Category</Text2>
                </TextWrapper>
                <Text3>5 min read</Text3>
              </Info>
              <Title3>
                <Heading4>Blog title heading will go here</Heading4>
                <Text6>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros.
                </Text6>
              </Title3>
            </Content5>
            <Button5>
              <Button4>Read more</Button4>
              <ChevronDownIcon
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button5>
          </Card2>
          <Card2>
            <PlaceholderImage2
              loading="eager"
              alt=""
              src="/placeholder--image-21@2x.png"
            />
            <Content5>
              <Info>
                <TextWrapper>
                  <Text2>Category</Text2>
                </TextWrapper>
                <Text3>5 min read</Text3>
              </Info>
              <Title3>
                <Heading4>Blog title heading will go here</Heading4>
                <Text6>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros.
                </Text6>
              </Title3>
            </Content5>
            <Button5>
              <Button4>Read more</Button4>
              <ChevronDownIcon alt="" src="/icon--chevron-right.svg" />
            </Button5>
          </Card2>
        </Row>
      </Blog2>
      <Blog2>
        <Title2>
          <SectionTitle1>
            <Heading6>Category name</Heading6>
            <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
          </SectionTitle1>
          <Button9>
            <Button8>View all</Button8>
          </Button9>
        </Title2>
        <Row>
          <Card2>
            <PlaceholderImage2
              loading="eager"
              alt=""
              src="/placeholder--image-21@2x.png"
            />
            <Content5>
              <Info>
                <TextWrapper>
                  <Text2>Category</Text2>
                </TextWrapper>
                <Text3>5 min read</Text3>
              </Info>
              <Title3>
                <Heading4>Blog title heading will go here</Heading4>
                <Text6>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros.
                </Text6>
              </Title3>
            </Content5>
            <Button5>
              <Button4>Read more</Button4>
              <ChevronDownIcon
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button5>
          </Card2>
          <Card2>
            <PlaceholderImage2
              loading="eager"
              alt=""
              src="/placeholder--image-21@2x.png"
            />
            <Content5>
              <Info>
                <TextWrapper>
                  <Text2>Category</Text2>
                </TextWrapper>
                <Text3>5 min read</Text3>
              </Info>
              <Title3>
                <Heading4>Blog title heading will go here</Heading4>
                <Text6>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros.
                </Text6>
              </Title3>
            </Content5>
            <Button5>
              <Button4>Read more</Button4>
              <ChevronDownIcon
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button5>
          </Card2>
          <Card2>
            <PlaceholderImage2
              loading="eager"
              alt=""
              src="/placeholder--image-21@2x.png"
            />
            <Content5>
              <Info>
                <TextWrapper>
                  <Text2>Category</Text2>
                </TextWrapper>
                <Text3>5 min read</Text3>
              </Info>
              <Title3>
                <Heading4>Blog title heading will go here</Heading4>
                <Text6>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros.
                </Text6>
              </Title3>
            </Content5>
            <Button5>
              <Button4>Read more</Button4>
              <ChevronDownIcon
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button5>
          </Card2>
        </Row>
      </Blog2>
      <Cta1>
        <Column4>
          <Content8>
            <Heading7>
              Invite the visitor to try your product or service
            </Heading7>
            <Text9>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique.
            </Text9>
          </Content8>
          <Actions1>
            <Button10>
              <Button2>Get started</Button2>
            </Button10>
            <Button12>
              <Button11>Learn more</Button11>
            </Button12>
          </Actions1>
        </Column4>
        <PlaceholderImage3
          loading="eager"
          alt=""
          src="/placeholder--image-10@2x.png"
        />
      </Cta1>
      <Footer>
        <Content9>
          <Newsletter>
            <LogoIcon1 loading="eager" alt="" src="/logo.svg" />
            <Text10>
              Join our newsletter to stay up to date on features and releases.
            </Text10>
            <Actions2>
              <Form1>
                <TextInput1>
                  <Placeholder1 placeholder="Enter your email" type="text" />
                </TextInput1>
                <Button14>
                  <Button13>Subscribe</Button13>
                </Button14>
              </Form1>
              <Text11>
                {`By subscribing you agree to with our `}
                <TermsAndConditions>Privacy Policy</TermsAndConditions> and
                provide consent to receive updates from our company.
              </Text11>
            </Actions2>
          </Newsletter>
          <Links>
            <Column5>
              <ColumnOne>Column One</ColumnOne>
              <FooterLinks>
                <Link1>
                  <Link>Link One</Link>
                </Link1>
                <Link1>
                  <Link>Link Two</Link>
                </Link1>
                <Link1>
                  <Link>Link Three</Link>
                </Link1>
                <Link1>
                  <Link>Link Four</Link>
                </Link1>
                <Link1>
                  <Link>Link Five</Link>
                </Link1>
              </FooterLinks>
            </Column5>
            <Column5>
              <ColumnOne>Column Two</ColumnOne>
              <FooterLinks>
                <Link1>
                  <Link>Link Six</Link>
                </Link1>
                <Link1>
                  <Link>Link Seven</Link>
                </Link1>
                <Link1>
                  <Link>Link Eight</Link>
                </Link1>
                <Link1>
                  <Link>Link Nine</Link>
                </Link1>
                <Link1>
                  <Link>Link Ten</Link>
                </Link1>
              </FooterLinks>
            </Column5>
            <Column6>
              <ColumnOne>Follow Us</ColumnOne>
              <SocialLinks>
                <Link2>
                  <ChevronDownIcon
                    loading="eager"
                    alt=""
                    src="/icon--facebook.svg"
                  />
                  <Facebook>Facebook</Facebook>
                </Link2>
                <Link2>
                  <ChevronDownIcon
                    loading="eager"
                    alt=""
                    src="/icon--instagram.svg"
                  />
                  <Instagram>Instagram</Instagram>
                </Link2>
                <Link2>
                  <ChevronDownIcon
                    loading="eager"
                    alt=""
                    src="/icon--twitter.svg"
                  />
                  <Twitter>Twitter</Twitter>
                </Link2>
                <Link2>
                  <ChevronDownIcon
                    loading="eager"
                    alt=""
                    src="/icon--linkedin.svg"
                  />
                  <Linkedin>LinkedIn</Linkedin>
                </Link2>
              </SocialLinks>
            </Column6>
          </Links>
        </Content9>
        <DividerParent>
          <Divider />
          <Row1>
            <Text12>© 2023 Relume. All rights reserved.</Text12>
            <LinkParent>
              <Link3>Privacy Policy</Link3>
              <Link4>Terms of Service</Link4>
              <Link4>Cookies Settings</Link4>
            </LinkParent>
          </Row1>
        </DividerParent>
      </Footer>
    </BlogRoot>
  );
};

export default Blog1;
