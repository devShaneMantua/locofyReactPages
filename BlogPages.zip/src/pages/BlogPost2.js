import Navbar from "../components/Navbar";
import Content3 from "../components/Content3";
import Content2 from "../components/Content2";
import styled from "styled-components";
import Content1 from "../components/Content1";
import Blog6 from "../components/Blog";
import Footer from "../components/Footer";

const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const BlogPostHeader = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  @media screen and (max-width: 1350px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const BlogPostRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const BlogPost2 = () => {
  return (
    <BlogPostRoot>
      <Navbar />
      <BlogPostHeader>
        <Content>
          <Content3 />
          <Content2 />
        </Content>
      </BlogPostHeader>
      <Content1 />
      <Blog6 />
      <Footer />
    </BlogPostRoot>
  );
};

export default BlogPost2;
