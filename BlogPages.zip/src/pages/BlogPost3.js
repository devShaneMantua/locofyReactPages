import Navbar from "../components/Navbar";
import BlogPostHeader2 from "../components/BlogPostHeader2";
import Content4 from "../components/Content4";
import CTA2 from "../components/CTA2";
import Blog11 from "../components/Blog1";
import Footer from "../components/Footer";
import styled from "styled-components";

const BlogPostRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const BlogPost = () => {
  return (
    <BlogPostRoot>
      <Navbar />
      <BlogPostHeader2 />
      <Content4 />
      <CTA2 propWidth="unset" />
      <Blog11 />
      <Footer />
    </BlogPostRoot>
  );
};

export default BlogPost;
