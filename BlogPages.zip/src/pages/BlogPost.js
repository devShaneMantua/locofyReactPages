import Navbar from "../components/Navbar";
import BlogPostHeader from "../components/BlogPostHeader";
import Content from "../components/Content";
import Category from "../components/Category";
import styled from "styled-components";
import Blog from "../components/Blog";
import Footer from "../components/Footer";

const Category1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xl) 0px 0px;
  box-sizing: border-box;
  min-width: 497px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const Content1 = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 88px 192px;
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex-wrap: wrap;
    padding-bottom: 125px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 1125px) {
    padding-bottom: 81px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-25xl);
    padding-right: var(--padding-25xl);
    padding-bottom: 53px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-xl);
    padding-right: var(--padding-xl);
    box-sizing: border-box;
  }
`;
const BlogPostRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const BlogPost3 = () => {
  return (
    <BlogPostRoot>
      <Navbar />
      <BlogPostHeader />
      <Content1>
        <Content />
        <Category1>
          <Category />
        </Category1>
      </Content1>
      <Blog heading="Related posts" />
      <Footer />
    </BlogPostRoot>
  );
};

export default BlogPost3;
