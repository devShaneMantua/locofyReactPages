import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--text-small-normal: Roboto;

/* font sizes */
--text-small-normal-size: 14px;
--font-size-xs: 12px;
--text-regular-normal-size: 16px;
--heading-h5-size: 24px;
--text-medium-normal-size: 18px;
--heading-h2-size: 48px;
--heading-h1-size: 56px;
--heading-h3-size: 40px;

/* Colors */
--white: #fff;
--black: #000;
--color-dimgray: #505050;
--light-grey: #f4f4f4;

/* Gaps */
--gap-45xl: 64px;
--gap-13xl: 32px;
--gap-5xl: 24px;
--gap-base: 16px;
--gap-61xl: 80px;
--gap-5xs: 8px;
--gap-29xl: 48px;
--gap-xl: 20px;
--gap-9xs: 4px;

/* Paddings */
--padding-61xl: 80px;
--padding-xs: 12px;
--padding-5xl: 24px;
--padding-93xl: 112px;
--padding-45xl: 64px;
--padding-base: 16px;
--padding-9xs: 4px;
--padding-5xs: 8px;
--padding-xl: 20px;

}
`;
