import styled from "styled-components";

const Heading = styled.b`
  width: 616px;
  position: relative;
  line-height: 120%;
  display: inline-block;
`;
const Paragraph = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-base);
`;
const RichText = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-5xl);
`;
const PlaceholderImage = styled.img`
  width: 616px;
  position: relative;
  height: 640px;
  object-fit: cover;
`;
const Container = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-61xl);
`;
const ContentRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const Content6 = ({ heading }) => {
  return (
    <ContentRoot>
      <Container>
        <Content1>
          <Heading>{heading}</Heading>
          <RichText>
            <Content>
              <Paragraph>
                Morbi sed imperdiet in ipsum, adipiscing elit dui lectus. Tellus
                id scelerisque est ultricies ultricies. Duis est sit sed leo
                nisl, blandit elit sagittis. Quisque tristique consequat quam
                sed. Nisl at scelerisque amet nulla purus habitasse.
              </Paragraph>
            </Content>
            <Content>
              <Paragraph>
                Nunc sed faucibus bibendum feugiat sed interdum. Ipsum egestas
                condimentum mi massa. In tincidunt pharetra consectetur sed duis
                facilisis metus. Etiam egestas in nec sed et. Quis lobortis at
                sit dictum eget nibh tortor commodo cursus.
              </Paragraph>
            </Content>
            <Content>
              <Paragraph>
                Odio felis sagittis, morbi feugiat tortor vitae feugiat fusce
                aliquet. Nam elementum urna nisi aliquet erat dolor enim. Ornare
                id morbi eget ipsum. Aliquam senectus neque ut id eget
                consectetur dictum. Donec posuere pharetra odio consequat
                scelerisque et, nunc tortor. Nulla adipiscing erat a erat.
                Condimentum lorem posuere gravida enim posuere cursus diam.
              </Paragraph>
            </Content>
          </RichText>
        </Content1>
        <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
      </Container>
    </ContentRoot>
  );
};

export default Content6;
