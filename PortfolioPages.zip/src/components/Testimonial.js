import styled from "styled-components";

const VectorIcon = styled.img`
  width: 20px;
  position: relative;
  height: 18.9px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const AvatarImageIcon = styled.img`
  width: 56px;
  position: relative;
  border-radius: 50%;
  height: 56px;
  object-fit: cover;
`;
const NameSurname = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const PositionCompanyName = styled.div`
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider = styled.div`
  width: 1px;
  position: relative;
  border-right: 1px solid var(--black);
  box-sizing: border-box;
  height: 62px;
`;
const WebflowBlack = styled.img`
  width: 120px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xl);
  text-align: left;
  font-size: var(--text-regular-normal-size);
`;
const Content = styled.div`
  width: 768px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const TestimonialRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  text-align: center;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const Testimonial = () => {
  return (
    <TestimonialRoot>
      <Content>
        <Stars>
          <VectorIcon alt="" src="/vector.svg" />
          <VectorIcon alt="" src="/vector.svg" />
          <VectorIcon alt="" src="/vector.svg" />
          <VectorIcon alt="" src="/vector.svg" />
          <VectorIcon alt="" src="/vector.svg" />
        </Stars>
        <Quote>
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat."
        </Quote>
        <Avatar>
          <AvatarImageIcon alt="" src="/avatar-image@2x.png" />
          <AvatarContent>
            <NameSurname>Name Surname</NameSurname>
            <PositionCompanyName>Position, Company name</PositionCompanyName>
          </AvatarContent>
          <Divider />
          <WebflowBlack alt="" src="/webflow--black.svg" />
        </Avatar>
      </Content>
    </TestimonialRoot>
  );
};

export default Testimonial;
