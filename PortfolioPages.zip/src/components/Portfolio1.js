import styled from "styled-components";

const Portfolio = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 640px;
  flex-shrink: 0;
  object-fit: cover;
`;
const Heading1 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const Tag = styled.div`
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-9xs) var(--padding-5xs);
`;
const Tags = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--text-small-normal-size);
`;
const Content1 = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-regular-normal-size);
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
`;
const Card = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const PortfolioList = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  font-size: var(--text-regular-normal-size);
`;
const Content3 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  text-align: left;
  font-size: var(--heading-h5-size);
`;
const PortfolioRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const Portfolio1 = () => {
  return (
    <PortfolioRoot>
      <SectionTitle>
        <Portfolio>Portfolio</Portfolio>
        <Content>
          <Heading>Next Project</Heading>
          <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
        </Content>
      </SectionTitle>
      <Content3>
        <PortfolioList>
          <Row>
            <Card>
              <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
              <Content2>
                <Content1>
                  <Heading1>Project name here</Heading1>
                  <Tags>
                    <Tag>
                      <Portfolio>Tag one</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag two</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag three</Portfolio>
                    </Tag>
                  </Tags>
                </Content1>
                <Column>
                  <Text2>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros elementum tristique. Duis
                    cursus, mi quis viverra ornare, eros dolor interdum nulla,
                    ut commodo diam libero vitae erat.
                  </Text2>
                </Column>
              </Content2>
            </Card>
          </Row>
        </PortfolioList>
        <Button1>
          <Button>View all</Button>
        </Button1>
      </Content3>
    </PortfolioRoot>
  );
};

export default Portfolio1;
