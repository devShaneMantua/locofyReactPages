import styled from "styled-components";

const Text1 = styled.b`
  position: relative;
  line-height: 150%;
`;
const Text2 = styled.div`
  position: relative;
  line-height: 150%;
`;
const ListItem = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const ListItem1 = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Text3 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const List = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Paragraph = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-base);
`;
const RichText = styled.div`
  width: 764px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Content1 = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-29xl);
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 700px;
  flex-shrink: 0;
  object-fit: cover;
`;
const Gallery = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const ContentRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const Content4 = () => {
  return (
    <ContentRoot>
      <Content1>
        <List>
          <ListItem>
            <Text1>Client</Text1>
            <Text2>Full name</Text2>
          </ListItem>
          <ListItem>
            <Text1>Date</Text1>
            <Text2>March 2023</Text2>
          </ListItem>
          <ListItem1>
            <Text1>Role</Text1>
            <Text2>Role name</Text2>
          </ListItem1>
          <ListItem1>
            <Text1>Website</Text1>
            <Text3>www.relume.io</Text3>
          </ListItem1>
        </List>
        <RichText>
          <Content>
            <Paragraph>
              Morbi sed imperdiet in ipsum, adipiscing elit dui lectus. Tellus
              id scelerisque est ultricies ultricies. Duis est sit sed leo nisl,
              blandit elit sagittis. Quisque tristique consequat quam sed. Nisl
              at scelerisque amet nulla purus habitasse.
            </Paragraph>
          </Content>
          <Content>
            <Paragraph>
              Nunc sed faucibus bibendum feugiat sed interdum. Ipsum egestas
              condimentum mi massa. In tincidunt pharetra consectetur sed duis
              facilisis metus. Etiam egestas in nec sed et. Quis lobortis at sit
              dictum eget nibh tortor commodo cursus.
            </Paragraph>
          </Content>
          <Content>
            <Paragraph>
              Odio felis sagittis, morbi feugiat tortor vitae feugiat fusce
              aliquet. Nam elementum urna nisi aliquet erat dolor enim. Ornare
              id morbi eget ipsum. Aliquam senectus neque ut id eget consectetur
              dictum. Donec posuere pharetra odio consequat scelerisque et, nunc
              tortor. Nulla adipiscing erat a erat. Condimentum lorem posuere
              gravida enim posuere cursus diam.
            </Paragraph>
          </Content>
        </RichText>
      </Content1>
      <Gallery>
        <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
      </Gallery>
    </ContentRoot>
  );
};

export default Content4;
