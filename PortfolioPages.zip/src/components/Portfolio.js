import styled from "styled-components";
import Card from "./Card";

const Portfolio1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Row = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const PortfolioList = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Content1 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  text-align: left;
`;
const PortfolioRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const Portfolio = () => {
  return (
    <PortfolioRoot>
      <SectionTitle>
        <Portfolio1>Portfolio</Portfolio1>
        <Content>
          <Heading>Related Projects</Heading>
          <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
        </Content>
      </SectionTitle>
      <Content1>
        <PortfolioList>
          <Row>
            <Card placeholderImage="/placeholder--image@2x.png" />
            <Card placeholderImage="/placeholder--image@2x.png" />
            <Card placeholderImage="/placeholder--image@2x.png" />
          </Row>
        </PortfolioList>
        <Button1>
          <Button>View all</Button>
        </Button1>
      </Content1>
    </PortfolioRoot>
  );
};

export default Portfolio;
