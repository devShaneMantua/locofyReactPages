import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 600px;
  flex-shrink: 0;
  object-fit: cover;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const TagOne = styled.div`
  position: relative;
  line-height: 150%;
`;
const Tag = styled.div`
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-9xs) var(--padding-5xs);
`;
const Tags = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--text-small-normal-size);
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Text2 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Text3 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const ListItem = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const ListItem1 = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Text4 = styled.div`
  align-self: stretch;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const List = styled.div`
  width: 464px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-61xl) var(--padding-45xl);
`;
const PortfolioHeaderRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--heading-h1-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const PortfolioHeader2 = () => {
  return (
    <PortfolioHeaderRoot>
      <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
      <Content2>
        <Content1>
          <Column>
            <Heading>Project name here</Heading>
            <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. `}</Text1>
            <Tags>
              <Tag>
                <TagOne>Tag one</TagOne>
              </Tag>
              <Tag>
                <TagOne>Tag two</TagOne>
              </Tag>
              <Tag>
                <TagOne>Tag three</TagOne>
              </Tag>
            </Tags>
          </Column>
          <List>
            <Content>
              <ListItem>
                <Text2>Client</Text2>
                <Text3>Full name</Text3>
              </ListItem>
              <ListItem>
                <Text2>Date</Text2>
                <Text3>March 2023</Text3>
              </ListItem>
            </Content>
            <Content>
              <ListItem1>
                <Text2>Role</Text2>
                <Text3>Role name</Text3>
              </ListItem1>
              <ListItem1>
                <Text2>Website</Text2>
                <Text4>www.relume.io</Text4>
              </ListItem1>
            </Content>
          </List>
        </Content1>
      </Content2>
    </PortfolioHeaderRoot>
  );
};

export default PortfolioHeader2;
