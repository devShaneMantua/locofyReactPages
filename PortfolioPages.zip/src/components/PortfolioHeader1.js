import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 600px;
  flex-shrink: 0;
  object-fit: cover;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const TagOne = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Tag = styled.div`
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-9xs) var(--padding-5xs);
`;
const Tags = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--text-small-normal-size);
`;
const Column = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Paragraph = styled.div`
  align-self: stretch;
  flex: 1;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-61xl) var(--padding-45xl);
`;
const PortfolioHeaderRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--heading-h1-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const PortfolioHeader1 = () => {
  return (
    <PortfolioHeaderRoot>
      <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
      <Content1>
        <Content>
          <Column>
            <Heading>Project name here</Heading>
            <Tags>
              <Tag>
                <TagOne>Tag one</TagOne>
              </Tag>
              <Tag>
                <TagOne>Tag two</TagOne>
              </Tag>
              <Tag>
                <TagOne>Tag three</TagOne>
              </Tag>
            </Tags>
          </Column>
          <Paragraph>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla, ut commodo diam libero
            vitae erat.
          </Paragraph>
        </Content>
      </Content1>
    </PortfolioHeaderRoot>
  );
};

export default PortfolioHeader1;
