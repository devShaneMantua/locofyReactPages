import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  position: relative;
  height: 27px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-xl);
`;
const IconMenu = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Icon = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Column1 = styled.div`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xl);
`;
const Container = styled.div`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-13xl);
`;
const NavbarRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  border-bottom: 1px solid var(--black);
  box-sizing: border-box;
  height: 72px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0px var(--padding-45xl);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--white);
  font-family: var(--text-small-normal);
`;

const Navbar = () => {
  return (
    <NavbarRoot>
      <Container>
        <Column>
          <LogoIcon alt="" src="/logo.svg" />
        </Column>
        <Column1>
          <Button1>
            <Button>Button</Button>
          </Button1>
          <Icon>
            <IconMenu alt="" src="/icon--menu.svg" />
          </Icon>
        </Column1>
      </Container>
    </NavbarRoot>
  );
};

export default Navbar;
