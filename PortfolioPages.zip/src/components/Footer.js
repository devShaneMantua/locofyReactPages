import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  position: relative;
  height: 27px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Logo = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Link = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Links = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Column = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Placeholder = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--black);
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  color: var(--color-dimgray);
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-xs);
  line-height: 150%;
`;
const Actions = styled.div`
  align-self: stretch;
  width: 400px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  background-color: var(--black);
  height: 1px;
`;
const Link1 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const FooterLinks = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Credits = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-normal-size);
`;
const FooterRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl);
  box-sizing: border-box;
  gap: var(--gap-45xl);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const Footer = () => {
  return (
    <FooterRoot>
      <Content>
        <Column>
          <Logo>
            <LogoIcon alt="" src="/logo.svg" />
          </Logo>
          <Links>
            <Link>Link One</Link>
            <Link>Link Two</Link>
            <Link>Link Three</Link>
            <Link>Link Four</Link>
            <Link>Link Five</Link>
          </Links>
        </Column>
        <Actions>
          <Heading>Subscribe</Heading>
          <Form>
            <TextInput>
              <Placeholder>Enter your email</Placeholder>
            </TextInput>
            <Button1>
              <Button>Subscribe</Button>
            </Button1>
          </Form>
          <Text1>
            {`By subscribing you agree to with our `}
            <PrivacyPolicy>Privacy Policy</PrivacyPolicy>
          </Text1>
        </Actions>
      </Content>
      <Credits>
        <Divider />
        <Content>
          <FooterLinks>
            <Link1>Privacy Policy</Link1>
            <Link1>Terms of Service</Link1>
            <Link1>Cookies Settings</Link1>
          </FooterLinks>
          <Button>© 2023 Relume. All rights reserved.</Button>
        </Content>
      </Credits>
    </FooterRoot>
  );
};

export default Footer;
