import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 400px;
  flex-shrink: 0;
  object-fit: cover;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Text2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const TagOne = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Tag = styled.div`
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-9xs) var(--padding-5xs);
`;
const Tags = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
  gap: var(--gap-5xs);
  font-size: var(--text-small-normal-size);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xl) 0px 0px;
  font-size: var(--text-regular-normal-size);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const CardRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const Card = ({ placeholderImage }) => {
  return (
    <CardRoot>
      <PlaceholderImage alt="" src={placeholderImage} />
      <Content>
        <Text2>
          <Heading>Project name here</Heading>
          <Text1>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros.
          </Text1>
        </Text2>
        <Tags>
          <Tag>
            <TagOne>Tag one</TagOne>
          </Tag>
          <Tag>
            <TagOne>Tag two</TagOne>
          </Tag>
          <Tag>
            <TagOne>Tag three</TagOne>
          </Tag>
        </Tags>
        <Actions>
          <Button1>
            <Button>View project</Button>
            <IconChevronRight alt="" src="/icon--chevron-right.svg" />
          </Button1>
        </Actions>
      </Content>
    </CardRoot>
  );
};

export default Card;
