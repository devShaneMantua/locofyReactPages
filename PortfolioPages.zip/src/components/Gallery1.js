import styled from "styled-components";

const PlaceholderImage = styled.img`
  width: 640px;
  position: relative;
  height: 640px;
  object-fit: cover;
`;
const PlaceholderImage1 = styled.img`
  width: 304px;
  position: relative;
  height: 304px;
  object-fit: cover;
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const GalleryRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
`;

const Gallery1 = () => {
  return (
    <GalleryRoot>
      <Row>
        <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
        <Column>
          <Row>
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
          </Row>
          <Row>
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
          </Row>
        </Column>
      </Row>
    </GalleryRoot>
  );
};

export default Gallery1;
