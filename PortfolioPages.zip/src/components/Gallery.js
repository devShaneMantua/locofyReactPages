import styled from "styled-components";

const PlaceholderImage = styled.img`
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 640px;
  object-fit: cover;
`;
const Row = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const PlaceholderImage1 = styled.img`
  width: 1312px;
  position: relative;
  height: 640px;
  object-fit: cover;
`;
const Content = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const GalleryRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
`;

const Gallery = () => {
  return (
    <GalleryRoot>
      <Content>
        <Row>
          <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
          <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
        </Row>
        <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
        <Row>
          <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
          <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
        </Row>
      </Content>
    </GalleryRoot>
  );
};

export default Gallery;
