import styled from "styled-components";

const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const TagOne = styled.div`
  position: relative;
  line-height: 150%;
`;
const Tag = styled.div`
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-9xs) var(--padding-5xs);
`;
const Tags = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-5xs);
  text-align: left;
  font-size: var(--text-small-normal-size);
`;
const Content = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 600px;
  flex-shrink: 0;
  object-fit: cover;
`;
const PortfolioHeaderRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: center;
  font-size: var(--heading-h1-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const PortfolioHeader = () => {
  return (
    <PortfolioHeaderRoot>
      <Content>
        <Heading>Project name here</Heading>
        <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. `}</Text1>
        <Tags>
          <Tag>
            <TagOne>Tag one</TagOne>
          </Tag>
          <Tag>
            <TagOne>Tag two</TagOne>
          </Tag>
          <Tag>
            <TagOne>Tag three</TagOne>
          </Tag>
        </Tags>
      </Content>
      <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
    </PortfolioHeaderRoot>
  );
};

export default PortfolioHeader;
