import Navbar from "../components/Navbar";
import styled from "styled-components";
import Content3 from "../components/Content3";
import Content2 from "../components/Content2";
import Testimonial1 from "../components/Testimonial1";
import Portfolio from "../components/Portfolio";
import Footer from "../components/Footer";

const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  width: 642px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const TagOne = styled.div`
  position: relative;
  line-height: 150%;
`;
const Tag = styled.div`
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-9xs) var(--padding-5xs);
`;
const Tags = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--text-small-normal-size);
  color: var(--black);
`;
const Column = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Text2 = styled.b`
  position: relative;
  line-height: 150%;
`;
const ListItem = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const ListItem1 = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Text3 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const List = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: flex-start;
  gap: var(--gap-61xl);
`;
const PortfolioHeader = styled.div`
  width: 1440px;
  height: 900px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  background-image: url("/portfolio-header--8@3x.png");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
`;
const PortfolioPageRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--heading-h1-size);
  color: var(--white);
  font-family: var(--text-small-normal);
`;

const PortfolioPage2 = () => {
  return (
    <PortfolioPageRoot>
      <Navbar />
      <PortfolioHeader>
        <Content1>
          <Column>
            <Heading>Project name here</Heading>
            <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. `}</Text1>
            <Tags>
              <Tag>
                <TagOne>Tag one</TagOne>
              </Tag>
              <Tag>
                <TagOne>Tag two</TagOne>
              </Tag>
              <Tag>
                <TagOne>Tag three</TagOne>
              </Tag>
            </Tags>
          </Column>
          <List>
            <Content>
              <ListItem>
                <Text2>Client</Text2>
                <TagOne>Full name</TagOne>
              </ListItem>
              <ListItem>
                <Text2>Date</Text2>
                <TagOne>March 2023</TagOne>
              </ListItem>
            </Content>
            <Content>
              <ListItem1>
                <Text2>Role</Text2>
                <TagOne>Role name</TagOne>
              </ListItem1>
              <ListItem1>
                <Text2>Website</Text2>
                <Text3>www.relume.io</Text3>
              </ListItem1>
            </Content>
          </List>
        </Content1>
      </PortfolioHeader>
      <Content3 heading="The opportunity" />
      <Content2 />
      <Content3 heading="The outcome" />
      <Testimonial1 />
      <Portfolio />
      <Footer />
    </PortfolioPageRoot>
  );
};

export default PortfolioPage2;
