import Navbar from "../components/Navbar";
import PortfolioHeader1 from "../components/PortfolioHeader1";
import styled from "styled-components";
import Gallery from "../components/Gallery";
import Footer from "../components/Footer";

const PlaceholderImage = styled.img`
  width: 1312px;
  position: relative;
  height: 640px;
  object-fit: cover;
`;
const PlaceholderImage1 = styled.img`
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 640px;
  object-fit: cover;
`;
const Row = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Content = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Gallery = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
`;
const Heading = styled.b`
  flex: 1;
  position: relative;
  line-height: 120%;
`;
const Paragraph = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-base);
`;
const RichText = styled.div`
  width: 764px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-regular-normal-size);
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-61xl);
`;
const Portfolio = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading1 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const PlaceholderImage2 = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 400px;
  flex-shrink: 0;
  object-fit: cover;
`;
const Heading2 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Text3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Tag = styled.div`
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-9xs) var(--padding-5xs);
`;
const Tags = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
  gap: var(--gap-5xs);
  font-size: var(--text-small-normal-size);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xl) 0px 0px;
  font-size: var(--text-regular-normal-size);
`;
const Content4 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Card = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row1 = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
`;
const PortfolioList = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
`;
const Button2 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  font-size: var(--text-regular-normal-size);
`;
const Content5 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  text-align: left;
  font-size: var(--heading-h5-size);
`;
const Portfolio1 = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: center;
  font-size: var(--text-regular-normal-size);
`;
const PortfolioPageRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--heading-h3-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const PortfolioPage3 = () => {
  return (
    <PortfolioPageRoot>
      <Navbar />
      <PortfolioHeader1 />
      <Gallery>
        <Content>
          <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
          <Row>
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
          </Row>
          <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
        </Content>
      </Gallery>
      <Gallery>
        <Content2>
          <Heading>Key heading about the project goes here</Heading>
          <RichText>
            <Content1>
              <Paragraph>
                Morbi sed imperdiet in ipsum, adipiscing elit dui lectus. Tellus
                id scelerisque est ultricies ultricies. Duis est sit sed leo
                nisl, blandit elit sagittis. Quisque tristique consequat quam
                sed. Nisl at scelerisque amet nulla purus habitasse.
              </Paragraph>
            </Content1>
            <Content1>
              <Paragraph>
                Nunc sed faucibus bibendum feugiat sed interdum. Ipsum egestas
                condimentum mi massa. In tincidunt pharetra consectetur sed duis
                facilisis metus. Etiam egestas in nec sed et. Quis lobortis at
                sit dictum eget nibh tortor commodo cursus.
              </Paragraph>
            </Content1>
            <Content1>
              <Paragraph>
                Odio felis sagittis, morbi feugiat tortor vitae feugiat fusce
                aliquet. Nam elementum urna nisi aliquet erat dolor enim. Ornare
                id morbi eget ipsum. Aliquam senectus neque ut id eget
                consectetur dictum. Donec posuere pharetra odio consequat
                scelerisque et, nunc tortor. Nulla adipiscing erat a erat.
                Condimentum lorem posuere gravida enim posuere cursus diam.
              </Paragraph>
            </Content1>
          </RichText>
        </Content2>
      </Gallery>
      <Gallery />
      <Portfolio1>
        <SectionTitle>
          <Portfolio>Portfolio</Portfolio>
          <Content3>
            <Heading1>Related Projects</Heading1>
            <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
          </Content3>
        </SectionTitle>
        <Content5>
          <PortfolioList>
            <Row1>
              <Card>
                <PlaceholderImage2 alt="" src="/placeholder--image@2x.png" />
                <Content4>
                  <Text3>
                    <Heading2>Project name here</Heading2>
                    <Text2>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Suspendisse varius enim in eros.
                    </Text2>
                  </Text3>
                  <Tags>
                    <Tag>
                      <Portfolio>Tag one</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag two</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag three</Portfolio>
                    </Tag>
                  </Tags>
                  <Actions>
                    <Button1>
                      <Button>View project</Button>
                      <IconChevronRight alt="" src="/icon--chevron-right.svg" />
                    </Button1>
                  </Actions>
                </Content4>
              </Card>
              <Card>
                <PlaceholderImage2 alt="" src="/placeholder--image@2x.png" />
                <Content4>
                  <Text3>
                    <Heading2>Project name here</Heading2>
                    <Text2>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Suspendisse varius enim in eros.
                    </Text2>
                  </Text3>
                  <Tags>
                    <Tag>
                      <Portfolio>Tag one</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag two</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag three</Portfolio>
                    </Tag>
                  </Tags>
                  <Actions>
                    <Button1>
                      <Button>View project</Button>
                      <IconChevronRight alt="" src="/icon--chevron-right.svg" />
                    </Button1>
                  </Actions>
                </Content4>
              </Card>
            </Row1>
          </PortfolioList>
          <Button2>
            <Button>View all</Button>
          </Button2>
        </Content5>
      </Portfolio1>
      <Footer />
    </PortfolioPageRoot>
  );
};

export default PortfolioPage3;
