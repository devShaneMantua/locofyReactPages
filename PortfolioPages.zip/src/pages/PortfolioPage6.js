import Navbar from "../components/Navbar";
import styled from "styled-components";
import Footer from "../components/Footer";

const PlaceholderImage = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 600px;
  flex-shrink: 0;
  object-fit: cover;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const TagOne = styled.div`
  position: relative;
  line-height: 150%;
`;
const Tag = styled.div`
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-9xs) var(--padding-5xs);
`;
const Tags = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-5xs);
  text-align: left;
  font-size: var(--text-small-normal-size);
`;
const Content = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const PortfolioHeader = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-61xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
`;
const PlaceholderImage1 = styled.img`
  width: 416px;
  position: relative;
  height: 416px;
  object-fit: cover;
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const PlaceholderImage2 = styled.img`
  width: 416px;
  position: relative;
  height: 234px;
  object-fit: cover;
`;
const Content1 = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Gallery = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
`;
const Portfolio = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const PlaceholderImage3 = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 400px;
  flex-shrink: 0;
  object-fit: cover;
`;
const Heading1 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Text3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Tags1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
  gap: var(--gap-5xs);
  font-size: var(--text-small-normal-size);
`;
const IconChevronRight = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xl) 0px 0px;
  font-size: var(--text-regular-normal-size);
`;
const Content3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Card = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const PortfolioList = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  font-size: var(--text-regular-normal-size);
`;
const Content4 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  text-align: left;
  font-size: var(--heading-h5-size);
`;
const Portfolio1 = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  font-size: var(--text-regular-normal-size);
`;
const PortfolioPageRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: center;
  font-size: var(--heading-h1-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const PortfolioPage6 = () => {
  return (
    <PortfolioPageRoot>
      <Navbar />
      <PortfolioHeader>
        <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
        <Content>
          <Heading>Project name here</Heading>
          <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. `}</Text1>
          <Tags>
            <Tag>
              <TagOne>Tag one</TagOne>
            </Tag>
            <Tag>
              <TagOne>Tag two</TagOne>
            </Tag>
            <Tag>
              <TagOne>Tag three</TagOne>
            </Tag>
          </Tags>
        </Content>
      </PortfolioHeader>
      <Gallery>
        <Content1>
          <Column>
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
          </Column>
          <Column>
            <PlaceholderImage2 alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage2 alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
          </Column>
          <Column>
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
          </Column>
        </Content1>
      </Gallery>
      <Portfolio1>
        <SectionTitle>
          <Portfolio>Portfolio</Portfolio>
          <Content2>
            <Heading>Related Projects</Heading>
            <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
          </Content2>
        </SectionTitle>
        <Content4>
          <PortfolioList>
            <Content1>
              <Card>
                <PlaceholderImage3 alt="" src="/placeholder--image@2x.png" />
                <Content3>
                  <Text3>
                    <Heading1>Project name here</Heading1>
                    <Text2>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Suspendisse varius enim in eros.
                    </Text2>
                  </Text3>
                  <Tags1>
                    <Tag>
                      <Portfolio>Tag one</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag two</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag three</Portfolio>
                    </Tag>
                  </Tags1>
                  <Actions>
                    <Button>
                      <TagOne>View project</TagOne>
                      <IconChevronRight alt="" src="/icon--chevron-right.svg" />
                    </Button>
                  </Actions>
                </Content3>
              </Card>
              <Card>
                <PlaceholderImage3 alt="" src="/placeholder--image@2x.png" />
                <Content3>
                  <Text3>
                    <Heading1>Project name here</Heading1>
                    <Text2>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Suspendisse varius enim in eros.
                    </Text2>
                  </Text3>
                  <Tags1>
                    <Tag>
                      <Portfolio>Tag one</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag two</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag three</Portfolio>
                    </Tag>
                  </Tags1>
                  <Actions>
                    <Button>
                      <TagOne>View project</TagOne>
                      <IconChevronRight alt="" src="/icon--chevron-right.svg" />
                    </Button>
                  </Actions>
                </Content3>
              </Card>
              <Card>
                <PlaceholderImage3 alt="" src="/placeholder--image@2x.png" />
                <Content3>
                  <Text3>
                    <Heading1>Project name here</Heading1>
                    <Text2>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Suspendisse varius enim in eros.
                    </Text2>
                  </Text3>
                  <Tags1>
                    <Tag>
                      <Portfolio>Tag one</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag two</Portfolio>
                    </Tag>
                    <Tag>
                      <Portfolio>Tag three</Portfolio>
                    </Tag>
                  </Tags1>
                  <Actions>
                    <Button>
                      <TagOne>View project</TagOne>
                      <IconChevronRight alt="" src="/icon--chevron-right.svg" />
                    </Button>
                  </Actions>
                </Content3>
              </Card>
            </Content1>
          </PortfolioList>
          <Button1>
            <TagOne>View all</TagOne>
          </Button1>
        </Content4>
      </Portfolio1>
      <Footer />
    </PortfolioPageRoot>
  );
};

export default PortfolioPage6;
