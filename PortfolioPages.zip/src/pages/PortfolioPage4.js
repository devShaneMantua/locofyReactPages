import Navbar from "../components/Navbar";
import PortfolioHeader from "../components/PortfolioHeader";
import Content1 from "../components/Content1";
import Content from "../components/Content";
import styled from "styled-components";
import Portfolio1 from "../components/Portfolio1";
import Footer from "../components/Footer";

const Heading = styled.b`
  flex: 1;
  position: relative;
  line-height: 120%;
`;
const Paragraph = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-base);
`;
const RichText = styled.div`
  width: 764px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-61xl);
`;
const Content2 = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
`;
const PlaceholderImage = styled.img`
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 640px;
  object-fit: cover;
`;
const Row = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const PlaceholderImage1 = styled.img`
  width: 1312px;
  position: relative;
  height: 640px;
  object-fit: cover;
`;
const Content3 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const PortfolioPageRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--heading-h3-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const PortfolioPage4 = () => {
  return (
    <PortfolioPageRoot>
      <Navbar />
      <PortfolioHeader />
      <Content1 />
      <Content />
      <Content2>
        <Content1>
          <Heading>Key heading about the project goes here</Heading>
          <RichText>
            <Content>
              <Paragraph>
                Morbi sed imperdiet in ipsum, adipiscing elit dui lectus. Tellus
                id scelerisque est ultricies ultricies. Duis est sit sed leo
                nisl, blandit elit sagittis. Quisque tristique consequat quam
                sed. Nisl at scelerisque amet nulla purus habitasse.
              </Paragraph>
            </Content>
            <Content>
              <Paragraph>
                Nunc sed faucibus bibendum feugiat sed interdum. Ipsum egestas
                condimentum mi massa. In tincidunt pharetra consectetur sed duis
                facilisis metus. Etiam egestas in nec sed et. Quis lobortis at
                sit dictum eget nibh tortor commodo cursus.
              </Paragraph>
            </Content>
            <Content>
              <Paragraph>
                Odio felis sagittis, morbi feugiat tortor vitae feugiat fusce
                aliquet. Nam elementum urna nisi aliquet erat dolor enim. Ornare
                id morbi eget ipsum. Aliquam senectus neque ut id eget
                consectetur dictum. Donec posuere pharetra odio consequat
                scelerisque et, nunc tortor. Nulla adipiscing erat a erat.
                Condimentum lorem posuere gravida enim posuere cursus diam.
              </Paragraph>
            </Content>
          </RichText>
        </Content1>
      </Content2>
      <Content2>
        <Content3>
          <Row>
            <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
          </Row>
          <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
          <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
        </Content3>
      </Content2>
      <Portfolio1 />
      <Footer />
    </PortfolioPageRoot>
  );
};

export default PortfolioPage4;
