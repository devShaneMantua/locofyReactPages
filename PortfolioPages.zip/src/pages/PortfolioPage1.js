import Navbar from "../components/Navbar";
import styled from "styled-components";
import Content4 from "../components/Content4";
import Gallery1 from "../components/Gallery1";
import Testimonial from "../components/Testimonial";
import Card from "../components/Card";
import Footer from "../components/Footer";

const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const TagOne = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Tag = styled.div`
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-9xs) var(--padding-5xs);
`;
const Tags = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-5xs);
  text-align: left;
  font-size: var(--text-small-normal-size);
  color: var(--black);
`;
const Content = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const PortfolioHeader = styled.div`
  width: 1440px;
  height: 900px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  background-image: url("/portfolio-header--8@3x.png");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
  text-align: center;
  font-size: var(--heading-h1-size);
  color: var(--white);
`;
const Heading1 = styled.b`
  width: 616px;
  position: relative;
  line-height: 120%;
  display: inline-block;
`;
const Paragraph = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-base);
`;
const RichText = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-regular-normal-size);
`;
const Content2 = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-5xl);
`;
const Content3 = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
`;
const PlaceholderImage = styled.img`
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 640px;
  object-fit: cover;
`;
const Row = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Content4 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const PlaceholderImage1 = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 700px;
  flex-shrink: 0;
  object-fit: cover;
`;
const Content5 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Row1 = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
`;
const PortfolioList = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Content6 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  text-align: left;
`;
const Portfolio = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: center;
  font-size: var(--text-regular-normal-size);
`;
const PortfolioPageRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const PortfolioPage1 = () => {
  return (
    <PortfolioPageRoot>
      <Navbar />
      <PortfolioHeader>
        <Content>
          <Heading>Project name here</Heading>
          <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. `}</Text1>
          <Tags>
            <Tag>
              <TagOne>Tag one</TagOne>
            </Tag>
            <Tag>
              <TagOne>Tag two</TagOne>
            </Tag>
            <Tag>
              <TagOne>Tag three</TagOne>
            </Tag>
          </Tags>
        </Content>
      </PortfolioHeader>
      <Content4 />
      <Content3>
        <Content2>
          <Heading1>The opportunity</Heading1>
          <RichText>
            <Content1>
              <Paragraph>
                Morbi sed imperdiet in ipsum, adipiscing elit dui lectus. Tellus
                id scelerisque est ultricies ultricies. Duis est sit sed leo
                nisl, blandit elit sagittis. Quisque tristique consequat quam
                sed. Nisl at scelerisque amet nulla purus habitasse.
              </Paragraph>
            </Content1>
            <Content1>
              <Paragraph>
                Nunc sed faucibus bibendum feugiat sed interdum. Ipsum egestas
                condimentum mi massa. In tincidunt pharetra consectetur sed duis
                facilisis metus. Etiam egestas in nec sed et. Quis lobortis at
                sit dictum eget nibh tortor commodo cursus.
              </Paragraph>
            </Content1>
            <Content1>
              <Paragraph>
                Odio felis sagittis, morbi feugiat tortor vitae feugiat fusce
                aliquet. Nam elementum urna nisi aliquet erat dolor enim. Ornare
                id morbi eget ipsum. Aliquam senectus neque ut id eget
                consectetur dictum. Donec posuere pharetra odio consequat
                scelerisque et, nunc tortor. Nulla adipiscing erat a erat.
                Condimentum lorem posuere gravida enim posuere cursus diam.
              </Paragraph>
            </Content1>
          </RichText>
        </Content2>
      </Content3>
      <Content3>
        <Content4>
          <Row>
            <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
          </Row>
        </Content4>
      </Content3>
      <Content3>
        <Content2>
          <Heading1>What we did</Heading1>
          <RichText>
            <Content1>
              <Paragraph>
                Morbi sed imperdiet in ipsum, adipiscing elit dui lectus. Tellus
                id scelerisque est ultricies ultricies. Duis est sit sed leo
                nisl, blandit elit sagittis. Quisque tristique consequat quam
                sed. Nisl at scelerisque amet nulla purus habitasse.
              </Paragraph>
            </Content1>
            <Content1>
              <Paragraph>
                Nunc sed faucibus bibendum feugiat sed interdum. Ipsum egestas
                condimentum mi massa. In tincidunt pharetra consectetur sed duis
                facilisis metus. Etiam egestas in nec sed et. Quis lobortis at
                sit dictum eget nibh tortor commodo cursus.
              </Paragraph>
            </Content1>
            <Content1>
              <Paragraph>
                Odio felis sagittis, morbi feugiat tortor vitae feugiat fusce
                aliquet. Nam elementum urna nisi aliquet erat dolor enim. Ornare
                id morbi eget ipsum. Aliquam senectus neque ut id eget
                consectetur dictum. Donec posuere pharetra odio consequat
                scelerisque et, nunc tortor. Nulla adipiscing erat a erat.
                Condimentum lorem posuere gravida enim posuere cursus diam.
              </Paragraph>
            </Content1>
          </RichText>
        </Content2>
      </Content3>
      <Content3>
        <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
      </Content3>
      <Content3>
        <Content2>
          <Heading1>The outcome</Heading1>
          <RichText>
            <Content1>
              <Paragraph>
                Morbi sed imperdiet in ipsum, adipiscing elit dui lectus. Tellus
                id scelerisque est ultricies ultricies. Duis est sit sed leo
                nisl, blandit elit sagittis. Quisque tristique consequat quam
                sed. Nisl at scelerisque amet nulla purus habitasse.
              </Paragraph>
            </Content1>
            <Content1>
              <Paragraph>
                Nunc sed faucibus bibendum feugiat sed interdum. Ipsum egestas
                condimentum mi massa. In tincidunt pharetra consectetur sed duis
                facilisis metus. Etiam egestas in nec sed et. Quis lobortis at
                sit dictum eget nibh tortor commodo cursus.
              </Paragraph>
            </Content1>
            <Content1>
              <Paragraph>
                Odio felis sagittis, morbi feugiat tortor vitae feugiat fusce
                aliquet. Nam elementum urna nisi aliquet erat dolor enim. Ornare
                id morbi eget ipsum. Aliquam senectus neque ut id eget
                consectetur dictum. Donec posuere pharetra odio consequat
                scelerisque et, nunc tortor. Nulla adipiscing erat a erat.
                Condimentum lorem posuere gravida enim posuere cursus diam.
              </Paragraph>
            </Content1>
          </RichText>
        </Content2>
      </Content3>
      <Gallery1 />
      <Testimonial />
      <Portfolio>
        <SectionTitle>
          <TagOne>Portfolio</TagOne>
          <Content5>
            <Heading>Related Projects</Heading>
            <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
          </Content5>
        </SectionTitle>
        <Content6>
          <PortfolioList>
            <Row1>
              <Card placeholderImage="/placeholder--image@2x.png" />
              <Card placeholderImage="/placeholder--image@2x.png" />
            </Row1>
          </PortfolioList>
          <Button1>
            <Button>View all</Button>
          </Button1>
        </Content6>
      </Portfolio>
      <Footer />
    </PortfolioPageRoot>
  );
};

export default PortfolioPage1;
