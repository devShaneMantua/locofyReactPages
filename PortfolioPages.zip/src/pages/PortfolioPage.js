import Navbar from "../components/Navbar";
import PortfolioHeader2 from "../components/PortfolioHeader2";
import Content6 from "../components/Content6";
import Content5 from "../components/Content5";
import styled from "styled-components";
import Testimonial1 from "../components/Testimonial1";
import Portfolio1 from "../components/Portfolio1";
import Footer from "../components/Footer";

const PlaceholderImage = styled.img`
  width: 1312px;
  position: relative;
  height: 640px;
  object-fit: cover;
`;
const PlaceholderImage1 = styled.img`
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 640px;
  object-fit: cover;
`;
const Row = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Content = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Gallery = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
`;
const PortfolioPageRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;

const PortfolioPage = () => {
  return (
    <PortfolioPageRoot>
      <Navbar />
      <PortfolioHeader2 />
      <Content6 heading="The opportunity" />
      <Content5 />
      <Content6 heading="The outcome" />
      <Gallery>
        <Content>
          <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
          <Row>
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
          </Row>
        </Content>
      </Gallery>
      <Testimonial1 />
      <Portfolio1 />
      <Footer />
    </PortfolioPageRoot>
  );
};

export default PortfolioPage;
