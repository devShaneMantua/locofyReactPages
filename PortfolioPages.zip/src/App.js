import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import PortfolioPage6 from "./pages/PortfolioPage6";
import PortfolioPage5 from "./pages/PortfolioPage5";
import PortfolioPage4 from "./pages/PortfolioPage4";
import PortfolioPage3 from "./pages/PortfolioPage3";
import PortfolioPage2 from "./pages/PortfolioPage2";
import PortfolioPage1 from "./pages/PortfolioPage1";
import PortfolioPage from "./pages/PortfolioPage";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/portfolio-page-6":
        title = "";
        metaDescription = "";
        break;
      case "/portfolio-page-5":
        title = "";
        metaDescription = "";
        break;
      case "/portfolio-page-4":
        title = "";
        metaDescription = "";
        break;
      case "/portfolio-page-3":
        title = "";
        metaDescription = "";
        break;
      case "/portfolio-page-2":
        title = "";
        metaDescription = "";
        break;
      case "/portfolio-page-1":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<PortfolioPage6 />} />
      <Route path="/portfolio-page-6" element={<PortfolioPage5 />} />
      <Route path="/portfolio-page-5" element={<PortfolioPage4 />} />
      <Route path="/portfolio-page-4" element={<PortfolioPage3 />} />
      <Route path="/portfolio-page-3" element={<PortfolioPage2 />} />
      <Route path="/portfolio-page-2" element={<PortfolioPage1 />} />
      <Route path="/portfolio-page-1" element={<PortfolioPage />} />
    </Routes>
  );
}
export default App;
