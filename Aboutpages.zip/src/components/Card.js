import styled from "styled-components";

const PlaceholderImage = styled.img`width: 294px;
  height: 294px;
  position: relative;
  object-fit: cover;
  width: ${(p) => p.placeholderImageWidth}
  height: ${(p) => p.placeholderImageHeight}
`;
const Name1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 24px;
  }
`;
const JobTitle = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const IconLinkedin = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
  min-height: ${(p) => p.propMinHeight};
`;
const IconTwitter = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
  min-height: ${(p) => p.propMinHeight1};
`;
const IconDribble = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
  min-height: ${(p) => p.propMinHeight2};
`;
const SocialIcons = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-sm);
  height: ${(p) => p.propHeight};
`;
const CardRoot = styled.div`width: 296px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 118px;
  text-align: left;
  font-size: var(--text-large-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  width: ${(p) => p.cardWidth}
  min-width: ${(p) => p.cardMinWidth}
`;

const Card = ({
  placeholderImage,
  propHeight,
  propMinHeight,
  propMinHeight1,
  propMinHeight2,
  cardWidth,
  cardMinWidth,
  placeholderImageWidth,
  placeholderImageHeight,
}) => {
  return (
    <CardRoot cardWidth={cardWidth} cardMinWidth={cardMinWidth}>
      <PlaceholderImage
        alt=""
        src={placeholderImage}
        placeholderImageWidth={placeholderImageWidth}
        placeholderImageHeight={placeholderImageHeight}
      />
      <Content>
        <Title>
          <Name1>Full name</Name1>
          <JobTitle>Job title</JobTitle>
        </Title>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique.
        </Text1>
      </Content>
      <SocialIcons propHeight={propHeight}>
        <IconLinkedin
          loading="eager"
          alt=""
          src="/icon--linkedin.svg"
          propMinHeight={propMinHeight}
        />
        <IconTwitter
          alt=""
          src="/icon--twitter.svg"
          propMinHeight1={propMinHeight1}
        />
        <IconDribble
          alt=""
          src="/icon--dribble.svg"
          propMinHeight2={propMinHeight2}
        />
      </SocialIcons>
    </CardRoot>
  );
};

export default Card;
