import styled from "styled-components";

const WebflowBlack = styled.img`
  width: 120px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const ACustomerTestimonial = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const NameSurname = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const PositionCompanyName = styled.div`
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xl);
  font-size: var(--text-regular-semi-bold-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  font-size: var(--text-regular-semi-bold-size);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
  }
`;
const ColumnRoot = styled.div`
  flex: 1;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-14xl) var(--padding-13xl)
    var(--padding-12xl);
  gap: var(--gap-29xl);
  min-width: 416px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-29xl);
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-2xl);
    padding-bottom: var(--padding-2xl);
    box-sizing: border-box;
  }
`;

const Column1 = ({ webflowBlack }) => {
  return (
    <ColumnRoot>
      <WebflowBlack loading="eager" alt="" src={webflowBlack} />
      <Content1>
        <Content>
          <ACustomerTestimonial>
            "A customer testimonial that highlights features and answers
            potential customer doubts about your product or service. Showcase
            testimonials from a similar demographic to your customers."
          </ACustomerTestimonial>
          <Avatar>
            <AvatarImageIcon
              loading="eager"
              alt=""
              src="/avatar-image2@2x.png"
            />
            <AvatarContent>
              <NameSurname>Name Surname</NameSurname>
              <PositionCompanyName>Position, Company name</PositionCompanyName>
            </AvatarContent>
          </Avatar>
        </Content>
        <Button>
          <PositionCompanyName>Read full story</PositionCompanyName>
          <IconChevronRight
            loading="eager"
            alt=""
            src="/icon--chevron-right.svg"
          />
        </Button>
      </Content1>
    </ColumnRoot>
  );
};

export default Column1;
