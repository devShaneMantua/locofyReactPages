import styled from "styled-components";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
  text-align: ${(p) => p.propTextAlign};
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
  text-align: ${(p) => p.propTextAlign1};
`;
const FooterLinks = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign2};
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const IconRelume = styled.input`
  margin: 0;
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading1 = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
  text-align: ${(p) => p.propTextAlign3};
`;
const ActionsFrame = styled.div`
  align-self: stretch;
  height: 96px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  display: inline-block;
  text-align: ${(p) => p.propTextAlign4};
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 304px;
  max-width: 100%;
`;
const Heading2 = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
  text-align: ${(p) => p.propTextAlign5};
`;
const Text1 = styled.div`
  align-self: stretch;
  height: 96px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  display: inline-block;
  text-align: ${(p) => p.propTextAlign6};
`;
const Heading3 = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
  text-align: ${(p) => p.propTextAlign7};
`;
const Text2 = styled.div`
  align-self: stretch;
  height: 96px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  display: inline-block;
  text-align: ${(p) => p.propTextAlign8};
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-29xl);
  max-width: 100%;
  font-size: var(--heading-h4-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-29xl);
  }
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding: var(--padding-54xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Layout5 = ({
  heading,
  heading1,
  heading2,
  propTextAlign,
  propTextAlign1,
  propTextAlign2,
  propTextAlign3,
  propTextAlign4,
  propTextAlign5,
  propTextAlign6,
  propTextAlign7,
  propTextAlign8,
}) => {
  return (
    <LayoutRoot>
      <SectionTitle>
        <Subheading propTextAlign={propTextAlign}>Our values</Subheading>
        <Content>
          <Heading propTextAlign1={propTextAlign1}>
            Emphasize what's important to your company
          </Heading>
          <FooterLinks propTextAlign2={propTextAlign2}>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare.
          </FooterLinks>
        </Content>
      </SectionTitle>
      <Row>
        <Column>
          <IconRelume type="checkbox" />
          <Content1>
            <Heading1 propTextAlign3={propTextAlign3}>{heading}</Heading1>
            <ActionsFrame propTextAlign4={propTextAlign4}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique. Duis cursus,
              mi quis viverra ornare, eros dolor interdum nulla.
            </ActionsFrame>
          </Content1>
        </Column>
        <Column>
          <IconRelume type="checkbox" />
          <Content1>
            <Heading2 propTextAlign5={propTextAlign5}>{heading1}</Heading2>
            <Text1 propTextAlign6={propTextAlign6}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique. Duis cursus,
              mi quis viverra ornare, eros dolor interdum nulla.
            </Text1>
          </Content1>
        </Column>
        <Column>
          <IconRelume type="checkbox" />
          <Content1>
            <Heading3 propTextAlign7={propTextAlign7}>{heading2}</Heading3>
            <Text2 propTextAlign8={propTextAlign8}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique. Duis cursus,
              mi quis viverra ornare, eros dolor interdum nulla.
            </Text2>
          </Content1>
        </Column>
      </Row>
    </LayoutRoot>
  );
};

export default Layout5;
