import styled from "styled-components";

const IconRelume = styled.img`
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const ButtonElement = styled.div`
  align-self: stretch;
  height: 72px;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  display: inline-block;
`;
const ListItem = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 192px;
`;
const ListRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;

const List = ({ heading, heading1 }) => {
  return (
    <ListRoot>
      <ListItem>
        <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
        <Heading>{heading}</Heading>
        <ButtonElement>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros.
        </ButtonElement>
      </ListItem>
      <ListItem>
        <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
        <Heading>{heading1}</Heading>
        <ButtonElement>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros.
        </ButtonElement>
      </ListItem>
    </ListRoot>
  );
};

export default List;
