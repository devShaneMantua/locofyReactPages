import styled from "styled-components";

const HighlightKey = styled.p`
  margin: 0;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-5xl);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const WebflowBlack = styled.img`
  width: 140px;
  flex: 1;
  position: relative;
  max-height: 100%;
  overflow: hidden;
`;
const Logo1 = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-sm);
  background-color: var(--light-grey);
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
const Row = styled.div`
  width: 616px;
  height: 84px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Content1 = styled.div`
  flex: 1;
  overflow-x: auto;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const LogoRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;

const Logo = () => {
  return (
    <LogoRoot>
      <Content>
        <Heading>
          <HighlightKey>Highlight key</HighlightKey>
          <HighlightKey>partnerships</HighlightKey>
        </Heading>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique.
        </Text1>
      </Content>
      <Content1>
        <Row>
          <Logo1>
            <WebflowBlack alt="" src="/webflow--black2.svg" />
          </Logo1>
          <Logo1>
            <WebflowBlack alt="" src="/webflow--black2.svg" />
          </Logo1>
        </Row>
        <Row>
          <Logo1>
            <WebflowBlack alt="" src="/relume--black.svg" />
          </Logo1>
          <Logo1>
            <WebflowBlack alt="" src="/relume--black.svg" />
          </Logo1>
        </Row>
        <Row>
          <Logo1>
            <WebflowBlack alt="" src="/webflow--black2.svg" />
          </Logo1>
          <Logo1>
            <WebflowBlack alt="" src="/webflow--black2.svg" />
          </Logo1>
        </Row>
        <Row>
          <Logo1>
            <WebflowBlack alt="" src="/relume--black.svg" />
          </Logo1>
          <Logo1>
            <WebflowBlack alt="" src="/relume--black.svg" />
          </Logo1>
        </Row>
      </Content1>
    </LogoRoot>
  );
};

export default Logo;
