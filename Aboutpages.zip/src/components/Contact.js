import styled from "styled-components";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Firstcolumnframe = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Navbarframe = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Headercontainer = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Border = styled.div`
  height: 124px;
  width: 2px;
  position: relative;
  border-right: 2px solid var(--black);
  box-sizing: border-box;
  @media screen and (max-width: 800px) {
    width: 100%;
    height: 2px;
  }
`;
const Heading1 = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Rowframe = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Link = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Dividerframe = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--text-regular-semi-bold-size);
`;
const HeadingParent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 304px;
  max-width: 100%;
  flex-shrink: 0;
`;
const TabHorizontal = styled.div`
  align-self: stretch;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
    gap: var(--gap-13xl);
  }
`;
const Border1 = styled.div`
  height: 124px;
  width: 2px;
  position: relative;
  border-right: 2px solid var(--black);
  box-sizing: border-box;
  opacity: 0;
  @media screen and (max-width: 800px) {
    width: 100%;
    height: 2px;
  }
`;
const TabsMenu = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  min-width: 500px;
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex: 1;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
    min-width: 100%;
  }
`;
const PlaceholderImage = styled.img`
  height: 440px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 476px;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const TabsMenuParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  font-size: var(--heading-h5-size);
  @media screen and (max-width: 1325px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const ContactRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Contact = () => {
  return (
    <ContactRoot>
      <Headercontainer>
        <Navbarframe>
          <Heading>Our locations</Heading>
          <Firstcolumnframe>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Firstcolumnframe>
        </Navbarframe>
      </Headercontainer>
      <TabsMenuParent>
        <TabsMenu>
          <TabHorizontal>
            <Border />
            <HeadingParent>
              <Heading1>Sydney</Heading1>
              <Dividerframe>
                <Rowframe>123 Sample St, Sydney NSW 2000 AU</Rowframe>
                <Link>View Map</Link>
              </Dividerframe>
            </HeadingParent>
          </TabHorizontal>
          <TabHorizontal>
            <Border1 />
            <HeadingParent>
              <Heading1>New York</Heading1>
              <Dividerframe>
                <Rowframe>123 Sample St, New York NY 10000 USA</Rowframe>
                <Link>View Map</Link>
              </Dividerframe>
            </HeadingParent>
          </TabHorizontal>
          <TabHorizontal>
            <Border1 />
            <HeadingParent>
              <Heading1>London</Heading1>
              <Dividerframe>
                <Rowframe>
                  123 Sample St, London W1C 1DE, United Kingdom
                </Rowframe>
                <Link>View Map</Link>
              </Dividerframe>
            </HeadingParent>
          </TabHorizontal>
        </TabsMenu>
        <PlaceholderImage alt="" src="/placeholder--image-5@2x.png" />
      </TabsMenuParent>
    </ContactRoot>
  );
};

export default Contact;
