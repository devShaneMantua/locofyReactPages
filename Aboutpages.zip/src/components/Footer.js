import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Buttoninstance = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Placeholder = styled.input`
  width: 100%;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-semi-bold-size);
  background-color: transparent;
  height: 24px;
  flex: 1;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
  min-width: 205px;
  max-width: 100%;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-smi) var(--padding-xs)
    var(--padding-2xs);
  min-width: 237px;
  max-width: 100%;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-4xl);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--font-size-xs);
`;
const Newsletter = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 500px;
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex: 1;
  }
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const ColumnOne = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 151px;
`;
const IconFacebook = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Facebook = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-xs);
`;
const Column1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 151px;
`;
const Links = styled.div`
  width: 684px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  min-width: 684px;
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex: 1;
  }
  @media screen and (max-width: 1125px) {
    min-width: 100%;
  }
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
    gap: var(--gap-21xl);
  }
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  min-height: 248px;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex-wrap: wrap;
  }
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Link3 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const Link4 = styled.div`
  flex: 1;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
  min-width: 68px;
`;
const LinkedFrames = styled.div`
  width: 345px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const Instagram = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
  }
`;
const FooterRoot = styled.footer`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding: var(--padding-33xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Footer = () => {
  return (
    <FooterRoot>
      <Content>
        <Newsletter>
          <LogoIcon loading="eager" alt="" src="/logo.svg" />
          <Buttoninstance>
            Join our newsletter to stay up to date on features and releases.
          </Buttoninstance>
          <Actions>
            <Form>
              <TextInput>
                <Placeholder placeholder="Enter your email" type="text" />
              </TextInput>
              <Button1>
                <Button>Subscribe</Button>
              </Button1>
            </Form>
            <Buttoninstance>
              {`By subscribing you agree to with our `}
              <PrivacyPolicy>Privacy Policy</PrivacyPolicy> and provide consent
              to receive updates from our company.
            </Buttoninstance>
          </Actions>
        </Newsletter>
        <Links>
          <Column>
            <ColumnOne>Column One</ColumnOne>
            <FooterLinks>
              <Link1>
                <Link>Link One</Link>
              </Link1>
              <Link1>
                <Link>Link Two</Link>
              </Link1>
              <Link1>
                <Link>Link Three</Link>
              </Link1>
              <Link1>
                <Link>Link Four</Link>
              </Link1>
              <Link1>
                <Link>Link Five</Link>
              </Link1>
            </FooterLinks>
          </Column>
          <Column>
            <ColumnOne>Column Two</ColumnOne>
            <FooterLinks>
              <Link1>
                <Link>Link Six</Link>
              </Link1>
              <Link1>
                <Link>Link Seven</Link>
              </Link1>
              <Link1>
                <Link>Link Eight</Link>
              </Link1>
              <Link1>
                <Link>Link Nine</Link>
              </Link1>
              <Link1>
                <Link>Link Ten</Link>
              </Link1>
            </FooterLinks>
          </Column>
          <Column1>
            <ColumnOne>Follow Us</ColumnOne>
            <FooterLinks>
              <Link2>
                <IconFacebook
                  loading="eager"
                  alt=""
                  src="/icon--facebook.svg"
                />
                <Facebook>Facebook</Facebook>
              </Link2>
              <Link2>
                <IconFacebook
                  loading="eager"
                  alt=""
                  src="/icon--instagram.svg"
                />
                <Facebook>Instagram</Facebook>
              </Link2>
              <Link2>
                <IconFacebook loading="eager" alt="" src="/icon--twitter.svg" />
                <Facebook>Twitter</Facebook>
              </Link2>
              <Link2>
                <IconFacebook alt="" src="/icon--linkedin.svg" />
                <Facebook>LinkedIn</Facebook>
              </Link2>
            </FooterLinks>
          </Column1>
        </Links>
      </Content>
      <Instagram>
        <Divider />
        <Row>
          <Facebook>© 2023 Relume. All rights reserved.</Facebook>
          <LinkedFrames>
            <Link3>Privacy Policy</Link3>
            <Link4>Terms of Service</Link4>
            <Link4>Cookies Settings</Link4>
          </LinkedFrames>
        </Row>
      </Instagram>
    </FooterRoot>
  );
};

export default Footer;
