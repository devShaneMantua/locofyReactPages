import styled from "styled-components";

const IconRelume = styled.input`
  margin: 0;
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Divider = styled.div`
  width: 50px;
  flex: 1;
  position: relative;
  border-right: 2px solid var(--black);
  box-sizing: border-box;
`;
const Icon1 = styled.div`
  height: 164px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h4-size);
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const LoremIpsumDolor = styled.p`
  margin: 0;
`;
const Subheading1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const SubheadingParent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-3xs);
  min-width: 343px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const ButtonRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
    gap: var(--gap-21xl);
  }
`;

const Icon = () => {
  return (
    <ButtonRoot>
      <Icon1>
        <IconRelume type="checkbox" />
        <Divider />
      </Icon1>
      <SubheadingParent>
        <Subheading>Year • Month</Subheading>
        <Heading>Summary of event</Heading>
        <Subheading1>
          <LoremIpsumDolor>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          </LoremIpsumDolor>
          <LoremIpsumDolor>
            Suspendisse varius enim in eros elementum tristique.
          </LoremIpsumDolor>
        </Subheading1>
      </SubheadingParent>
    </ButtonRoot>
  );
};

export default Icon;
