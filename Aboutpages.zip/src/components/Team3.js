import styled from "styled-components";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
  text-align: ${(p) => p.propTextAlign};
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
  text-align: ${(p) => p.propTextAlign1};
`;
const IconSocialMedia = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign2};
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const PlaceholderImage = styled.img`width: 80px;
  height: 80px;
  position: relative;
  object-fit: cover;
  width: ${(p) => p.propWidth1}
  height: ${(p) => p.propHeight}
  align-self: ${(p) => p.propAlignSelf3}
  overflow: ${(p) => p.propOverflow}
`;
const Name1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 24px;
  }
  text-align: ${(p) => p.propTextAlign3};
`;
const JobTitle = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign4};
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
`;
const SocialIcons = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign5};
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const IconLinkedin = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const SocialIcons1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-sm);
`;
const Card = styled.div`
  width: 394px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 158px;
  max-width: 100%;
  min-width: ${(p) => p.propMinWidth};
`;
const PlaceholderImage1 = styled.img`width: 80px;
  height: 80px;
  position: relative;
  object-fit: cover;
  width: ${(p) => p.propWidth2}
  height: ${(p) => p.propHeight1}
  align-self: ${(p) => p.propAlignSelf4}
  overflow: ${(p) => p.propOverflow1}
`;
const Name2 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 24px;
  }
  text-align: ${(p) => p.propTextAlign6};
`;
const JobTitle1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign7};
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign8};
`;
const Card1 = styled.div`
  width: 394px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 158px;
  max-width: 100%;
  min-width: ${(p) => p.propMinWidth1};
`;
const PlaceholderImage2 = styled.img`width: 80px;
  height: 80px;
  position: relative;
  object-fit: cover;
  width: ${(p) => p.propWidth3}
  height: ${(p) => p.propHeight2}
  align-self: ${(p) => p.propAlignSelf5}
  overflow: ${(p) => p.propOverflow2}
`;
const Name3 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 24px;
  }
  text-align: ${(p) => p.propTextAlign9};
`;
const JobTitle2 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign10};
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign11};
`;
const Card2 = styled.div`
  width: 394px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 158px;
  max-width: 100%;
  min-width: ${(p) => p.propMinWidth2};
`;
const PlaceholderImage3 = styled.img`width: 80px;
  height: 80px;
  position: relative;
  object-fit: cover;
  width: ${(p) => p.propWidth4}
  height: ${(p) => p.propHeight3}
  align-self: ${(p) => p.propAlignSelf6}
  overflow: ${(p) => p.propOverflow3}
`;
const Name4 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 24px;
  }
  text-align: ${(p) => p.propTextAlign12};
`;
const JobTitle3 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign13};
`;
const Text3 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign14};
`;
const Card3 = styled.div`
  width: 394px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 158px;
  max-width: 100%;
  min-width: ${(p) => p.propMinWidth3};
`;
const PlaceholderImage4 = styled.img`width: 80px;
  height: 80px;
  position: relative;
  object-fit: cover;
  width: ${(p) => p.propWidth5}
  height: ${(p) => p.propHeight4}
  align-self: ${(p) => p.propAlignSelf7}
  overflow: ${(p) => p.propOverflow4}
`;
const Name5 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 24px;
  }
  text-align: ${(p) => p.propTextAlign15};
`;
const JobTitle4 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign16};
`;
const Text4 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign17};
`;
const Card4 = styled.div`
  width: 394px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 158px;
  max-width: 100%;
  min-width: ${(p) => p.propMinWidth4};
`;
const PlaceholderImage5 = styled.img`width: 80px;
  height: 80px;
  position: relative;
  object-fit: cover;
  width: ${(p) => p.propWidth6}
  height: ${(p) => p.propHeight5}
  align-self: ${(p) => p.propAlignSelf8}
  overflow: ${(p) => p.propOverflow5}
`;
const Name6 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 24px;
  }
  text-align: ${(p) => p.propTextAlign18};
`;
const JobTitle5 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign19};
`;
const Text5 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign20};
`;
const Card5 = styled.div`
  width: 394px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 158px;
  max-width: 100%;
  min-width: ${(p) => p.propMinWidth5};
`;
const Content2 = styled.div`align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 64px 47px;
  min-height: 610px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
  gap: 64px 47px;
  
  }
  align-self: ${(p) => p.propAlignSelf2}
  min-height: ${(p) => p.propMinHeight}
  width: ${(p) => p.propWidth}
  overflow-x: ${(p) => p.propOverflowX}
`;
const Heading1 = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
  text-align: ${(p) => p.propTextAlign21};
`;
const ContentText = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign22};
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-3xl);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
  padding: ${(p) => p.propPadding2};
`;
const Content3 = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  font-size: var(--heading-h4-size);
`;
const Content4 = styled.div`align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 0px var(--padding-base);
  box-sizing: border-box;
  gap: var(--gap-77xl);
  max-width: 100%;
  font-size: var(--text-large-semi-bold-size);
  @media screen and (max-width: 800px) {
  gap: var(--gap-77xl);
  
  }
  @media screen and (max-width: 450px) {
  gap: var(--gap-77xl);
  
  }
  align-self: ${(p) => p.propAlignSelf1}
  padding: ${(p) => p.propPadding1}
`;
const TeamRoot = styled.section`align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
  padding-top: var(--padding-54xl);
  padding-bottom: var(--padding-54xl);
  box-sizing: border-box;
  
  }
  @media screen and (max-width: 800px) {
  gap: var(--gap-61xl);
  padding: var(--padding-28xl) var(--padding-13xl);
  box-sizing: border-box;
  
  }
  @media screen and (max-width: 450px) {
  gap: var(--gap-61xl);
  
  }
  align-self: ${(p) => p.propAlignSelf}
  padding: ${(p) => p.propPadding}
`;

const Team3 = ({
  heading,
  placeholderImage,
  placeholderImage1,
  placeholderImage2,
  placeholderImage3,
  placeholderImage4,
  placeholderImage5,
  contentText,
  button,
  propAlignSelf,
  propPadding,
  propTextAlign,
  propTextAlign1,
  propTextAlign2,
  propAlignSelf1,
  propPadding1,
  propAlignSelf2,
  propMinHeight,
  propWidth,
  propOverflowX,
  propMinWidth,
  propWidth1,
  propHeight,
  propAlignSelf3,
  propOverflow,
  propTextAlign3,
  propTextAlign4,
  propTextAlign5,
  propMinWidth1,
  propWidth2,
  propHeight1,
  propAlignSelf4,
  propOverflow1,
  propTextAlign6,
  propTextAlign7,
  propTextAlign8,
  propMinWidth2,
  propWidth3,
  propHeight2,
  propAlignSelf5,
  propOverflow2,
  propTextAlign9,
  propTextAlign10,
  propTextAlign11,
  propMinWidth3,
  propWidth4,
  propHeight3,
  propAlignSelf6,
  propOverflow3,
  propTextAlign12,
  propTextAlign13,
  propTextAlign14,
  propMinWidth4,
  propWidth5,
  propHeight4,
  propAlignSelf7,
  propOverflow4,
  propTextAlign15,
  propTextAlign16,
  propTextAlign17,
  propMinWidth5,
  propWidth6,
  propHeight5,
  propAlignSelf8,
  propOverflow5,
  propTextAlign18,
  propTextAlign19,
  propTextAlign20,
  propTextAlign21,
  propTextAlign22,
  propPadding2,
}) => {
  return (
    <TeamRoot propAlignSelf={propAlignSelf} propPadding={propPadding}>
      <SectionTitle>
        <Subheading propTextAlign={propTextAlign}>Our team</Subheading>
        <Content>
          <Heading propTextAlign1={propTextAlign1}>{heading}</Heading>
          <IconSocialMedia propTextAlign2={propTextAlign2}>
            A common concern a visitor experiences is how well will the product
            or service be supported. Introducing the team eases fears while
            showing confidence.
          </IconSocialMedia>
        </Content>
      </SectionTitle>
      <Content4 propAlignSelf1={propAlignSelf1} propPadding1={propPadding1}>
        <Content2
          propAlignSelf2={propAlignSelf2}
          propMinHeight={propMinHeight}
          propWidth={propWidth}
          propOverflowX={propOverflowX}
        >
          <Card propMinWidth={propMinWidth}>
            <PlaceholderImage
              loading="eager"
              alt=""
              src={placeholderImage}
              propWidth1={propWidth1}
              propHeight={propHeight}
              propAlignSelf3={propAlignSelf3}
              propOverflow={propOverflow}
            />
            <Content1>
              <Title>
                <Name1 propTextAlign3={propTextAlign3}>Full name</Name1>
                <JobTitle propTextAlign4={propTextAlign4}>Job title</JobTitle>
              </Title>
              <SocialIcons propTextAlign5={propTextAlign5}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique.
              </SocialIcons>
            </Content1>
            <SocialIcons1>
              <IconLinkedin loading="eager" alt="" src="/icon--linkedin.svg" />
              <IconLinkedin alt="" src="/icon--twitter.svg" />
              <IconLinkedin alt="" src="/icon--dribble.svg" />
            </SocialIcons1>
          </Card>
          <Card1 propMinWidth1={propMinWidth1}>
            <PlaceholderImage1
              loading="eager"
              alt=""
              src={placeholderImage1}
              propWidth2={propWidth2}
              propHeight1={propHeight1}
              propAlignSelf4={propAlignSelf4}
              propOverflow1={propOverflow1}
            />
            <Content1>
              <Title>
                <Name2 propTextAlign6={propTextAlign6}>Full name</Name2>
                <JobTitle1 propTextAlign7={propTextAlign7}>Job title</JobTitle1>
              </Title>
              <Text1 propTextAlign8={propTextAlign8}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique.
              </Text1>
            </Content1>
            <SocialIcons1>
              <IconLinkedin alt="" src="/icon--linkedin.svg" />
              <IconLinkedin alt="" src="/icon--twitter.svg" />
              <IconLinkedin alt="" src="/icon--dribble.svg" />
            </SocialIcons1>
          </Card1>
          <Card2 propMinWidth2={propMinWidth2}>
            <PlaceholderImage2
              loading="eager"
              alt=""
              src={placeholderImage2}
              propWidth3={propWidth3}
              propHeight2={propHeight2}
              propAlignSelf5={propAlignSelf5}
              propOverflow2={propOverflow2}
            />
            <Content1>
              <Title>
                <Name3 propTextAlign9={propTextAlign9}>Full name</Name3>
                <JobTitle2 propTextAlign10={propTextAlign10}>
                  Job title
                </JobTitle2>
              </Title>
              <Text2 propTextAlign11={propTextAlign11}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique.
              </Text2>
            </Content1>
            <SocialIcons1>
              <IconLinkedin alt="" src="/icon--linkedin.svg" />
              <IconLinkedin alt="" src="/icon--twitter.svg" />
              <IconLinkedin alt="" src="/icon--dribble.svg" />
            </SocialIcons1>
          </Card2>
          <Card3 propMinWidth3={propMinWidth3}>
            <PlaceholderImage3
              loading="eager"
              alt=""
              src={placeholderImage3}
              propWidth4={propWidth4}
              propHeight3={propHeight3}
              propAlignSelf6={propAlignSelf6}
              propOverflow3={propOverflow3}
            />
            <Content1>
              <Title>
                <Name4 propTextAlign12={propTextAlign12}>Full name</Name4>
                <JobTitle3 propTextAlign13={propTextAlign13}>
                  Job title
                </JobTitle3>
              </Title>
              <Text3 propTextAlign14={propTextAlign14}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique.
              </Text3>
            </Content1>
            <SocialIcons1>
              <IconLinkedin alt="" src="/icon--linkedin.svg" />
              <IconLinkedin alt="" src="/icon--twitter.svg" />
              <IconLinkedin alt="" src="/icon--dribble.svg" />
            </SocialIcons1>
          </Card3>
          <Card4 propMinWidth4={propMinWidth4}>
            <PlaceholderImage4
              loading="eager"
              alt=""
              src={placeholderImage4}
              propWidth5={propWidth5}
              propHeight4={propHeight4}
              propAlignSelf7={propAlignSelf7}
              propOverflow4={propOverflow4}
            />
            <Content1>
              <Title>
                <Name5 propTextAlign15={propTextAlign15}>Full name</Name5>
                <JobTitle4 propTextAlign16={propTextAlign16}>
                  Job title
                </JobTitle4>
              </Title>
              <Text4 propTextAlign17={propTextAlign17}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique.
              </Text4>
            </Content1>
            <SocialIcons1>
              <IconLinkedin alt="" src="/icon--linkedin.svg" />
              <IconLinkedin alt="" src="/icon--twitter.svg" />
              <IconLinkedin alt="" src="/icon--dribble.svg" />
            </SocialIcons1>
          </Card4>
          <Card5 propMinWidth5={propMinWidth5}>
            <PlaceholderImage5
              loading="eager"
              alt=""
              src={placeholderImage5}
              propWidth6={propWidth6}
              propHeight5={propHeight5}
              propAlignSelf8={propAlignSelf8}
              propOverflow5={propOverflow5}
            />
            <Content1>
              <Title>
                <Name6 propTextAlign18={propTextAlign18}>Full name</Name6>
                <JobTitle5 propTextAlign19={propTextAlign19}>
                  Job title
                </JobTitle5>
              </Title>
              <Text5 propTextAlign20={propTextAlign20}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique.
              </Text5>
            </Content1>
            <SocialIcons1>
              <IconLinkedin alt="" src="/icon--linkedin.svg" />
              <IconLinkedin alt="" src="/icon--twitter.svg" />
              <IconLinkedin alt="" src="/icon--dribble.svg" />
            </SocialIcons1>
          </Card5>
        </Content2>
        <Content3>
          <Content1>
            <Heading1 propTextAlign21={propTextAlign21}>We’re hiring!</Heading1>
            <ContentText propTextAlign22={propTextAlign22}>
              {contentText}
            </ContentText>
          </Content1>
          <Button1 propPadding2={propPadding2}>
            <Button>{button}</Button>
          </Button1>
        </Content3>
      </Content4>
    </TeamRoot>
  );
};

export default Team3;
