import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 300px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const LinkButtonIcon = styled.div`
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const ActionsFrame = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-8xs) var(--padding-9xs)
    var(--padding-5xs);
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-gainsboro);
  }
`;
const LinkButtonIcon1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Info = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const TitleSection = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h5-size);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  font-size: var(--text-regular-semi-bold-size);
`;
const CardRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 411px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;

const Card1 = () => {
  return (
    <CardRoot>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image-51@2x.png"
      />
      <Content>
        <Info>
          <ActionsFrame>
            <LinkButtonIcon>Media company</LinkButtonIcon>
          </ActionsFrame>
          <LinkButtonIcon1>April 1, 2022</LinkButtonIcon1>
        </Info>
        <Title>
          <Heading>Article title heading will go here</Heading>
          <TitleSection>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros.
          </TitleSection>
        </Title>
      </Content>
      <Button1>
        <Button>Read article</Button>
        <IconChevronRight
          loading="eager"
          alt=""
          src="/icon--chevron-right.svg"
        />
      </Button1>
    </CardRoot>
  );
};

export default Card1;
