import styled from "styled-components";

const VectorClusterIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  height: ${(p) => p.propHeight};
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const NameSurname = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const PositionCompanyName = styled.div`
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-semi-bold-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content = styled.div`
  align-self: stretch;
  border: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-12xl);
  gap: var(--gap-13xl);
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;
const Quote1 = styled.div`
  align-self: stretch;
  height: 135px;
  position: relative;
  line-height: 150%;
  display: inline-block;
  height: ${(p) => p.propHeight1};
`;
const ColumnRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 312px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;

const Column = ({ quote, quote1, propHeight, propHeight1 }) => {
  return (
    <ColumnRoot>
      <Content>
        <Stars>
          <VectorClusterIcon alt="" src="/vector.svg" />
          <VectorClusterIcon alt="" src="/vector.svg" />
          <VectorClusterIcon alt="" src="/vector.svg" />
          <VectorClusterIcon alt="" src="/vector.svg" />
          <VectorClusterIcon alt="" src="/vector.svg" />
        </Stars>
        <Quote propHeight={propHeight}>{quote}</Quote>
        <Avatar>
          <AvatarImageIcon loading="eager" alt="" src="/avatar-image1@2x.png" />
          <AvatarContent>
            <NameSurname>Name Surname</NameSurname>
            <PositionCompanyName>Position, Company name</PositionCompanyName>
          </AvatarContent>
        </Avatar>
      </Content>
      <Content>
        <Stars>
          <VectorClusterIcon alt="" src="/vector.svg" />
          <VectorClusterIcon alt="" src="/vector.svg" />
          <VectorClusterIcon alt="" src="/vector.svg" />
          <VectorClusterIcon alt="" src="/vector.svg" />
          <VectorClusterIcon alt="" src="/vector.svg" />
        </Stars>
        <Quote1 propHeight1={propHeight1}>{quote1}</Quote1>
        <Avatar>
          <AvatarImageIcon
            loading="eager"
            alt=""
            src="/avatar-image-1@2x.png"
          />
          <AvatarContent>
            <NameSurname>Name Surname</NameSurname>
            <PositionCompanyName>Position, Company name</PositionCompanyName>
          </AvatarContent>
        </Avatar>
      </Content>
    </ColumnRoot>
  );
};

export default Column;
