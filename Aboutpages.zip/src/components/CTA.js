import styled from "styled-components";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 467px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const Placeholder = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-smi) var(--padding-xs)
    var(--padding-2xs);
  min-width: 256px;
  max-width: 100%;
  white-space: nowrap;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xl);
  background-color: var(--black);
  width: 105px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const TermsAndConditions = styled.span`
  text-decoration: underline;
`;
const ByClickingSignContainer = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-xs);
  line-height: 150%;
  color: var(--black);
`;
const Actions = styled.div`
  width: 513px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--color-dimgray);
`;
const CtaRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h3-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const CTA = () => {
  return (
    <CtaRoot>
      <Content>
        <Heading>Join our newsletter</Heading>
        <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
      </Content>
      <Actions>
        <Form>
          <TextInput>
            <Placeholder>Enter your email</Placeholder>
          </TextInput>
          <Button1>
            <Button>Sign Up</Button>
          </Button1>
        </Form>
        <ByClickingSignContainer>
          {`By clicking Sign Up you're confirming that you agree with our `}
          <TermsAndConditions>Terms and Conditions</TermsAndConditions>.
        </ByClickingSignContainer>
      </Actions>
    </CtaRoot>
  );
};

export default CTA;
