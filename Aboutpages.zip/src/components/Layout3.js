import styled from "styled-components";
import Column2 from "./Column2";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const Row = styled.div`
  align-self: stretch;
  display: grid;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  grid-template-columns: repeat(3, minmax(304px, 1fr));
  @media screen and (max-width: 1125px) {
    justify-content: center;
    grid-template-columns: repeat(2, minmax(304px, 527px));
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-29xl);
    grid-template-columns: minmax(304px, 1fr);
  }
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h4-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-29xl);
  }
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Layout3 = () => {
  return (
    <LayoutRoot>
      <SectionTitle>
        <Subheading>Our values</Subheading>
        <Content>
          <Heading>Emphasize what's important to your company</Heading>
          <Text1>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare.
          </Text1>
        </Content>
      </SectionTitle>
      <Content1>
        <Row>
          <Column2
            placeholderImage="/placeholder--image-13@2x.png"
            heading="Highlight value one"
          />
          <Column2
            placeholderImage="/placeholder--image-2@2x.png"
            heading="Highlight value two"
          />
          <Column2
            placeholderImage="/placeholder--image-3@2x.png"
            heading="Highlight value three"
          />
        </Row>
      </Content1>
    </LayoutRoot>
  );
};

export default Layout3;
