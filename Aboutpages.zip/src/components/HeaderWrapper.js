import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 288px;
  width: 288px;
  position: relative;
  object-fit: cover;
`;
const Name1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-semi-bold-size);
    line-height: 24px;
  }
`;
const JobTitle = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
`;
const BackgroundImage = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const IconLinkedin = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const SocialIcons = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-sm);
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 187px;
`;
const Card = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 395px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
    gap: var(--gap-13xl);
    min-width: 100%;
  }
`;
const ActionsWrapperRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-large-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-45xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;

const HeaderWrapper = () => {
  return (
    <ActionsWrapperRoot>
      <Card>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-12@2x.png"
        />
        <Column>
          <Content>
            <Title>
              <Name1>Full name</Name1>
              <JobTitle>Job title</JobTitle>
            </Title>
            <BackgroundImage>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique.
            </BackgroundImage>
          </Content>
          <SocialIcons>
            <IconLinkedin loading="eager" alt="" src="/icon--linkedin.svg" />
            <IconLinkedin loading="eager" alt="" src="/icon--twitter.svg" />
            <IconLinkedin loading="eager" alt="" src="/icon--dribble.svg" />
          </SocialIcons>
        </Column>
      </Card>
      <Card>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-12@2x.png"
        />
        <Column>
          <Content>
            <Title>
              <Name1>Full name</Name1>
              <JobTitle>Job title</JobTitle>
            </Title>
            <BackgroundImage>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique.
            </BackgroundImage>
          </Content>
          <SocialIcons>
            <IconLinkedin alt="" src="/icon--linkedin.svg" />
            <IconLinkedin alt="" src="/icon--twitter.svg" />
            <IconLinkedin alt="" src="/icon--dribble.svg" />
          </SocialIcons>
        </Column>
      </Card>
    </ActionsWrapperRoot>
  );
};

export default HeaderWrapper;
