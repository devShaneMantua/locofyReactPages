import styled from "styled-components";
import Card from "./Card";

const OurTeam = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h2-size);
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const LogoFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const ColumnOne = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const CardFrame = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const OurTeamHeading = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Content = styled.div`
  width: 1312px;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-29xl);
  }
`;
const Dot = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--black);
`;
const Dot1 = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--neutral-gray);
`;
const SliderDots = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Icon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xs);
  background-color: transparent;
  height: 48px;
  width: 48px;
  border-radius: var(--br-31xl);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const ButtonParent = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-mini);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--gap-xl);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const FooterLinksFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-29xl);
  }
`;
const TeamRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Team = () => {
  return (
    <TeamRoot>
      <OurTeamHeading>
        <CardFrame>
          <LogoFrame>
            <OurTeam>Our team</OurTeam>
            <Heading>Introduce your team</Heading>
          </LogoFrame>
          <ColumnOne>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</ColumnOne>
        </CardFrame>
      </OurTeamHeading>
      <FooterLinksFrame>
        <Content>
          <Card
            placeholderImage="/placeholder--image-1@2x.png"
            propHeight="unset"
            propMinHeight="24px"
            propMinHeight1="24px"
            propMinHeight2="24px"
            cardWidth="400px"
            cardMinWidth="unset"
            placeholderImageWidth="80px"
            placeholderImageHeight="80px"
          />
          <Card
            placeholderImage="/placeholder--image-1@2x.png"
            propHeight="unset"
            propMinHeight="24px"
            propMinHeight1="24px"
            propMinHeight2="24px"
            cardWidth="400px"
            cardMinWidth="unset"
            placeholderImageWidth="80px"
            placeholderImageHeight="80px"
          />
          <Card
            placeholderImage="/placeholder--image-1@2x.png"
            propHeight="unset"
            propMinHeight="24px"
            propMinHeight1="24px"
            propMinHeight2="24px"
            cardWidth="400px"
            cardMinWidth="unset"
            placeholderImageWidth="80px"
            placeholderImageHeight="80px"
          />
          <Card
            placeholderImage="/placeholder--image-1@2x.png"
            propHeight="unset"
            propMinHeight="24px"
            propMinHeight1="24px"
            propMinHeight2="24px"
            cardWidth="400px"
            cardMinWidth="unset"
            placeholderImageWidth="80px"
            placeholderImageHeight="80px"
          />
        </Content>
        <Content1>
          <SliderDots>
            <Dot />
            <Dot1 />
            <Dot1 />
            <Dot1 />
            <Dot1 />
          </SliderDots>
          <ButtonParent>
            <Button>
              <Icon alt="" src="/icon.svg" />
            </Button>
            <Button>
              <Icon alt="" src="/icon-1.svg" />
            </Button>
          </ButtonParent>
        </Content1>
      </FooterLinksFrame>
    </TeamRoot>
  );
};

export default Team;
