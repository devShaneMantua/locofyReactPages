import styled from "styled-components";
import Icon from "./Icon";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const ShareYourJourney = styled.p`
  margin: 0;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: var(--heading-h2-size);
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Newsletter = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const IconRelume = styled.input`
  margin: 0;
  height: 48px;
  width: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Subheading1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading1 = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h4-size);
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const Logo = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const NameSurname = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-3xs);
  min-width: 343px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const ContentBlock = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
    gap: var(--gap-21xl);
  }
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Layout4 = () => {
  return (
    <LayoutRoot>
      <Newsletter>
        <Subheading>Our story</Subheading>
        <Heading>
          <ShareYourJourney>Share your journey from</ShareYourJourney>
          <ShareYourJourney>the beginning to now</ShareYourJourney>
        </Heading>
      </Newsletter>
      <Newsletter>
        <Icon />
        <Icon />
        <Icon />
        <Icon />
        <ContentBlock>
          <IconRelume type="checkbox" />
          <NameSurname>
            <Subheading1>Year • Month</Subheading1>
            <Heading1>Summary of event</Heading1>
            <Logo>
              <ShareYourJourney>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </ShareYourJourney>
              <ShareYourJourney>
                Suspendisse varius enim in eros elementum tristique.
              </ShareYourJourney>
            </Logo>
          </NameSurname>
        </ContentBlock>
      </Newsletter>
    </LayoutRoot>
  );
};

export default Layout4;
