import styled from "styled-components";
import Card1 from "./Card1";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const LinkButtonIcon = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xl);
  background-color: transparent;
  width: 106px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 1125px) {
    flex-wrap: wrap;
  }
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-29xl);
  }
`;
const BlogRoot = styled.div`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Blog = () => {
  return (
    <BlogRoot>
      <Title>
        <SectionTitle>
          <Heading>News from [company name]</Heading>
          <LinkButtonIcon>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          </LinkButtonIcon>
        </SectionTitle>
        <Button1>
          <Button>View all</Button>
        </Button1>
      </Title>
      <Row>
        <Card1 />
        <Card1 />
      </Row>
    </BlogRoot>
  );
};

export default Blog;
