import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import About from "./pages/About";
import About4 from "./pages/About4";
import About1 from "./pages/About1";
import About2 from "./pages/About2";
import About3 from "./pages/About3";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/about-1":
        title = "";
        metaDescription = "";
        break;
      case "/about-2":
        title = "";
        metaDescription = "";
        break;
      case "/about-3":
        title = "";
        metaDescription = "";
        break;
      case "/about-4":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<About />} />
      <Route path="/about-1" element={<About4 />} />
      <Route path="/about-2" element={<About1 />} />
      <Route path="/about-3" element={<About2 />} />
      <Route path="/about-4" element={<About3 />} />
    </Routes>
  );
}
export default App;
