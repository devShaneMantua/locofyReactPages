import Navbar from "../components/Navbar";
import styled from "styled-components";
import Layout2 from "../components/Layout2";
import Testimonial1 from "../components/Testimonial1";
import Layout1 from "../components/Layout1";
import Team2 from "../components/Team2";
import Blog from "../components/Blog";
import Header from "../components/Header";
import Footer from "../components/Footer";

const Heading = styled.h1`
  margin: 0;
  height: 216px;
  flex: 1;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const LoremIpsumDolor = styled.p`
  margin: 0;
`;
const Instagram = styled.div`
  height: 216px;
  flex: 1;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const Header = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;
const LinkButtonIcon = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const AboutRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const About2 = () => {
  return (
    <AboutRoot>
      <Navbar />
      <Header>
        <Heading>Describe what your company does best</Heading>
        <Instagram>
          <LoremIpsumDolor>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce
            varius faucibus massa sollicitudin amet augue. Nibh metus a semper
            purus mauris duis. Lorem eu neque, tristique quis duis. Nibh
            scelerisque ac adipiscing velit non nulla in amet pellentesque.
          </LoremIpsumDolor>
          <LoremIpsumDolor>&nbsp;</LoremIpsumDolor>
          <LoremIpsumDolor>
            Sit turpis pretium eget maecenas. Vestibulum dolor mattis
            consectetur eget commodo vitae. Amet pellentesque sit pulvinar lorem
            mi a, euismod risus rhoncus.
          </LoremIpsumDolor>
        </Instagram>
      </Header>
      <Layout2 />
      <Testimonial1 />
      <Layout1 />
      <Team2 />
      <LinkButtonIcon>
        <Blog />
        <Header />
      </LinkButtonIcon>
      <Footer />
    </AboutRoot>
  );
};

export default About2;
