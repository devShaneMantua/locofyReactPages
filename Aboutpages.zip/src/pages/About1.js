import Navbar from "../components/Navbar";
import styled from "styled-components";
import Layout4 from "../components/Layout4";
import Layout3 from "../components/Layout3";
import Team3 from "../components/Team3";
import Testimonial2 from "../components/Testimonial2";
import Footer from "../components/Footer";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 134px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-26xl);
    line-height: 54px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
`;
const Button = styled.div`
  align-self: stretch;
  height: 81px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const HeadingParent = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const Header = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h1-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link = styled.h3`
  margin: 0;
  width: 768px;
  height: 102px;
  position: relative;
  font-size: var(--heading-h5-size);
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  text-align: center;
  display: inline-block;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Layout = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-base);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;
const AboutRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const About1 = () => {
  return (
    <AboutRoot>
      <Navbar />
      <Header>
        <HeadingParent>
          <Heading>
            Describe why your company exists [mission statement]
          </Heading>
          <Button>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla, ut commodo diam libero
            vitae erat.
          </Button>
        </HeadingParent>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image1@2x.png"
        />
      </Header>
      <Layout4 />
      <Layout>
        <Subheading>Our vision</Subheading>
        <Link>
          Describe what your company is building towards in the future. This
          vision statement should serve the purpose of selling the dream of the
          company to hiring talent, investors and partners.
        </Link>
      </Layout>
      <Layout3 />
      <Team3
        heading="Introduce the team"
        placeholderImage="/placeholder--image-41@2x.png"
        placeholderImage1="/placeholder--image-52@2x.png"
        placeholderImage2="/placeholder--image-6@2x.png"
        placeholderImage3="/placeholder--image-41@2x.png"
        placeholderImage4="/placeholder--image-52@2x.png"
        placeholderImage5="/placeholder--image-6@2x.png"
        contentText="Lorem ipsum dolor sit amet, consectetur adipiscing elit. "
        button="Open positions"
        propAlignSelf="unset"
        propPadding="var(--padding-93xl) var(--padding-77xl) var(--padding-93xl) var(--padding-45xl)"
        propTextAlign="left"
        propTextAlign1="left"
        propTextAlign2="left"
        propAlignSelf1="unset"
        propPadding1="unset"
        propAlignSelf2="unset"
        propMinHeight="1240px"
        propWidth="1280px"
        propOverflowX="auto"
        propMinWidth="unset"
        propWidth1="unset"
        propHeight="395px"
        propAlignSelf3="stretch"
        propOverflow="hidden"
        propTextAlign3="left"
        propTextAlign4="left"
        propTextAlign5="left"
        propMinWidth1="unset"
        propWidth2="unset"
        propHeight1="395px"
        propAlignSelf4="stretch"
        propOverflow1="hidden"
        propTextAlign6="left"
        propTextAlign7="left"
        propTextAlign8="left"
        propMinWidth2="unset"
        propWidth3="unset"
        propHeight2="395px"
        propAlignSelf5="stretch"
        propOverflow2="hidden"
        propTextAlign9="left"
        propTextAlign10="left"
        propTextAlign11="left"
        propMinWidth3="unset"
        propWidth4="unset"
        propHeight3="395px"
        propAlignSelf6="stretch"
        propOverflow3="hidden"
        propTextAlign12="left"
        propTextAlign13="left"
        propTextAlign14="left"
        propMinWidth4="unset"
        propWidth5="unset"
        propHeight4="395px"
        propAlignSelf7="stretch"
        propOverflow4="hidden"
        propTextAlign15="left"
        propTextAlign16="left"
        propTextAlign17="left"
        propMinWidth5="unset"
        propWidth6="unset"
        propHeight5="395px"
        propAlignSelf8="stretch"
        propOverflow5="hidden"
        propTextAlign18="left"
        propTextAlign19="left"
        propTextAlign20="left"
        propTextAlign21="left"
        propTextAlign22="left"
        propPadding2="var(--padding-xs) var(--padding-2xl)"
      />
      <Testimonial2 />
      <Footer />
    </AboutRoot>
  );
};

export default About1;
