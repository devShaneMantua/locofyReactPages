import Navbar from "../components/Navbar";
import styled from "styled-components";
import Layout7 from "../components/Layout7";
import Layout6 from "../components/Layout6";
import Logo1 from "../components/Logo1";
import Layout5 from "../components/Layout5";
import Team3 from "../components/Team3";
import Blog1 from "../components/Blog1";
import Footer from "../components/Footer";

const Heading = styled.h1`
  margin: 0;
  width: 768px;
  height: 134px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-26xl);
    line-height: 54px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
`;
const ExplainWhatYour = styled.div`
  width: 768px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
`;
const Header = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h1-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;
const AboutRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const About4 = () => {
  return (
    <AboutRoot>
      <Navbar />
      <Header>
        <Heading>Describe why your company exists [mission statement</Heading>
        <ExplainWhatYour>
          Explain what your company is working on and the value you provide to
          your customers.
        </ExplainWhatYour>
      </Header>
      <Layout7 />
      <Layout6 />
      <Logo1 />
      <Layout5
        heading="Highlight value one"
        heading1="Highlight value two"
        heading2="Highlight value three"
      />
      <Team3
        heading="Introduce your team"
        placeholderImage="/placeholder--image-21@2x.png"
        placeholderImage1="/placeholder--image-1@2x.png"
        placeholderImage2="/placeholder--image-42@2x.png"
        placeholderImage3="/placeholder--image-21@2x.png"
        placeholderImage4="/placeholder--image-1@2x.png"
        placeholderImage5="/placeholder--image-42@2x.png"
        contentText="Our team is growing fast and we’re always looking for smart people."
        button="View open roles"
      />
      <Blog1 />
      <Footer />
    </AboutRoot>
  );
};

export default About4;
