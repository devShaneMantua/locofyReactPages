import Navbar from "../components/Navbar";
import styled from "styled-components";
import Layout from "../components/Layout";
import Layout5 from "../components/Layout5";
import Team1 from "../components/Team1";
import Logo from "../components/Logo";
import CTA from "../components/CTA";
import Footer from "../components/Footer";

const Heading = styled.h1`
  margin: 0;
  width: 768px;
  height: 134px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-26xl);
    line-height: 54px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
`;
const LinkedInIcon = styled.div`
  width: 768px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
`;
const Header = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h1-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;
const AboutRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const About3 = () => {
  return (
    <AboutRoot>
      <Navbar />
      <Header>
        <Heading>Describe why your company exists [mission statement]</Heading>
        <LinkedInIcon>
          Explain what your company is working on and the value you provide to
          your customers.
        </LinkedInIcon>
      </Header>
      <Layout />
      <Layout5
        heading="Describe value one"
        heading1="Describe value two"
        heading2="Describe value three"
        propTextAlign="left"
        propTextAlign1="left"
        propTextAlign2="left"
        propTextAlign3="left"
        propTextAlign4="left"
        propTextAlign5="left"
        propTextAlign6="left"
        propTextAlign7="left"
        propTextAlign8="left"
      />
      <Team1 />
      <Logo />
      <CTA />
      <Footer />
    </AboutRoot>
  );
};

export default About3;
