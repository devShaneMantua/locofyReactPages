import Navbar from "../components/Navbar";
import styled from "styled-components";
import Team from "../components/Team";
import Testimonial from "../components/Testimonial";
import Contact from "../components/Contact";
import Footer from "../components/Footer";

const Heading = styled.h1`
  margin: 0;
  width: 768px;
  height: 134px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-26xl);
    line-height: 54px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
`;
const INP = styled.div`
  width: 768px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
`;
const Header = styled.section`
  align-self: stretch;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
  background-image: url("/header--30@3x.png");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h1-size);
  color: var(--white);
  font-family: var(--text-small-link);
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;
const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading1 = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const LoremIpsumDolor = styled.p`
  margin: 0;
`;
const Paragraph = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--heading-h2-size);
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const PlaceholderImage = styled.img`
  height: 640px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 400px;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const Layout = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;
const AboutRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px 0px;
  box-sizing: border-box;
  letter-spacing: normal;
`;

const About = () => {
  return (
    <AboutRoot>
      <Navbar />
      <Header>
        <Heading>Describe what makes your company unique</Heading>
        <INP>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. `}</INP>
      </Header>
      <Layout>
        <Content1>
          <Subheading>Feature one</Subheading>
          <Content>
            <Heading1>About [company name]</Heading1>
            <Paragraph>
              <LoremIpsumDolor>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce
                varius faucibus massa sollicitudin amet augue. Nibh metus a
                semper purus mauris duis. Lorem eu neque, tristique quis duis.
                Nibh scelerisque ac adipiscing velit non nulla in amet
                pellentesque. Sit turpis pretium eget maecenas. Vestibulum dolor
                mattis consectetur eget commodo vitae.
              </LoremIpsumDolor>
              <LoremIpsumDolor>&nbsp;</LoremIpsumDolor>
              <LoremIpsumDolor>
                Amet pellentesque sit pulvinar lorem mi a, euismod risus
                rhoncus. Elementum ullamcorper nec, habitasse vulputate. Eget
                dictum quis est sed egestas tellus, a lectus. Quam ullamcorper
                in fringilla arcu aliquet fames arcu.Lacinia eget faucibus urna,
                nam risus nec elementum cras porta. Sed elementum, sed dolor
                purus dolor dui. Ut dictum nulla pulvinar vulputate sit sagittis
                in eleifend dignissim. Natoque mauris cras molestie velit.
                Maecenas eget adipiscing quisque viverra lectus arcu, tincidunt
                ultrices pellentesque.
              </LoremIpsumDolor>
            </Paragraph>
          </Content>
        </Content1>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image@2x.png"
        />
      </Layout>
      <Team />
      <Testimonial />
      <Contact />
      <Footer />
    </AboutRoot>
  );
};

export default About;
