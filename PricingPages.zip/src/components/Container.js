import styled from "styled-components";

const VectorIcon = styled.img`
  width: 20px;
  position: relative;
  height: 18.9px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const AvatarImageIcon = styled.img`
  width: 56px;
  position: relative;
  border-radius: 50%;
  height: 56px;
  object-fit: cover;
`;
const NameSurname = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const PositionCompanyName = styled.div`
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider = styled.div`
  width: 1px;
  position: relative;
  border-right: 1px solid var(--black);
  box-sizing: border-box;
  height: 62px;
`;
const WebflowBlack = styled.img`
  width: 120px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xl);
  font-size: var(--text-regular-semi-bold-size);
`;
const ContainerRoot = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  text-align: left;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Container = () => {
  return (
    <ContainerRoot>
      <Stars>
        <VectorIcon alt="" src="/vector.svg" />
        <VectorIcon alt="" src="/vector.svg" />
        <VectorIcon alt="" src="/vector.svg" />
        <VectorIcon alt="" src="/vector.svg" />
        <VectorIcon alt="" src="/vector.svg" />
      </Stars>
      <Quote>
        "A customer testimonial that highlights features and answers potential
        customer doubts about your product or service. Showcase testimonials
        from a similar demographic to your customers."
      </Quote>
      <Avatar>
        <AvatarImageIcon alt="" src="/avatar-image@2x.png" />
        <AvatarContent>
          <NameSurname>Name Surname</NameSurname>
          <PositionCompanyName>Position, Company name</PositionCompanyName>
        </AvatarContent>
        <Divider />
        <WebflowBlack alt="" src="/webflow--black.svg" />
      </Avatar>
    </ContainerRoot>
  );
};

export default Container;
