import styled from "styled-components";

const Text1 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TableCell = styled.div`
  width: 420px;
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl) var(--padding-base) 0px;
  box-sizing: border-box;
  text-align: left;
`;
const Text2 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const TableCell1 = styled.div`
  flex: 1;
  background-color: var(--white);
  box-shadow: 1px 0px 0px #000 inset;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-base) var(--padding-5xl);
`;
const Row = styled.div`
  align-self: stretch;
  background-color: var(--white);
  box-shadow: 0px 1px 0px #000 inset;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: center;
`;
const TableCell2 = styled.div`
  width: 420px;
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl) var(--padding-base) 0px;
  box-sizing: border-box;
`;
const CheckIcon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Row1 = styled.div`
  align-self: stretch;
  background-color: var(--white);
  box-shadow: 0px 1px 0px #000 inset;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Check = styled.div`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
  display: none;
`;
const ListRoot = styled.div`
  align-self: stretch;
  box-shadow: 0px -1px 0px #000 inset;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const List = () => {
  return (
    <ListRoot>
      <Row>
        <TableCell>
          <Text1>Feature text goes here</Text1>
        </TableCell>
        <TableCell1>
          <Text2>10</Text2>
        </TableCell1>
        <TableCell1>
          <Text2>25</Text2>
        </TableCell1>
        <TableCell1>
          <Text2>Unlimited</Text2>
        </TableCell1>
      </Row>
      <Row1>
        <TableCell2>
          <Text1>Feature text goes here</Text1>
        </TableCell2>
        <TableCell1>
          <CheckIcon alt="" src="/check.svg" />
        </TableCell1>
        <TableCell1>
          <CheckIcon alt="" src="/check.svg" />
        </TableCell1>
        <TableCell1>
          <CheckIcon alt="" src="/check.svg" />
        </TableCell1>
      </Row1>
      <Row1>
        <TableCell2>
          <Text1>Feature text goes here</Text1>
        </TableCell2>
        <TableCell1>
          <CheckIcon alt="" src="/check.svg" />
        </TableCell1>
        <TableCell1>
          <CheckIcon alt="" src="/check.svg" />
        </TableCell1>
        <TableCell1>
          <CheckIcon alt="" src="/check.svg" />
        </TableCell1>
      </Row1>
      <Row1>
        <TableCell2>
          <Text1>Feature text goes here</Text1>
        </TableCell2>
        <TableCell1>
          <Check />
        </TableCell1>
        <TableCell1>
          <CheckIcon alt="" src="/check.svg" />
        </TableCell1>
        <TableCell1>
          <CheckIcon alt="" src="/check.svg" />
        </TableCell1>
      </Row1>
      <Row1>
        <TableCell2>
          <Text1>Feature text goes here</Text1>
        </TableCell2>
        <TableCell1>
          <Check />
        </TableCell1>
        <TableCell1>
          <Check />
        </TableCell1>
        <TableCell1>
          <CheckIcon alt="" src="/check.svg" />
        </TableCell1>
      </Row1>
    </ListRoot>
  );
};

export default List;
