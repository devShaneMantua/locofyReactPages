import styled from "styled-components";

const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const Span = styled.span`
  line-height: 120%;
`;
const Mo = styled.span`
  font-size: var(--heading-h5-size);
  line-height: 140%;
`;
const Price = styled.b`
  align-self: stretch;
  position: relative;
`;
const PriceWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--heading-h1-size);
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Price1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--white);
`;
const ColumnRoot = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 0px var(--padding-base);
  gap: var(--gap-13xl);
  text-align: center;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Column6 = ({ heading, prop }) => {
  return (
    <ColumnRoot>
      <Price1>
        <Heading>{heading}</Heading>
        <PriceWrapper>
          <Price>
            <Span>{prop}</Span>
            <Mo>/mo</Mo>
          </Price>
        </PriceWrapper>
        <Text1>Lorem ipsum dolor sit amet</Text1>
      </Price1>
      <Button1>
        <Button>Get started</Button>
      </Button1>
    </ColumnRoot>
  );
};

export default Column6;
