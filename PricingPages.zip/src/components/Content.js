import styled from "styled-components";

const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 130%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
`;
const ContentRoot = styled.div`
  width: 560px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: center;
  font-size: var(--heading-h4-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Content = ({ button }) => {
  return (
    <ContentRoot>
      <Content1>
        <Heading>Still have questions?</Heading>
        <Text1>
          Support details to capture customers that might be on the fence.
        </Text1>
      </Content1>
      <Button1>
        <Button>{button}</Button>
      </Button1>
    </ContentRoot>
  );
};

export default Content;
