import styled from "styled-components";

const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Price = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  font-size: var(--text-regular-semi-bold-size);
  color: var(--white);
`;
const ColumnRoot = styled.div`
  align-self: stretch;
  flex: 1;
  background-color: var(--white);
  box-shadow: -1px 0px 0px #000;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-5xl);
  gap: var(--gap-13xl);
  text-align: left;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Column = ({ heading }) => {
  return (
    <ColumnRoot>
      <Price>
        <Heading>{heading}</Heading>
        <Text1>Lorem ipsum dolor sit amet</Text1>
      </Price>
      <Button1>
        <Button>Get started</Button>
      </Button1>
    </ColumnRoot>
  );
};

export default Column;
