import styled from "styled-components";
import Price from "./Price";
import List2 from "./List2";
import List1 from "./List1";

const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.b`
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h1-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  text-align: center;
`;
const Monthly = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button = styled.div`
  background-color: var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--black);
`;
const Tabs = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  color: var(--white);
`;
const Price1 = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Button2 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--white);
`;
const Column = styled.div`
  align-self: stretch;
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-13xl);
  gap: var(--gap-13xl);
  text-align: center;
  font-size: var(--heading-h6-size);
`;
const CheckIcon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const ListItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const List = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-base);
`;
const Button3 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--white);
`;
const Column1 = styled.div`
  align-self: stretch;
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-13xl);
  gap: var(--gap-13xl);
`;
const Price2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Button4 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Column2 = styled.div`
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-13xl);
  gap: var(--gap-13xl);
  color: var(--white);
`;
const Content1 = styled.div`
  align-self: stretch;
  height: 512px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const PricingRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-29xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Pricing1 = () => {
  return (
    <PricingRoot>
      <SectionTitle>
        <Subheading>Pricing plans</Subheading>
        <Content>
          <Heading>Introduce pricing plans</Heading>
          <Text1>
            Simple, transparent pricing that grows with you. Try any plan free
            for 30 days.
          </Text1>
        </Content>
      </SectionTitle>
      <Tabs>
        <Button>
          <Monthly>Monthly</Monthly>
        </Button>
        <Button1>
          <Monthly>Yearly</Monthly>
        </Button1>
      </Tabs>
      <Content1>
        <Column>
          <Price1>
            <Price heading="Basic plan" prop="$19" text="or $199 yearly" />
            <List2
              listFlex="unset"
              listAlignSelf="stretch"
              listPadding="var(--padding-5xs) 0px"
              textFlex="unset"
              textFlex1="unset"
              textFlex2="unset"
            />
          </Price1>
          <Button2>
            <Monthly>Get started</Monthly>
          </Button2>
        </Column>
        <Column1>
          <Price1>
            <Price heading="Business plan" prop="$29" text="or $299 yearly" />
            <List>
              <ListItem>
                <CheckIcon alt="" src="/check.svg" />
                <Monthly>Feature text goes here</Monthly>
              </ListItem>
              <ListItem>
                <CheckIcon alt="" src="/check.svg" />
                <Monthly>Feature text goes here</Monthly>
              </ListItem>
              <ListItem>
                <CheckIcon alt="" src="/check.svg" />
                <Monthly>Feature text goes here</Monthly>
              </ListItem>
              <ListItem>
                <CheckIcon alt="" src="/check.svg" />
                <Monthly>Feature text goes here</Monthly>
              </ListItem>
            </List>
          </Price1>
          <Button3>
            <Monthly>Get started</Monthly>
          </Button3>
        </Column1>
        <Column2>
          <Price2>
            <Price heading="Enterprise plan" prop="$49" text="or $499 yearly" />
            <List1
              listFlex="unset"
              listAlignSelf="stretch"
              listPadding="var(--padding-5xs) 0px"
              textFlex="unset"
              textFlex1="unset"
              textFlex2="unset"
              textFlex3="unset"
              textFlex4="unset"
            />
          </Price2>
          <Button4>
            <Monthly>Get started</Monthly>
          </Button4>
        </Column2>
      </Content1>
    </PricingRoot>
  );
};

export default Pricing1;
