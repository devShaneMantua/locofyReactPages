import styled from "styled-components";

const WebflowBlack = styled.img`
  width: 120px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Quote = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const AvatarImageIcon = styled.img`
  width: 56px;
  position: relative;
  border-radius: 50%;
  height: 56px;
  object-fit: cover;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  width: 300px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-semi-bold-size);
`;
const ColumnRoot = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: center;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Column1 = ({ avatarImage }) => {
  return (
    <ColumnRoot>
      <WebflowBlack alt="" src="/webflow--black.svg" />
      <Quote>
        "A customer testimonial that highlights features and answers potential
        customer doubts about your product or service. Showcase testimonials
        from a similar demographic to your customers."
      </Quote>
      <Avatar>
        <AvatarImageIcon alt="" src={avatarImage} />
        <AvatarContent>
          <Text1>Customer name</Text1>
          <Text2>Position, Company name</Text2>
        </AvatarContent>
      </Avatar>
    </ColumnRoot>
  );
};

export default Column1;
