import styled from "styled-components";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const DescribeFeatureOne = styled.p`
  margin: 0;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 130%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h4-size);
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const ColumnRoot = styled.div`
  width: 405.3px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Column7 = ({ subheading, describeFeatureOneAnd }) => {
  return (
    <ColumnRoot>
      <SectionTitle>
        <Subheading>{subheading}</Subheading>
        <Content>
          <Heading>
            <DescribeFeatureOne>{describeFeatureOneAnd}</DescribeFeatureOne>
            <DescribeFeatureOne>its benefits</DescribeFeatureOne>
          </Heading>
          <Text1>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla.
          </Text1>
        </Content>
      </SectionTitle>
      <Button1>
        <Button>Learn more</Button>
        <IconChevronRight alt="" src="/icon--chevron-right.svg" />
      </Button1>
    </ColumnRoot>
  );
};

export default Column7;
