import styled from "styled-components";

const Heading = styled.b`
  position: relative;
  line-height: 140%;
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const PriceTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
  font-size: var(--heading-h6-size);
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  border-top: 1px solid var(--black);
  box-sizing: border-box;
  height: 1px;
`;
const Span = styled.span`
  line-height: 120%;
`;
const Mo = styled.span`
  font-size: var(--heading-h4-size);
  line-height: 130%;
`;
const Price = styled.b`
  position: relative;
`;
const Price1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h1-size);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  text-align: left;
  color: var(--white);
`;
const CheckIcon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const ListItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const List = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-base);
  text-align: left;
`;
const ColumnRoot = styled.div`
  align-self: stretch;
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl);
  gap: var(--gap-13xl);
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Column4 = () => {
  return (
    <ColumnRoot>
      <PriceTitle>
        <Heading>Business plan</Heading>
        <Text1>Lorem ipsum dolor sit amet</Text1>
      </PriceTitle>
      <Divider />
      <Price1>
        <Price>
          <Span>$29</Span>
          <Mo>/mo</Mo>
        </Price>
        <Text1>or $299 yearly</Text1>
      </Price1>
      <Button1>
        <Button>Get started</Button>
      </Button1>
      <Divider />
      <List>
        <ListItem>
          <CheckIcon alt="" src="/check.svg" />
          <Button>Feature text goes here</Button>
        </ListItem>
        <ListItem>
          <CheckIcon alt="" src="/check.svg" />
          <Button>Feature text goes here</Button>
        </ListItem>
        <ListItem>
          <CheckIcon alt="" src="/check.svg" />
          <Button>Feature text goes here</Button>
        </ListItem>
        <ListItem>
          <CheckIcon alt="" src="/check.svg" />
          <Button>Feature text goes here</Button>
        </ListItem>
      </List>
    </ColumnRoot>
  );
};

export default Column4;
