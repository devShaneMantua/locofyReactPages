import styled from "styled-components";

const CheckIcon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Text1 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  flex: ${(p) => p.textFlex};
`;
const ListItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Text2 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  flex: ${(p) => p.textFlex1};
`;
const Text3 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  flex: ${(p) => p.textFlex2};
`;
const Text4 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  flex: ${(p) => p.textFlex3};
`;
const Text5 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  flex: ${(p) => p.textFlex4};
`;
const ListRoot = styled.div`flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  flex: ${(p) => p.listFlex}
  align-self: ${(p) => p.listAlignSelf}
  padding: ${(p) => p.listPadding}
`;

const List1 = ({
  listFlex,
  listAlignSelf,
  listPadding,
  textFlex,
  textFlex1,
  textFlex2,
  textFlex3,
  textFlex4,
}) => {
  return (
    <ListRoot
      listFlex={listFlex}
      listAlignSelf={listAlignSelf}
      listPadding={listPadding}
    >
      <ListItem>
        <CheckIcon alt="" src="/check.svg" />
        <Text1 textFlex={textFlex}>Feature text goes here</Text1>
      </ListItem>
      <ListItem>
        <CheckIcon alt="" src="/check.svg" />
        <Text2 textFlex1={textFlex1}>Feature text goes here</Text2>
      </ListItem>
      <ListItem>
        <CheckIcon alt="" src="/check.svg" />
        <Text3 textFlex2={textFlex2}>Feature text goes here</Text3>
      </ListItem>
      <ListItem>
        <CheckIcon alt="" src="/check.svg" />
        <Text4 textFlex3={textFlex3}>Feature text goes here</Text4>
      </ListItem>
      <ListItem>
        <CheckIcon alt="" src="/check.svg" />
        <Text5 textFlex4={textFlex4}>Feature text goes here</Text5>
      </ListItem>
    </ListRoot>
  );
};

export default List1;
