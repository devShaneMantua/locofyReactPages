import styled from "styled-components";

const IconRelume = styled.img`
  width: 32px;
  position: relative;
  height: 32px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const ListItemRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const ListItem = () => {
  return (
    <ListItemRoot>
      <IconRelume alt="" src="/icon--relume.svg" />
      <Content>
        <Heading>Key feature heading</Heading>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique.
        </Text1>
      </Content>
    </ListItemRoot>
  );
};

export default ListItem;
