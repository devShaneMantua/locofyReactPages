import styled from "styled-components";
import AccordionItem from "./AccordionItem";
import Content from "./Content";

const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Divider = styled.div`
  width: 768px;
  position: relative;
  background-color: var(--black);
  height: 1px;
`;
const Accordion = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--text-medium-normal-size);
`;
const Container = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-61xl);
`;
const FaqRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const FAQ = () => {
  return (
    <FaqRoot>
      <Container>
        <SectionTitle>
          <Heading>Frequently asked questions</Heading>
          <Text1>
            Frequently asked questions ordered by popularity. Remember that if
            the visitor has not committed to the call to action, they may still
            have questions (doubts) that can be answered.
          </Text1>
        </SectionTitle>
        <Accordion>
          <AccordionItem />
          <AccordionItem />
          <AccordionItem />
          <AccordionItem />
          <AccordionItem />
          <Divider />
        </Accordion>
        <Content button="Contact us" />
      </Container>
    </FaqRoot>
  );
};

export default FAQ;
