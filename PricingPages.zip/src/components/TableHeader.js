import styled from "styled-components";
import Column from "./Column";

const Column = styled.div`
  align-self: stretch;
  width: 420px;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  background-color: var(--black);
  height: 1px;
`;
const TableHeaderRoot = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const TableHeader = () => {
  return (
    <TableHeaderRoot>
      <Content>
        <Column />
        <Column heading="Basic " />
        <Column heading="Business " />
        <Column heading="Enterprise " />
      </Content>
      <Divider />
    </TableHeaderRoot>
  );
};

export default TableHeader;
