import styled from "styled-components";

const Text1 = styled.div`
  position: relative;
  line-height: 150%;
`;
const CheckIcon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const ListItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const List = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-base);
`;
const ContentRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Content3 = () => {
  return (
    <ContentRoot>
      <Text1>Includes:</Text1>
      <List>
        <ListItem>
          <CheckIcon alt="" src="/check.svg" />
          <Text1>Feature text goes here</Text1>
        </ListItem>
        <ListItem>
          <CheckIcon alt="" src="/check.svg" />
          <Text1>Feature text goes here</Text1>
        </ListItem>
        <ListItem>
          <CheckIcon alt="" src="/check.svg" />
          <Text1>Feature text goes here</Text1>
        </ListItem>
        <ListItem>
          <CheckIcon alt="" src="/check.svg" />
          <Text1>Feature text goes here</Text1>
        </ListItem>
      </List>
    </ContentRoot>
  );
};

export default Content3;
