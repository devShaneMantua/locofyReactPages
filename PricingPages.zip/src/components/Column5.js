import styled from "styled-components";
import List2 from "./List2";

const Heading = styled.b`
  position: relative;
  line-height: 140%;
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const PriceTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  border-top: 1px solid var(--black);
  box-sizing: border-box;
  height: 1px;
`;
const Span = styled.span`
  line-height: 120%;
`;
const Mo = styled.span`
  font-size: var(--heading-h4-size);
  line-height: 130%;
`;
const Price = styled.b`
  position: relative;
`;
const Price1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h1-size);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--white);
`;
const ColumnRoot = styled.div`
  align-self: stretch;
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl);
  gap: var(--gap-13xl);
  text-align: center;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Column5 = () => {
  return (
    <ColumnRoot>
      <PriceTitle>
        <Heading>Basic plan</Heading>
        <Text1>Lorem ipsum dolor sit amet</Text1>
      </PriceTitle>
      <Divider />
      <Price1>
        <Price>
          <Span>$19</Span>
          <Mo>/mo</Mo>
        </Price>
        <Text1>or $199 yearly</Text1>
      </Price1>
      <Button1>
        <Button>Get started</Button>
      </Button1>
      <Divider />
      <List2
        listFlex="unset"
        listAlignSelf="stretch"
        listPadding="var(--padding-5xs) 0px"
        textFlex="unset"
        textFlex1="unset"
        textFlex2="unset"
      />
    </ColumnRoot>
  );
};

export default Column5;
