import styled from "styled-components";

const IconRelume = styled.img`
  width: 48px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.b`
  position: relative;
  line-height: 140%;
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Title = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const PriceTitle1 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Span = styled.span`
  line-height: 120%;
`;
const Mo = styled.span`
  font-size: var(--heading-h4-size);
  line-height: 130%;
`;
const Mo1 = styled.b`
  position: relative;
  font-size: var(--heading-h1-size);
`;
const PriceTitleRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  text-align: center;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const PriceTitle = ({ heading, prop }) => {
  return (
    <PriceTitleRoot>
      <PriceTitle1>
        <IconRelume alt="" src="/icon--relume.svg" />
        <Title>
          <Heading>{heading}</Heading>
          <Text1>Lorem ipsum dolor sit amet</Text1>
        </Title>
      </PriceTitle1>
      <Mo1>
        <Span>{prop}</Span>
        <Mo>/mo</Mo>
      </Mo1>
    </PriceTitleRoot>
  );
};

export default PriceTitle;
