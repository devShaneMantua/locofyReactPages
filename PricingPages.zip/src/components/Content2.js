import styled from "styled-components";

const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 130%;
  text-align: ${(p) => p.propTextAlign};
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign1};
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  font-size: var(--text-regular-semi-bold-size);
`;
const ContentRoot = styled.div`
  width: 560px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--heading-h4-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Content2 = ({ propTextAlign, propTextAlign1 }) => {
  return (
    <ContentRoot>
      <Content>
        <Heading propTextAlign={propTextAlign}>Still have questions?</Heading>
        <Text1 propTextAlign1={propTextAlign1}>
          Support details to capture customers that might be on the fence.
        </Text1>
      </Content>
      <Button1>
        <Button>Contact us</Button>
      </Button1>
    </ContentRoot>
  );
};

export default Content2;
