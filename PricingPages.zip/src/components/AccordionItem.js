import styled from "styled-components";

const Divider = styled.div`
  width: 768px;
  position: relative;
  background-color: var(--black);
  height: 1px;
`;
const Question = styled.b`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Icon = styled.img`
  width: 32px;
  position: relative;
  height: 32px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Title = styled.div`
  width: 768px;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  box-sizing: border-box;
  gap: var(--gap-xs);
`;
const AccordionItemRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const AccordionItem = () => {
  return (
    <AccordionItemRoot>
      <Divider />
      <Title>
        <Question>Question text goes here</Question>
        <Icon alt="" src="/icon.svg" />
      </Title>
    </AccordionItemRoot>
  );
};

export default AccordionItem;
