import styled from "styled-components";

const Heading = styled.b`
  position: relative;
  line-height: 150%;
`;
const VectorIcon = styled.img`
  position: absolute;
  top: calc(50% - 14.2px);
  left: calc(50% - 57px);
  width: 114px;
  height: 28.7px;
`;
const WebflowBlack = styled.div`
  width: 200px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const RelumeBlack = styled.img`
  width: 200px;
  position: relative;
  height: 56px;
  overflow: hidden;
  flex-shrink: 0;
`;
const WebflowBlack1 = styled.img`
  width: 200px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Content = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xl);
`;
const LogoRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-29xl);
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Logo = () => {
  return (
    <LogoRoot>
      <Heading>
        Trusted by the world's best companies [social proof to build
        credibility]
      </Heading>
      <Content>
        <WebflowBlack>
          <VectorIcon alt="" src="/vector.svg" />
        </WebflowBlack>
        <RelumeBlack alt="" src="/relume--black.svg" />
        <WebflowBlack1 alt="" src="/webflow--black.svg" />
        <RelumeBlack alt="" src="/relume--black.svg" />
        <WebflowBlack1 alt="" src="/webflow--black.svg" />
        <RelumeBlack alt="" src="/relume--black.svg" />
        <WebflowBlack1 alt="" src="/webflow--black.svg" />
      </Content>
    </LogoRoot>
  );
};

export default Logo;
