import styled from "styled-components";
import Column2 from "./Column2";

const Heading = styled.b`
  width: 768px;
  position: relative;
  line-height: 120%;
  display: inline-block;
`;
const IconRelume = styled.img`
  width: 48px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading1 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-29xl);
  font-size: var(--heading-h5-size);
`;
const LayoutRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Layout = () => {
  return (
    <LayoutRoot>
      <Heading>Highlight key features of the product or service</Heading>
      <Row>
        <Column2 describeFeatureOneAndIts="Describe feature one and its" />
        <Column2 describeFeatureOneAndIts="Describe feature two and its" />
        <Column>
          <IconRelume alt="" src="/icon--relume.svg" />
          <SectionTitle>
            <Heading1>Describe feature three and its benefits</Heading1>
            <Text1>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique. Duis cursus,
              mi quis viverra ornare, eros dolor interdum nulla.
            </Text1>
          </SectionTitle>
          <Button1>
            <Button>Learn more</Button>
            <IconChevronRight alt="" src="/icon--chevron-right.svg" />
          </Button1>
        </Column>
      </Row>
    </LayoutRoot>
  );
};

export default Layout;
