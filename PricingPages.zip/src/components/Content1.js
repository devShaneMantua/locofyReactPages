import styled from "styled-components";
import List from "./List";

const FeatureCategory = styled.b`
  flex: 1;
  position: relative;
  line-height: 140%;
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
`;
const ContentRoot = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Content1 = () => {
  return (
    <ContentRoot>
      <Row>
        <FeatureCategory>Feature Category</FeatureCategory>
      </Row>
      <List />
      <Row>
        <FeatureCategory>Feature Category</FeatureCategory>
      </Row>
      <List />
      <Row>
        <FeatureCategory>Feature Category</FeatureCategory>
      </Row>
      <List />
    </ContentRoot>
  );
};

export default Content1;
