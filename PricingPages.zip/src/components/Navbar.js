import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  position: relative;
  height: 27px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Link = styled.div`
  position: relative;
  line-height: 150%;
`;
const ChevronDownIcon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const NavLinkDropdown = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-9xs);
`;
const Column1 = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Button = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-xl);
`;
const Button1 = styled.div`
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-xl);
  color: var(--white);
`;
const Column2 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-base);
`;
const Column3 = styled.div`
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-13xl);
`;
const Container = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;
const NavbarRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  box-shadow: 0px -1px 0px #000 inset;
  height: 72px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0px var(--padding-45xl);
  box-sizing: border-box;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Navbar = () => {
  return (
    <NavbarRoot>
      <Container>
        <Column>
          <LogoIcon alt="" src="/logo.svg" />
        </Column>
        <Column3>
          <Column1>
            <Link>Link One</Link>
            <Link>Link Two</Link>
            <Link>Link Three</Link>
            <NavLinkDropdown>
              <Link>Link Four</Link>
              <ChevronDownIcon alt="" src="/chevron-down.svg" />
            </NavLinkDropdown>
          </Column1>
          <Column2>
            <Button>
              <Link>Log in</Link>
            </Button>
            <Button1>
              <Link>Get started</Link>
            </Button1>
          </Column2>
        </Column3>
      </Container>
    </NavbarRoot>
  );
};

export default Navbar;
