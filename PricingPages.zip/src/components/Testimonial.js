import Column1 from "./Column1";
import styled from "styled-components";

const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-29xl);
`;
const TestimonialRoot = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  text-align: center;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Testimonial = () => {
  return (
    <TestimonialRoot>
      <Content>
        <Column1 avatarImage="/avatar-image@2x.png" />
        <Column1 avatarImage="/avatar-image@2x.png" />
        <Column1 avatarImage="/avatar-image@2x.png" />
      </Content>
    </TestimonialRoot>
  );
};

export default Testimonial;
