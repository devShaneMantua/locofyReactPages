import styled from "styled-components";

const Heading = styled.b`
  position: relative;
  line-height: 140%;
`;
const Span = styled.span`
  line-height: 120%;
`;
const Mo = styled.span`
  font-size: var(--heading-h4-size);
  line-height: 130%;
`;
const Price1 = styled.b`
  position: relative;
  font-size: var(--heading-h1-size);
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const PriceRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  text-align: center;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Price = ({ heading, prop, text }) => {
  return (
    <PriceRoot>
      <Heading>{heading}</Heading>
      <Price1>
        <Span>{prop}</Span>
        <Mo>/mo</Mo>
      </Price1>
      <Text1>{text}</Text1>
    </PriceRoot>
  );
};

export default Price;
