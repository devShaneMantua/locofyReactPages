import styled from "styled-components";

const ColumnOne = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const IconFacebook = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Facebook = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-xs);
`;
const Column1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const LinksRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Links = () => {
  return (
    <LinksRoot>
      <Column>
        <ColumnOne>Column One</ColumnOne>
        <FooterLinks>
          <Link1>
            <Link>Link One</Link>
          </Link1>
          <Link1>
            <Link>Link Two</Link>
          </Link1>
          <Link1>
            <Link>Link Three</Link>
          </Link1>
          <Link1>
            <Link>Link Four</Link>
          </Link1>
          <Link1>
            <Link>Link Five</Link>
          </Link1>
        </FooterLinks>
      </Column>
      <Column>
        <ColumnOne>Column Two</ColumnOne>
        <FooterLinks>
          <Link1>
            <Link>Link Six</Link>
          </Link1>
          <Link1>
            <Link>Link Seven</Link>
          </Link1>
          <Link1>
            <Link>Link Eight</Link>
          </Link1>
          <Link1>
            <Link>Link Nine</Link>
          </Link1>
          <Link1>
            <Link>Link Ten</Link>
          </Link1>
        </FooterLinks>
      </Column>
      <Column1>
        <ColumnOne>Follow Us</ColumnOne>
        <FooterLinks>
          <Link2>
            <IconFacebook alt="" src="/icon--facebook.svg" />
            <Facebook>Facebook</Facebook>
          </Link2>
          <Link2>
            <IconFacebook alt="" src="/icon--instagram.svg" />
            <Facebook>Instagram</Facebook>
          </Link2>
          <Link2>
            <IconFacebook alt="" src="/icon--twitter.svg" />
            <Facebook>Twitter</Facebook>
          </Link2>
          <Link2>
            <IconFacebook alt="" src="/icon--linkedin.svg" />
            <Facebook>LinkedIn</Facebook>
          </Link2>
        </FooterLinks>
      </Column1>
    </LinksRoot>
  );
};

export default Links;
