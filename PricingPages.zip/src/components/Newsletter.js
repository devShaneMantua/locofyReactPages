import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  position: relative;
  height: 27px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Placeholder = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--black);
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-xs);
  line-height: 150%;
  color: var(--black);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  color: var(--color-dimgray);
`;
const NewsletterRoot = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Newsletter = () => {
  return (
    <NewsletterRoot>
      <LogoIcon alt="" src="/logo.svg" />
      <Text1>
        Join our newsletter to stay up to date on features and releases.
      </Text1>
      <Actions>
        <Form>
          <TextInput>
            <Placeholder>Enter your email</Placeholder>
          </TextInput>
          <Button1>
            <Button>Subscribe</Button>
          </Button1>
        </Form>
        <Text2>
          {`By subscribing you agree to with our `}
          <PrivacyPolicy>Privacy Policy</PrivacyPolicy> and provide consent to
          receive updates from our company.
        </Text2>
      </Actions>
    </NewsletterRoot>
  );
};

export default Newsletter;
