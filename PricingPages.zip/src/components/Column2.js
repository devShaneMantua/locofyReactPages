import styled from "styled-components";

const IconRelume = styled.img`
  width: 48px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const DescribeFeatureOne = styled.p`
  margin: 0;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
`;
const ColumnRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: center;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Column2 = ({ describeFeatureOneAndIts }) => {
  return (
    <ColumnRoot>
      <IconRelume alt="" src="/icon--relume.svg" />
      <SectionTitle>
        <Heading>
          <DescribeFeatureOne>{describeFeatureOneAndIts}</DescribeFeatureOne>
          <DescribeFeatureOne>benefits</DescribeFeatureOne>
        </Heading>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla.
        </Text1>
      </SectionTitle>
      <Button1>
        <Button>Learn more</Button>
        <IconChevronRight alt="" src="/icon--chevron-right.svg" />
      </Button1>
    </ColumnRoot>
  );
};

export default Column2;
