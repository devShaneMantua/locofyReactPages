import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--text-small-link: Roboto;

/* font sizes */
--text-small-link-size: 14px;
--text-regular-semi-bold-size: 16px;
--font-size-xs: 12px;
--text-medium-normal-size: 18px;
--heading-h2-size: 48px;
--heading-h4-size: 32px;
--heading-h6-size: 20px;
--heading-h1-size: 56px;
--heading-h5-size: 24px;
--heading-h3-size: 40px;

/* Colors */
--white: #fff;
--black: #000;
--color-dimgray: #505050;
--neutral-gray: #8d8d8d;
--light-grey: #f4f4f4;

/* Gaps */
--gap-61xl: 80px;
--gap-13xl: 32px;
--gap-5xl: 24px;
--gap-109xl: 128px;
--gap-21xl: 40px;
--gap-base: 16px;
--gap-xs: 12px;
--gap-29xl: 48px;
--gap-5xs: 8px;
--gap-9xs: 4px;
--gap-45xl: 64px;
--gap-xl: 20px;

/* Paddings */
--padding-61xl: 80px;
--padding-45xl: 64px;
--padding-5xs: 8px;
--padding-xs: 12px;
--padding-5xl: 24px;
--padding-93xl: 112px;
--padding-base: 16px;
--padding-xl: 20px;
--padding-13xl: 32px;

/* Border radiuses */
--br-31xl: 50px;

}
`;
