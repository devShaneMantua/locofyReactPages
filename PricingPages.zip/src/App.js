import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Pricing from "./pages/Pricing";
import Pricing2 from "./pages/Pricing2";
import Pricing3 from "./pages/Pricing3";
import Pricing4 from "./pages/Pricing4";
import Pricing5 from "./pages/Pricing5";
import Pricing6 from "./pages/Pricing6";
import Pricing7 from "./pages/Pricing7";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/pricing-2":
        title = "";
        metaDescription = "";
        break;
      case "/pricing-3":
        title = "";
        metaDescription = "";
        break;
      case "/pricing-4":
        title = "";
        metaDescription = "";
        break;
      case "/pricing-5":
        title = "";
        metaDescription = "";
        break;
      case "/pricing-6":
        title = "";
        metaDescription = "";
        break;
      case "/pricing-7":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<Pricing />} />
      <Route path="/pricing-2" element={<Pricing2 />} />
      <Route path="/pricing-3" element={<Pricing3 />} />
      <Route path="/pricing-4" element={<Pricing4 />} />
      <Route path="/pricing-5" element={<Pricing5 />} />
      <Route path="/pricing-6" element={<Pricing6 />} />
      <Route path="/pricing-7" element={<Pricing7 />} />
    </Routes>
  );
}
export default App;
