import Navbar from "../components/Navbar";
import styled from "styled-components";
import Price from "../components/Price";
import List2 from "../components/List2";
import Content3 from "../components/Content3";
import List1 from "../components/List1";
import Column6 from "../components/Column6";
import List3 from "../components/List3";
import Content2 from "../components/Content2";

const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const RemindYourVisitor = styled.p`
  margin: 0;
`;
const Heading = styled.b`
  width: 768px;
  position: relative;
  line-height: 120%;
  display: inline-block;
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h1-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const IconRelume = styled.img`
  width: 48px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  border-top: 1px solid var(--black);
  box-sizing: border-box;
  height: 1px;
`;
const Text2 = styled.div`
  position: relative;
  line-height: 150%;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Button = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--white);
`;
const Content3 = styled.div`
  align-self: stretch;
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: space-between;
  padding: var(--padding-13xl);
`;
const Button1 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Content4 = styled.div`
  align-self: stretch;
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: space-between;
  padding: var(--padding-13xl);
  color: var(--white);
`;
const Content5 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  text-align: left;
`;
const Pricing = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  font-size: var(--text-regular-semi-bold-size);
`;
const Heading1 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text3 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle1 = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Column = styled.div`
  align-self: stretch;
  width: 420px;
`;
const Content6 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const TableHeader = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const FeatureCategory = styled.b`
  flex: 1;
  position: relative;
  line-height: 140%;
`;
const Row = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  box-sizing: border-box;
`;
const Content7 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) 0px 0px;
`;
const Column1 = styled.div`
  align-self: stretch;
  width: 400px;
`;
const Column2 = styled.div`
  align-self: stretch;
  flex: 1;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
`;
const Content8 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const TableButtons = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) 0px 0px;
  box-sizing: border-box;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--white);
`;
const Table = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--heading-h6-size);
`;
const Pricing1 = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
`;
const SectionTitle2 = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Divider1 = styled.div`
  align-self: stretch;
  position: relative;
  background-color: var(--black);
  height: 1px;
`;
const Question = styled.b`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Icon = styled.img`
  width: 32px;
  position: relative;
  height: 32px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Title = styled.div`
  align-self: stretch;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  gap: var(--gap-xs);
`;
const AccordionItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Column3 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Content9 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  text-align: left;
  font-size: var(--text-medium-normal-size);
`;
const Content10 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Button2 = styled.div`
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Button3 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--black);
`;
const Actions = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
  gap: var(--gap-base);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--white);
`;
const Text4 = styled.div`
  width: 1312px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const WebflowBlack = styled.img`
  width: 120px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const RelumeBlack = styled.img`
  width: 140px;
  position: relative;
  height: 56px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Logos = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-29xl);
`;
const TextParent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-semi-bold-size);
`;
const Cta = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-29xl);
`;
const LogoIcon = styled.img`
  width: 63px;
  position: relative;
  height: 27px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Text5 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Placeholder = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const Text6 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-xs);
  line-height: 150%;
  color: var(--black);
`;
const Actions1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  color: var(--color-dimgray);
`;
const Newsletter = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Link = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column4 = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const IconFacebook = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-xs);
`;
const Column5 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Links = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
`;
const Content11 = styled.div`
  width: 1312px;
  height: 248px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-109xl);
`;
const Link2 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const FooterLinks1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
`;
const Credits = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
`;
const Footer = styled.div`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  gap: var(--gap-61xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
`;
const PricingRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Pricing4 = () => {
  return (
    <PricingRoot>
      <Navbar />
      <Pricing>
        <SectionTitle>
          <Subheading>Pricing plans</Subheading>
          <Content>
            <Heading>
              <RemindYourVisitor>Remind your visitor why</RemindYourVisitor>
              <RemindYourVisitor>they should sign up</RemindYourVisitor>
            </Heading>
            <Text1>
              Describe how you have structured your pricing plan and finish with
              a strong call to action.
            </Text1>
          </Content>
        </SectionTitle>
        <Content5>
          <Content3>
            <Content2>
              <IconRelume alt="" src="/icon--relume.svg" />
              <Price heading="Basic plan" prop="$19" text="or $199 yearly" />
              <Divider />
              <Content1>
                <Text2>Includes:</Text2>
                <List2
                  listFlex="unset"
                  listAlignSelf="stretch"
                  listPadding="var(--padding-5xs) 0px"
                  textFlex="unset"
                  textFlex1="unset"
                  textFlex2="unset"
                />
              </Content1>
            </Content2>
            <Button>
              <Text2>Get started</Text2>
            </Button>
          </Content3>
          <Content4>
            <Content2>
              <IconRelume alt="" src="/icon--relume.svg" />
              <Price heading="Business plan" prop="$29" text="or $299 yearly" />
              <Divider />
              <Content3 />
            </Content2>
            <Button1>
              <Text2>Get started</Text2>
            </Button1>
          </Content4>
          <Content3>
            <Content2>
              <IconRelume alt="" src="/icon--relume.svg" />
              <Price
                heading="Enterprise plan"
                prop="$49"
                text="or $499 yearly"
              />
              <Divider />
              <Content1>
                <Text2>Includes:</Text2>
                <List1
                  listFlex="unset"
                  listAlignSelf="stretch"
                  listPadding="var(--padding-5xs) 0px"
                  textFlex="unset"
                  textFlex1="unset"
                  textFlex2="unset"
                  textFlex3="unset"
                  textFlex4="unset"
                />
              </Content1>
            </Content2>
            <Button>
              <Text2>Get started</Text2>
            </Button>
          </Content3>
        </Content5>
      </Pricing>
      <Pricing1>
        <SectionTitle1>
          <Heading1>Compare plans</Heading1>
          <Text3>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text3>
        </SectionTitle1>
        <Table>
          <TableHeader>
            <Content6>
              <Column />
              <Column6 heading="Basic" prop="$19" />
              <Column6 heading="Business" prop="$29" />
              <Column6 heading="Enterprise" prop="$49" />
            </Content6>
          </TableHeader>
          <TableHeader>
            <Content7>
              <Row>
                <FeatureCategory>Feature Category</FeatureCategory>
              </Row>
            </Content7>
            <List3 />
            <Content7>
              <Row>
                <FeatureCategory>Feature Category</FeatureCategory>
              </Row>
            </Content7>
            <List3 />
            <Content7>
              <Row>
                <FeatureCategory>Feature Category</FeatureCategory>
              </Row>
            </Content7>
            <List3 />
          </TableHeader>
          <TableButtons>
            <Content8>
              <Column1 />
              <Column2>
                <Button1>
                  <Text2>Get started</Text2>
                </Button1>
              </Column2>
              <Column2>
                <Button1>
                  <Text2>Get started</Text2>
                </Button1>
              </Column2>
              <Column2>
                <Button1>
                  <Text2>Get started</Text2>
                </Button1>
              </Column2>
            </Content8>
          </TableButtons>
        </Table>
      </Pricing1>
      <Pricing1>
        <SectionTitle2>
          <Heading1>Frequently asked questions</Heading1>
          <Text3>
            Frequently asked questions ordered by popularity. Remember that if
            the visitor has not committed to the call to action, they may still
            have questions (doubts) that can be answered.
          </Text3>
        </SectionTitle2>
        <Content9>
          <Column3>
            <AccordionItem>
              <Divider1 />
              <Title>
                <Question>Question text goes here</Question>
                <Icon alt="" src="/icon.svg" />
              </Title>
            </AccordionItem>
            <AccordionItem>
              <Divider1 />
              <Title>
                <Question>Question text goes here</Question>
                <Icon alt="" src="/icon.svg" />
              </Title>
            </AccordionItem>
            <AccordionItem>
              <Divider1 />
              <Title>
                <Question>Question text goes here</Question>
                <Icon alt="" src="/icon.svg" />
              </Title>
            </AccordionItem>
            <AccordionItem>
              <Divider1 />
              <Title>
                <Question>Question text goes here</Question>
                <Icon alt="" src="/icon.svg" />
              </Title>
            </AccordionItem>
            <AccordionItem>
              <Divider1 />
              <Title>
                <Question>Question text goes here</Question>
                <Icon alt="" src="/icon.svg" />
              </Title>
            </AccordionItem>
            <Divider1 />
          </Column3>
          <Column3>
            <AccordionItem>
              <Divider1 />
              <Title>
                <Question>Question text goes here</Question>
                <Icon alt="" src="/icon.svg" />
              </Title>
            </AccordionItem>
            <AccordionItem>
              <Divider1 />
              <Title>
                <Question>Question text goes here</Question>
                <Icon alt="" src="/icon.svg" />
              </Title>
            </AccordionItem>
            <AccordionItem>
              <Divider1 />
              <Title>
                <Question>Question text goes here</Question>
                <Icon alt="" src="/icon.svg" />
              </Title>
            </AccordionItem>
            <AccordionItem>
              <Divider1 />
              <Title>
                <Question>Question text goes here</Question>
                <Icon alt="" src="/icon.svg" />
              </Title>
            </AccordionItem>
            <AccordionItem>
              <Divider1 />
              <Title>
                <Question>Question text goes here</Question>
                <Icon alt="" src="/icon.svg" />
              </Title>
            </AccordionItem>
            <Divider1 />
          </Column3>
        </Content9>
        <Content2 propTextAlign="center" propTextAlign1="center" />
      </Pricing1>
      <Cta>
        <SectionTitle1>
          <Content10>
            <Heading1>
              Call to action that persuades the visitor to take action
            </Heading1>
            <Text3>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique.
            </Text3>
          </Content10>
          <Actions>
            <Button2>
              <Text2>Get started</Text2>
            </Button2>
            <Button3>
              <Text2>Learn more</Text2>
            </Button3>
          </Actions>
        </SectionTitle1>
        <TextParent>
          <Text4>
            Trusted by the world's best companies [social proof to build
            credibility]
          </Text4>
          <Logos>
            <WebflowBlack alt="" src="/webflow--black.svg" />
            <RelumeBlack alt="" src="/relume--black.svg" />
            <WebflowBlack alt="" src="/webflow--black.svg" />
            <RelumeBlack alt="" src="/relume--black.svg" />
            <WebflowBlack alt="" src="/webflow--black.svg" />
            <RelumeBlack alt="" src="/relume--black.svg" />
          </Logos>
        </TextParent>
      </Cta>
      <Footer>
        <Content11>
          <Newsletter>
            <LogoIcon alt="" src="/logo.svg" />
            <Text5>
              Join our newsletter to stay up to date on features and releases.
            </Text5>
            <Actions1>
              <Form>
                <TextInput>
                  <Placeholder>Enter your email</Placeholder>
                </TextInput>
                <Button3>
                  <Text2>Subscribe</Text2>
                </Button3>
              </Form>
              <Text6>
                {`By subscribing you agree to with our `}
                <PrivacyPolicy>Privacy Policy</PrivacyPolicy> and provide
                consent to receive updates from our company.
              </Text6>
            </Actions1>
          </Newsletter>
          <Links>
            <Column4>
              <Subheading>Column One</Subheading>
              <FooterLinks>
                <Link>
                  <Placeholder>Link One</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Two</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Three</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Four</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Five</Placeholder>
                </Link>
              </FooterLinks>
            </Column4>
            <Column4>
              <Subheading>Column Two</Subheading>
              <FooterLinks>
                <Link>
                  <Placeholder>Link Six</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Seven</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Eight</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Nine</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Ten</Placeholder>
                </Link>
              </FooterLinks>
            </Column4>
            <Column5>
              <Subheading>Follow Us</Subheading>
              <FooterLinks>
                <Link1>
                  <IconFacebook alt="" src="/icon--facebook.svg" />
                  <Text2>Facebook</Text2>
                </Link1>
                <Link1>
                  <IconFacebook alt="" src="/icon--instagram.svg" />
                  <Text2>Instagram</Text2>
                </Link1>
                <Link1>
                  <IconFacebook alt="" src="/icon--twitter.svg" />
                  <Text2>Twitter</Text2>
                </Link1>
                <Link1>
                  <IconFacebook alt="" src="/icon--linkedin.svg" />
                  <Text2>LinkedIn</Text2>
                </Link1>
              </FooterLinks>
            </Column5>
          </Links>
        </Content11>
        <Credits>
          <Divider1 />
          <Row1>
            <Text2>© 2023 Relume. All rights reserved.</Text2>
            <FooterLinks1>
              <Link2>Privacy Policy</Link2>
              <Link2>Terms of Service</Link2>
              <Link2>Cookies Settings</Link2>
            </FooterLinks1>
          </Row1>
        </Credits>
      </Footer>
    </PricingRoot>
  );
};

export default Pricing4;
