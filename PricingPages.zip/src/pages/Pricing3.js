import Navbar from "../components/Navbar";
import styled from "styled-components";
import PriceTitle from "../components/PriceTitle";
import List2 from "../components/List2";
import List1 from "../components/List1";
import Content2 from "../components/Content2";
import Container from "../components/Container";

const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.b`
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h1-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  text-align: center;
`;
const Monthly = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button = styled.div`
  background-color: var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--black);
`;
const Tabs = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  color: var(--white);
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  border-top: 1px solid var(--black);
  box-sizing: border-box;
  height: 1px;
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-5xl);
`;
const Content2 = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button2 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--white);
`;
const Content3 = styled.div`
  align-self: stretch;
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl);
  gap: var(--gap-13xl);
`;
const Content4 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Content5 = styled.div`
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl);
  gap: var(--gap-13xl);
`;
const Content6 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Pricing = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-29xl);
`;
const Heading1 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text3 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle1 = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Question = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Text4 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const List = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
`;
const Content7 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  font-size: var(--text-medium-normal-size);
`;
const Faq = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  font-size: var(--heading-h2-size);
`;
const Heading2 = styled.b`
  width: 768px;
  position: relative;
  line-height: 120%;
  display: inline-block;
`;
const Text5 = styled.div`
  width: 560px;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const SectionTitle2 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Content8 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-45xl);
`;
const Dot = styled.div`
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--black);
  height: 8px;
`;
const Dot1 = styled.div`
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--neutral-gray);
  height: 8px;
`;
const SliderDots = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Icon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button3 = styled.div`
  border-radius: var(--br-31xl);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs);
`;
const SliderButtons = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 15px;
`;
const Content9 = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;
const Content10 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
`;
const Testimonial = styled.div`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  gap: var(--gap-61xl);
  font-size: var(--heading-h3-size);
`;
const Content11 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Button4 = styled.div`
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Actions = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
  gap: var(--gap-base);
  font-size: var(--text-regular-semi-bold-size);
  color: var(--white);
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const PlaceholderImage = styled.img`
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  height: 400px;
  object-fit: cover;
`;
const Cta = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  font-size: var(--heading-h2-size);
`;
const LogoIcon = styled.img`
  width: 63px;
  position: relative;
  height: 27px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Placeholder = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const Text6 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-xs);
  line-height: 150%;
  color: var(--black);
`;
const Actions1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  color: var(--color-dimgray);
`;
const Newsletter = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Link = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column1 = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-xs);
`;
const Column2 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Links = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
`;
const Content12 = styled.div`
  width: 1312px;
  height: 248px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-109xl);
`;
const Divider1 = styled.div`
  align-self: stretch;
  position: relative;
  background-color: var(--black);
  height: 1px;
`;
const Link2 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const FooterLinks1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
`;
const Credits = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
`;
const Footer = styled.div`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  gap: var(--gap-61xl);
`;
const PricingRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Pricing3 = () => {
  return (
    <PricingRoot>
      <Navbar />
      <Pricing>
        <SectionTitle>
          <Subheading>Pricing plans</Subheading>
          <Content>
            <Heading>Introduce pricing plans</Heading>
            <Text1>Simple, transparent pricing that grows with you.</Text1>
          </Content>
        </SectionTitle>
        <Tabs>
          <Button>
            <Monthly>Monthly</Monthly>
          </Button>
          <Button1>
            <Monthly>Yearly</Monthly>
          </Button1>
        </Tabs>
        <Content6>
          <Content3>
            <PriceTitle heading="Basic plan" prop="$19" />
            <Divider />
            <Content2>
              <Text2>Includes:</Text2>
              <Content1>
                <List2 />
                <List2
                  listFlex="1"
                  listAlignSelf="unset"
                  listPadding="unset"
                  textFlex="1"
                  textFlex1="1"
                  textFlex2="1"
                />
              </Content1>
            </Content2>
            <Button2>
              <Monthly>Get started</Monthly>
            </Button2>
          </Content3>
          <Content5>
            <PriceTitle heading="Business plan" prop="$29" />
            <Divider />
            <Content4>
              <Text2>Includes:</Text2>
              <Content1>
                <List1 />
                <List1
                  listFlex="1"
                  listAlignSelf="unset"
                  listPadding="unset"
                  textFlex="1"
                  textFlex1="1"
                  textFlex2="1"
                  textFlex3="1"
                  textFlex4="1"
                />
              </Content1>
            </Content4>
            <Button2>
              <Monthly>Get started</Monthly>
            </Button2>
          </Content5>
        </Content6>
      </Pricing>
      <Faq>
        <SectionTitle1>
          <Heading1>Frequently asked questions</Heading1>
          <Text3>
            Frequently asked questions ordered by popularity. Remember that if
            the visitor has not committed to the call to action, they may still
            have questions (doubts) that can be answered.
          </Text3>
        </SectionTitle1>
        <Content7>
          <List>
            <Content4>
              <Question>Question text goes here</Question>
              <Text4>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla, ut
                commodo diam libero vitae erat. Aenean faucibus nibh et justo
                cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus
                tristique posuere.
              </Text4>
            </Content4>
            <Content4>
              <Question>Question text goes here</Question>
              <Text4>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla, ut
                commodo diam libero vitae erat. Aenean faucibus nibh et justo
                cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus
                tristique posuere.
              </Text4>
            </Content4>
            <Content4>
              <Question>Question text goes here</Question>
              <Text4>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla, ut
                commodo diam libero vitae erat. Aenean faucibus nibh et justo
                cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus
                tristique posuere.
              </Text4>
            </Content4>
            <Content4>
              <Question>Question text goes here</Question>
              <Text4>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla, ut
                commodo diam libero vitae erat. Aenean faucibus nibh et justo
                cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus
                tristique posuere.
              </Text4>
            </Content4>
          </List>
          <List>
            <Content4>
              <Question>Question text goes here</Question>
              <Text4>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla, ut
                commodo diam libero vitae erat. Aenean faucibus nibh et justo
                cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus
                tristique posuere.
              </Text4>
            </Content4>
            <Content4>
              <Question>Question text goes here</Question>
              <Text4>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla, ut
                commodo diam libero vitae erat. Aenean faucibus nibh et justo
                cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus
                tristique posuere.
              </Text4>
            </Content4>
            <Content4>
              <Question>Question text goes here</Question>
              <Text4>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla, ut
                commodo diam libero vitae erat. Aenean faucibus nibh et justo
                cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus
                tristique posuere.
              </Text4>
            </Content4>
            <Content4>
              <Question>Question text goes here</Question>
              <Text4>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla, ut
                commodo diam libero vitae erat. Aenean faucibus nibh et justo
                cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus
                tristique posuere.
              </Text4>
            </Content4>
          </List>
        </Content7>
        <Content2 />
      </Faq>
      <Testimonial>
        <SectionTitle2>
          <Heading2>Customer testimonials</Heading2>
          <Text5>5,000+ happy customers</Text5>
        </SectionTitle2>
        <Content10>
          <Content8>
            <Container />
            <Container />
          </Content8>
          <Content9>
            <SliderDots>
              <Dot />
              <Dot1 />
              <Dot1 />
              <Dot1 />
            </SliderDots>
            <SliderButtons>
              <Button3>
                <Icon alt="" src="/icon.svg" />
              </Button3>
              <Button3>
                <Icon alt="" src="/icon.svg" />
              </Button3>
            </SliderButtons>
          </Content9>
        </Content10>
      </Testimonial>
      <Cta>
        <Column>
          <Content11>
            <Heading1>
              Call to action that invites the visitor to get started
            </Heading1>
            <Text3>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique.
            </Text3>
          </Content11>
          <Actions>
            <Button4>
              <Monthly>Get started</Monthly>
            </Button4>
            <Button1>
              <Monthly>Learn more</Monthly>
            </Button1>
          </Actions>
        </Column>
        <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
      </Cta>
      <Footer>
        <Content12>
          <Newsletter>
            <LogoIcon alt="" src="/logo.svg" />
            <Text2>
              Join our newsletter to stay up to date on features and releases.
            </Text2>
            <Actions1>
              <Form>
                <TextInput>
                  <Placeholder>Enter your email</Placeholder>
                </TextInput>
                <Button1>
                  <Monthly>Subscribe</Monthly>
                </Button1>
              </Form>
              <Text6>
                {`By subscribing you agree to with our `}
                <PrivacyPolicy>Privacy Policy</PrivacyPolicy> and provide
                consent to receive updates from our company.
              </Text6>
            </Actions1>
          </Newsletter>
          <Links>
            <Column1>
              <Subheading>Column One</Subheading>
              <FooterLinks>
                <Link>
                  <Placeholder>Link One</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Two</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Three</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Four</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Five</Placeholder>
                </Link>
              </FooterLinks>
            </Column1>
            <Column1>
              <Subheading>Column Two</Subheading>
              <FooterLinks>
                <Link>
                  <Placeholder>Link Six</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Seven</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Eight</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Nine</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Ten</Placeholder>
                </Link>
              </FooterLinks>
            </Column1>
            <Column2>
              <Subheading>Follow Us</Subheading>
              <FooterLinks>
                <Link1>
                  <Icon alt="" src="/icon--facebook.svg" />
                  <Monthly>Facebook</Monthly>
                </Link1>
                <Link1>
                  <Icon alt="" src="/icon--instagram.svg" />
                  <Monthly>Instagram</Monthly>
                </Link1>
                <Link1>
                  <Icon alt="" src="/icon--twitter.svg" />
                  <Monthly>Twitter</Monthly>
                </Link1>
                <Link1>
                  <Icon alt="" src="/icon--linkedin.svg" />
                  <Monthly>LinkedIn</Monthly>
                </Link1>
              </FooterLinks>
            </Column2>
          </Links>
        </Content12>
        <Credits>
          <Divider1 />
          <Row>
            <Monthly>© 2023 Relume. All rights reserved.</Monthly>
            <FooterLinks1>
              <Link2>Privacy Policy</Link2>
              <Link2>Terms of Service</Link2>
              <Link2>Cookies Settings</Link2>
            </FooterLinks1>
          </Row>
        </Credits>
      </Footer>
    </PricingRoot>
  );
};

export default Pricing3;
