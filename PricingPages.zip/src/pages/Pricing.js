import Navbar from "../components/Navbar";
import Pricing1 from "../components/Pricing1";
import Testimonial from "../components/Testimonial";
import styled from "styled-components";
import TableHeader from "../components/TableHeader";
import Content1 from "../components/Content1";
import FAQ from "../components/FAQ";
import Newsletter from "../components/Newsletter";
import Links from "../components/Links";

const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const LoremIpsumDolor = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Table = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Pricing2 = styled.div`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  gap: var(--gap-61xl);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Actions = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--white);
`;
const Header = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
`;
const Content2 = styled.div`
  width: 1312px;
  height: 248px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-109xl);
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  background-color: var(--black);
  height: 1px;
`;
const Link = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const FooterLinks = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
`;
const Credits = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Footer = styled.div`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  gap: var(--gap-61xl);
  text-align: left;
  font-size: var(--text-small-link-size);
`;
const PricingRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Pricing = () => {
  return (
    <PricingRoot>
      <Navbar />
      <Pricing1 />
      <Testimonial />
      <Pricing2>
        <SectionTitle>
          <Heading>Compare plans</Heading>
          <LoremIpsumDolor>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</LoremIpsumDolor>
        </SectionTitle>
        <Table>
          <TableHeader />
          <Content1 />
        </Table>
      </Pricing2>
      <FAQ />
      <Header>
        <SectionTitle>
          <Content>
            <Heading>
              Call to action that excites the visitor to try your product
            </Heading>
            <LoremIpsumDolor>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. `}</LoremIpsumDolor>
          </Content>
          <Actions>
            <Button1>
              <Button>Get started</Button>
            </Button1>
          </Actions>
        </SectionTitle>
      </Header>
      <Footer>
        <Content2>
          <Newsletter />
          <Links />
        </Content2>
        <Credits>
          <Divider />
          <Row>
            <Button>© 2023 Relume. All rights reserved.</Button>
            <FooterLinks>
              <Link>Privacy Policy</Link>
              <Link>Terms of Service</Link>
              <Link>Cookies Settings</Link>
            </FooterLinks>
          </Row>
        </Credits>
      </Footer>
    </PricingRoot>
  );
};

export default Pricing;
