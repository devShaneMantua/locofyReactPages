import Navbar from "../components/Navbar";
import styled from "styled-components";
import Column5 from "../components/Column5";
import Column4 from "../components/Column4";
import Column3 from "../components/Column3";
import Logo from "../components/Logo";
import Layout from "../components/Layout";
import FAQ1 from "../components/FAQ1";

const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.b`
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h1-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Pricing = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
`;
const LogoIcon = styled.img`
  width: 63px;
  position: relative;
  height: 27px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Placeholder = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--black);
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const Text3 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-xs);
  line-height: 150%;
  color: var(--black);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  color: var(--color-dimgray);
`;
const Newsletter = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Link = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const IconFacebook = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-xs);
`;
const Column1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Links = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
`;
const Content2 = styled.div`
  width: 1312px;
  height: 248px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-109xl);
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  background-color: var(--black);
  height: 1px;
`;
const Link2 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const FooterLinks1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
`;
const Credits = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
`;
const Footer = styled.div`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  gap: var(--gap-61xl);
  text-align: left;
`;
const PricingRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Pricing2 = () => {
  return (
    <PricingRoot>
      <Navbar />
      <Pricing>
        <SectionTitle>
          <Subheading>Pricing plans</Subheading>
          <Content>
            <Heading>Introduce pricing plans</Heading>
            <Text1>
              Simple, transparent pricing that grows with you. Try any plan free
              for 30 days.
            </Text1>
          </Content>
        </SectionTitle>
        <Content1>
          <Column5 />
          <Column4 />
          <Column3 />
        </Content1>
      </Pricing>
      <Logo />
      <Layout />
      <FAQ1 />
      <Footer>
        <Content2>
          <Newsletter>
            <LogoIcon alt="" src="/logo.svg" />
            <Text2>
              Join our newsletter to stay up to date on features and releases.
            </Text2>
            <Actions>
              <Form>
                <TextInput>
                  <Placeholder>Enter your email</Placeholder>
                </TextInput>
                <Button1>
                  <Button>Subscribe</Button>
                </Button1>
              </Form>
              <Text3>
                {`By subscribing you agree to with our `}
                <PrivacyPolicy>Privacy Policy</PrivacyPolicy> and provide
                consent to receive updates from our company.
              </Text3>
            </Actions>
          </Newsletter>
          <Links>
            <Column>
              <Subheading>Column One</Subheading>
              <FooterLinks>
                <Link>
                  <Placeholder>Link One</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Two</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Three</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Four</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Five</Placeholder>
                </Link>
              </FooterLinks>
            </Column>
            <Column>
              <Subheading>Column Two</Subheading>
              <FooterLinks>
                <Link>
                  <Placeholder>Link Six</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Seven</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Eight</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Nine</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Ten</Placeholder>
                </Link>
              </FooterLinks>
            </Column>
            <Column1>
              <Subheading>Follow Us</Subheading>
              <FooterLinks>
                <Link1>
                  <IconFacebook alt="" src="/icon--facebook.svg" />
                  <Button>Facebook</Button>
                </Link1>
                <Link1>
                  <IconFacebook alt="" src="/icon--instagram.svg" />
                  <Button>Instagram</Button>
                </Link1>
                <Link1>
                  <IconFacebook alt="" src="/icon--twitter.svg" />
                  <Button>Twitter</Button>
                </Link1>
                <Link1>
                  <IconFacebook alt="" src="/icon--linkedin.svg" />
                  <Button>LinkedIn</Button>
                </Link1>
              </FooterLinks>
            </Column1>
          </Links>
        </Content2>
        <Credits>
          <Divider />
          <Row>
            <Button>© 2023 Relume. All rights reserved.</Button>
            <FooterLinks1>
              <Link2>Privacy Policy</Link2>
              <Link2>Terms of Service</Link2>
              <Link2>Cookies Settings</Link2>
            </FooterLinks1>
          </Row>
        </Credits>
      </Footer>
    </PricingRoot>
  );
};

export default Pricing2;
