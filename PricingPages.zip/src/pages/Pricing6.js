import styled from "styled-components";

const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h2-size);
`;
const Content1 = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Monthly = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button = styled.div`
  background-color: var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Button1 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--black);
`;
const Tabs = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  color: var(--white);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-29xl);
`;
const Column = styled.div`
  align-self: stretch;
  width: 420px;
`;
const Heading1 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
`;
const Span = styled.span`
  line-height: 120%;
`;
const Mo = styled.span`
  font-size: var(--heading-h5-size);
  line-height: 140%;
`;
const Price = styled.b`
  align-self: stretch;
  position: relative;
`;
const PriceWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--heading-h1-size);
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Price1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button2 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--white);
`;
const Column1 = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 0px var(--padding-base);
  gap: var(--gap-13xl);
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const TableHeader = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: center;
`;
const Heading2 = styled.b`
  position: relative;
  line-height: 140%;
`;
const Row = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  box-sizing: border-box;
`;
const Content3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) 0px 0px;
`;
const Text3 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TableCell = styled.div`
  width: 420px;
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl);
  box-sizing: border-box;
  text-align: left;
`;
const Text4 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const TableCell1 = styled.div`
  flex: 1;
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-base) var(--padding-5xl);
`;
const Row1 = styled.div`
  align-self: stretch;
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: center;
`;
const TableCell2 = styled.div`
  width: 420px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl);
  box-sizing: border-box;
`;
const CheckIcon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const TableCell3 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-base) var(--padding-5xl);
`;
const TableCell4 = styled.div`
  width: 420px;
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl);
  box-sizing: border-box;
`;
const Row2 = styled.div`
  align-self: stretch;
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const CheckIcon1 = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
  display: none;
`;
const List = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-regular-semi-bold-size);
`;
const Content4 = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Column2 = styled.div`
  align-self: stretch;
  width: 400px;
`;
const Button3 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Column3 = styled.div`
  align-self: stretch;
  flex: 1;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
`;
const Content5 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const TableButtons = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) 0px 0px;
  box-sizing: border-box;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--white);
`;
const Table = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--heading-h6-size);
`;
const PricingRoot = styled.div`
  width: 100%;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Pricing6 = () => {
  return (
    <PricingRoot>
      <SectionTitle>
        <Content1>
          <Subheading>Tagline</Subheading>
          <Content>
            <Heading>Pricing plan</Heading>
            <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
          </Content>
        </Content1>
        <Tabs>
          <Button>
            <Monthly>Monthly</Monthly>
          </Button>
          <Button1>
            <Monthly>Yearly</Monthly>
          </Button1>
        </Tabs>
      </SectionTitle>
      <Table>
        <TableHeader>
          <Content2>
            <Column />
            <Column1>
              <Price1>
                <Heading1>Basic</Heading1>
                <PriceWrapper>
                  <Price>
                    <Span>$19</Span>
                    <Mo>/mo</Mo>
                  </Price>
                </PriceWrapper>
                <Text2>Lorem ipsum dolor sit amet</Text2>
              </Price1>
              <Button2>
                <Monthly>Get started</Monthly>
              </Button2>
            </Column1>
            <Column1>
              <Price1>
                <Heading1>Business</Heading1>
                <PriceWrapper>
                  <Price>
                    <Span>$29</Span>
                    <Mo>/mo</Mo>
                  </Price>
                </PriceWrapper>
                <Text2>Lorem ipsum dolor sit amet</Text2>
              </Price1>
              <Button2>
                <Monthly>Get started</Monthly>
              </Button2>
            </Column1>
            <Column1>
              <Price1>
                <Heading1>Enterprise</Heading1>
                <PriceWrapper>
                  <Price>
                    <Span>$49</Span>
                    <Mo>/mo</Mo>
                  </Price>
                </PriceWrapper>
                <Text2>Lorem ipsum dolor sit amet</Text2>
              </Price1>
              <Button2>
                <Monthly>Get started</Monthly>
              </Button2>
            </Column1>
          </Content2>
        </TableHeader>
        <Content4>
          <Content3>
            <Row>
              <Heading2>Feature Category</Heading2>
            </Row>
          </Content3>
          <List>
            <Row1>
              <TableCell>
                <Text3>Feature text goes here</Text3>
              </TableCell>
              <TableCell1>
                <Text4>10</Text4>
              </TableCell1>
              <TableCell1>
                <Text4>25</Text4>
              </TableCell1>
              <TableCell1>
                <Text4>Unlimited</Text4>
              </TableCell1>
            </Row1>
            <Content2>
              <TableCell2>
                <Text3>Feature text goes here</Text3>
              </TableCell2>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
            </Content2>
            <Row2>
              <TableCell4>
                <Text3>Feature text goes here</Text3>
              </TableCell4>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
            </Row2>
            <Content2>
              <TableCell2>
                <Text3>Feature text goes here</Text3>
              </TableCell2>
              <TableCell3>
                <CheckIcon1 alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
            </Content2>
            <Row2>
              <TableCell4>
                <Text3>Feature text goes here</Text3>
              </TableCell4>
              <TableCell1>
                <CheckIcon1 alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon1 alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
            </Row2>
          </List>
          <Content3>
            <Row>
              <Heading2>Feature Category</Heading2>
            </Row>
          </Content3>
          <List>
            <Row1>
              <TableCell>
                <Text3>Feature text goes here</Text3>
              </TableCell>
              <TableCell1>
                <Text4>10</Text4>
              </TableCell1>
              <TableCell1>
                <Text4>25</Text4>
              </TableCell1>
              <TableCell1>
                <Text4>Unlimited</Text4>
              </TableCell1>
            </Row1>
            <Content2>
              <TableCell2>
                <Text3>Feature text goes here</Text3>
              </TableCell2>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
            </Content2>
            <Row2>
              <TableCell4>
                <Text3>Feature text goes here</Text3>
              </TableCell4>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
            </Row2>
            <Content2>
              <TableCell2>
                <Text3>Feature text goes here</Text3>
              </TableCell2>
              <TableCell3>
                <CheckIcon1 alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
            </Content2>
            <Row2>
              <TableCell4>
                <Text3>Feature text goes here</Text3>
              </TableCell4>
              <TableCell1>
                <CheckIcon1 alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon1 alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
            </Row2>
          </List>
          <Content3>
            <Row>
              <Heading2>Feature Category</Heading2>
            </Row>
          </Content3>
          <List>
            <Row1>
              <TableCell>
                <Text3>Feature text goes here</Text3>
              </TableCell>
              <TableCell1>
                <Text4>10</Text4>
              </TableCell1>
              <TableCell1>
                <Text4>25</Text4>
              </TableCell1>
              <TableCell1>
                <Text4>Unlimited</Text4>
              </TableCell1>
            </Row1>
            <Content2>
              <TableCell2>
                <Text3>Feature text goes here</Text3>
              </TableCell2>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
            </Content2>
            <Row2>
              <TableCell4>
                <Text3>Feature text goes here</Text3>
              </TableCell4>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
            </Row2>
            <Content2>
              <TableCell2>
                <Text3>Feature text goes here</Text3>
              </TableCell2>
              <TableCell3>
                <CheckIcon1 alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
              <TableCell3>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell3>
            </Content2>
            <Row2>
              <TableCell4>
                <Text3>Feature text goes here</Text3>
              </TableCell4>
              <TableCell1>
                <CheckIcon1 alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon1 alt="" src="/check.svg" />
              </TableCell1>
              <TableCell1>
                <CheckIcon alt="" src="/check.svg" />
              </TableCell1>
            </Row2>
          </List>
        </Content4>
        <TableButtons>
          <Content5>
            <Column2 />
            <Column3>
              <Button3>
                <Monthly>Get started</Monthly>
              </Button3>
            </Column3>
            <Column3>
              <Button3>
                <Monthly>Get started</Monthly>
              </Button3>
            </Column3>
            <Column3>
              <Button3>
                <Monthly>Get started</Monthly>
              </Button3>
            </Column3>
          </Content5>
        </TableButtons>
      </Table>
    </PricingRoot>
  );
};

export default Pricing6;
