import Navbar from "../components/Navbar";
import styled from "styled-components";
import Content3 from "../components/Content3";
import Column7 from "../components/Column7";

const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.b`
  width: 768px;
  position: relative;
  line-height: 120%;
  display: inline-block;
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h1-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const IconRelume = styled.img`
  width: 48px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading1 = styled.b`
  position: relative;
  line-height: 140%;
`;
const Span = styled.span`
  line-height: 120%;
`;
const Mo = styled.span`
  font-size: var(--heading-h4-size);
  line-height: 130%;
`;
const Price = styled.b`
  position: relative;
  font-size: var(--heading-h1-size);
`;
const Text2 = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Price1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  border-top: 1px solid var(--black);
  box-sizing: border-box;
  height: 1px;
`;
const Text3 = styled.div`
  position: relative;
  line-height: 150%;
`;
const CheckIcon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const ListItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const List = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-base);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Button = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--white);
`;
const Content3 = styled.div`
  align-self: stretch;
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: space-between;
  padding: var(--padding-13xl);
`;
const Content4 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  text-align: center;
  font-size: var(--heading-h6-size);
`;
const Pricing = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  font-size: var(--text-regular-semi-bold-size);
`;
const Heading2 = styled.b`
  width: 320px;
  position: relative;
  line-height: 140%;
  display: inline-block;
  flex-shrink: 0;
`;
const WebflowBlack = styled.img`
  width: 120px;
  position: relative;
  height: 48px;
  overflow: hidden;
  flex-shrink: 0;
`;
const RelumeBlack = styled.img`
  width: 140px;
  position: relative;
  height: 56px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Content5 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-end;
  gap: var(--gap-13xl);
`;
const Logo = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-45xl);
  font-size: var(--heading-h5-size);
`;
const Subheading1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading3 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 130%;
`;
const Text4 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Content6 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h4-size);
`;
const SectionTitle1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Column = styled.div`
  width: 405.3px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Content7 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  font-size: var(--text-regular-semi-bold-size);
`;
const Layout = styled.div`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  gap: var(--gap-61xl);
`;
const Heading4 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const Text5 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle2 = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Divider1 = styled.div`
  align-self: stretch;
  position: relative;
  background-color: var(--black);
  height: 1px;
`;
const Question = styled.b`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Icon = styled.img`
  width: 32px;
  position: relative;
  height: 32px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Title = styled.div`
  align-self: stretch;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  gap: var(--gap-xs);
`;
const AccordionItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Accordion = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-medium-normal-size);
`;
const Faq = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
`;
const Content8 = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Button2 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
`;
const Button3 = styled.div`
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--white);
`;
const Actions = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-end;
  gap: var(--gap-base);
  font-size: var(--text-regular-semi-bold-size);
`;
const Cta = styled.div`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
`;
const LogoIcon = styled.img`
  width: 63px;
  position: relative;
  height: 27px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Text6 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Placeholder = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs);
`;
const Button4 = styled.div`
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--black);
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const Text7 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-xs);
  line-height: 150%;
  color: var(--black);
`;
const Actions1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  color: var(--color-dimgray);
`;
const Link = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column1 = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-xs);
`;
const Column2 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Links = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
`;
const Content9 = styled.div`
  width: 1312px;
  height: 248px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-109xl);
`;
const Link2 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const FooterLinks1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
`;
const Credits = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
`;
const Footer = styled.div`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  gap: var(--gap-61xl);
  font-size: var(--text-regular-semi-bold-size);
`;
const PricingRoot = styled.div`
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Pricing5 = () => {
  return (
    <PricingRoot>
      <Navbar />
      <Pricing>
        <SectionTitle>
          <Subheading>Pricing plans</Subheading>
          <Content>
            <Heading>Introduce pricing plans</Heading>
            <Text1>
              Describe how you have structured your pricing plan and finish with
              a strong call to action.
            </Text1>
          </Content>
        </SectionTitle>
        <Content4>
          <Content3>
            <Content2>
              <IconRelume alt="" src="/icon--relume.svg" />
              <Price1>
                <Heading1>Basic plan</Heading1>
                <Price>
                  <Span>$19</Span>
                  <Mo>/mo</Mo>
                </Price>
                <Text2>or $199 yearly</Text2>
              </Price1>
              <Divider />
              <Content1>
                <Text3>Includes:</Text3>
                <List>
                  <ListItem>
                    <CheckIcon alt="" src="/check.svg" />
                    <Text3>Feature text goes here</Text3>
                  </ListItem>
                  <ListItem>
                    <CheckIcon alt="" src="/check.svg" />
                    <Text3>Feature text goes here</Text3>
                  </ListItem>
                  <ListItem>
                    <CheckIcon alt="" src="/check.svg" />
                    <Text3>Feature text goes here</Text3>
                  </ListItem>
                </List>
              </Content1>
            </Content2>
            <Button>
              <Text3>Get started</Text3>
            </Button>
          </Content3>
          <Content3>
            <Content2>
              <IconRelume alt="" src="/icon--relume.svg" />
              <Price1>
                <Heading1>Business plan</Heading1>
                <Price>
                  <Span>$29</Span>
                  <Mo>/mo</Mo>
                </Price>
                <Text2>or $299 yearly</Text2>
              </Price1>
              <Divider />
              <Content3 />
            </Content2>
            <Button>
              <Text3>Get started</Text3>
            </Button>
          </Content3>
          <Content3>
            <Content2>
              <IconRelume alt="" src="/icon--relume.svg" />
              <Price1>
                <Heading1>Enterprise plan</Heading1>
                <Price>
                  <Span>$49</Span>
                  <Mo>/mo</Mo>
                </Price>
                <Text2>or $499 yearly</Text2>
              </Price1>
              <Divider />
              <Content1>
                <Text3>Includes:</Text3>
                <List>
                  <ListItem>
                    <CheckIcon alt="" src="/check.svg" />
                    <Text3>Feature text goes here</Text3>
                  </ListItem>
                  <ListItem>
                    <CheckIcon alt="" src="/check.svg" />
                    <Text3>Feature text goes here</Text3>
                  </ListItem>
                  <ListItem>
                    <CheckIcon alt="" src="/check.svg" />
                    <Text3>Feature text goes here</Text3>
                  </ListItem>
                  <ListItem>
                    <CheckIcon alt="" src="/check.svg" />
                    <Text3>Feature text goes here</Text3>
                  </ListItem>
                  <ListItem>
                    <CheckIcon alt="" src="/check.svg" />
                    <Text3>Feature text goes here</Text3>
                  </ListItem>
                </List>
              </Content1>
            </Content2>
            <Button>
              <Text3>Get started</Text3>
            </Button>
          </Content3>
        </Content4>
      </Pricing>
      <Logo>
        <Heading2>
          Trusted by the world's best companies [social proof to build
          credibility]
        </Heading2>
        <Content5>
          <WebflowBlack alt="" src="/webflow--black.svg" />
          <RelumeBlack alt="" src="/relume--black.svg" />
          <WebflowBlack alt="" src="/webflow--black.svg" />
          <RelumeBlack alt="" src="/relume--black.svg" />
          <WebflowBlack alt="" src="/webflow--black.svg" />
        </Content5>
      </Logo>
      <Layout>
        <Heading>Highlight key features of the product or service</Heading>
        <Content7>
          <Column7
            subheading="Feature one"
            describeFeatureOneAnd="Describe feature one and"
          />
          <Column7
            subheading="Feature two"
            describeFeatureOneAnd="Describe feature two and"
          />
          <Column>
            <SectionTitle1>
              <Subheading1>Feature three</Subheading1>
              <Content6>
                <Heading3>Describe feature three and its benefits</Heading3>
                <Text4>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros elementum tristique. Duis
                  cursus, mi quis viverra ornare, eros dolor interdum nulla.
                </Text4>
              </Content6>
            </SectionTitle1>
            <Button1>
              <Text3>Learn more</Text3>
              <CheckIcon alt="" src="/icon--chevron-right.svg" />
            </Button1>
          </Column>
        </Content7>
      </Layout>
      <Faq>
        <SectionTitle2>
          <Heading4>Frequently asked questions</Heading4>
          <Text5>
            Frequently asked questions ordered by popularity. Remember that if
            the visitor has not committed to the call to action, they may still
            have questions (doubts) that can be answered.
          </Text5>
        </SectionTitle2>
        <Accordion>
          <AccordionItem>
            <Divider1 />
            <Title>
              <Question>Question text goes here</Question>
              <Icon alt="" src="/icon.svg" />
            </Title>
          </AccordionItem>
          <AccordionItem>
            <Divider1 />
            <Title>
              <Question>Question text goes here</Question>
              <Icon alt="" src="/icon.svg" />
            </Title>
          </AccordionItem>
          <AccordionItem>
            <Divider1 />
            <Title>
              <Question>Question text goes here</Question>
              <Icon alt="" src="/icon.svg" />
            </Title>
          </AccordionItem>
          <AccordionItem>
            <Divider1 />
            <Title>
              <Question>Question text goes here</Question>
              <Icon alt="" src="/icon.svg" />
            </Title>
          </AccordionItem>
          <AccordionItem>
            <Divider1 />
            <Title>
              <Question>Question text goes here</Question>
              <Icon alt="" src="/icon.svg" />
            </Title>
          </AccordionItem>
          <Divider1 />
        </Accordion>
      </Faq>
      <Cta>
        <Content8>
          <Heading4>
            Call to action that invites the visitor to try your product
          </Heading4>
          <Text5>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text5>
        </Content8>
        <Actions>
          <Button2>
            <Text3>Chat to sales</Text3>
          </Button2>
          <Button3>
            <Text3>Get started</Text3>
          </Button3>
        </Actions>
      </Cta>
      <Footer>
        <Content9>
          <SectionTitle2>
            <LogoIcon alt="" src="/logo.svg" />
            <Text6>
              Join our newsletter to stay up to date on features and releases.
            </Text6>
            <Actions1>
              <ListItem>
                <TextInput>
                  <Placeholder>Enter your email</Placeholder>
                </TextInput>
                <Button4>
                  <Text3>Subscribe</Text3>
                </Button4>
              </ListItem>
              <Text7>
                {`By subscribing you agree to with our `}
                <PrivacyPolicy>Privacy Policy</PrivacyPolicy> and provide
                consent to receive updates from our company.
              </Text7>
            </Actions1>
          </SectionTitle2>
          <Links>
            <Column1>
              <Subheading>Column One</Subheading>
              <FooterLinks>
                <Link>
                  <Placeholder>Link One</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Two</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Three</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Four</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Five</Placeholder>
                </Link>
              </FooterLinks>
            </Column1>
            <Column1>
              <Subheading>Column Two</Subheading>
              <FooterLinks>
                <Link>
                  <Placeholder>Link Six</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Seven</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Eight</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Nine</Placeholder>
                </Link>
                <Link>
                  <Placeholder>Link Ten</Placeholder>
                </Link>
              </FooterLinks>
            </Column1>
            <Column2>
              <Subheading>Follow Us</Subheading>
              <FooterLinks>
                <Link1>
                  <CheckIcon alt="" src="/icon--facebook.svg" />
                  <Text3>Facebook</Text3>
                </Link1>
                <Link1>
                  <CheckIcon alt="" src="/icon--instagram.svg" />
                  <Text3>Instagram</Text3>
                </Link1>
                <Link1>
                  <CheckIcon alt="" src="/icon--twitter.svg" />
                  <Text3>Twitter</Text3>
                </Link1>
                <Link1>
                  <CheckIcon alt="" src="/icon--linkedin.svg" />
                  <Text3>LinkedIn</Text3>
                </Link1>
              </FooterLinks>
            </Column2>
          </Links>
        </Content9>
        <Credits>
          <Divider1 />
          <Row>
            <Text3>© 2023 Relume. All rights reserved.</Text3>
            <FooterLinks1>
              <Link2>Privacy Policy</Link2>
              <Link2>Terms of Service</Link2>
              <Link2>Cookies Settings</Link2>
            </FooterLinks1>
          </Row>
        </Credits>
      </Footer>
    </PricingRoot>
  );
};

export default Pricing5;
