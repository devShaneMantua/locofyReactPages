import styled from "styled-components";
import ListItem from "../components/ListItem";

const Tagline = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const PricingPlan = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 120%;
`;
const LoremIpsumDolor = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const List = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-13xl);
`;
const Heading = styled.b`
  position: relative;
  line-height: 140%;
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
`;
const Title = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Span = styled.span`
  line-height: 120%;
`;
const Mo = styled.span`
  font-size: var(--heading-h4-size);
  line-height: 130%;
`;
const Price = styled.b`
  position: relative;
  font-size: var(--heading-h1-size);
`;
const PriceTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  text-align: center;
  font-size: var(--heading-h5-size);
`;
const Divider = styled.div`
  align-self: stretch;
  position: relative;
  border-top: 1px solid var(--black);
  box-sizing: border-box;
  height: 1px;
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const CheckIcon = styled.img`
  width: 24px;
  position: relative;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
`;
const Text3 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const ListItem1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const List1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-5xl);
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  align-self: stretch;
  background-color: var(--black);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-5xl);
  color: var(--white);
`;
const Content3 = styled.div`
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl);
  gap: var(--gap-13xl);
`;
const Content4 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  text-align: left;
`;
const PricingRoot = styled.div`
  width: 100%;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  text-align: center;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Pricing7 = () => {
  return (
    <PricingRoot>
      <SectionTitle>
        <Tagline>Tagline</Tagline>
        <Content>
          <PricingPlan>Pricing plan</PricingPlan>
          <LoremIpsumDolor>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</LoremIpsumDolor>
        </Content>
      </SectionTitle>
      <Content4>
        <List>
          <ListItem />
          <ListItem />
          <ListItem />
        </List>
        <Content3>
          <PriceTitle>
            <Title>
              <Heading>Basic plan</Heading>
              <Text1>Lorem ipsum dolor sit amet</Text1>
            </Title>
            <Price>
              <Span>$19</Span>
              <Mo>/mo</Mo>
            </Price>
          </PriceTitle>
          <Divider />
          <Content2>
            <Text2>Includes:</Text2>
            <Content1>
              <List1>
                <ListItem1>
                  <CheckIcon alt="" src="/check.svg" />
                  <Text3>Feature text goes here</Text3>
                </ListItem1>
                <ListItem1>
                  <CheckIcon alt="" src="/check.svg" />
                  <Text3>Feature text goes here</Text3>
                </ListItem1>
                <ListItem1>
                  <CheckIcon alt="" src="/check.svg" />
                  <Text3>Feature text goes here</Text3>
                </ListItem1>
                <ListItem1>
                  <CheckIcon alt="" src="/check.svg" />
                  <Text3>Feature text goes here</Text3>
                </ListItem1>
                <ListItem1>
                  <CheckIcon alt="" src="/check.svg" />
                  <Text3>Feature text goes here</Text3>
                </ListItem1>
              </List1>
              <List1>
                <ListItem1>
                  <CheckIcon alt="" src="/check.svg" />
                  <Text3>Feature text goes here</Text3>
                </ListItem1>
                <ListItem1>
                  <CheckIcon alt="" src="/check.svg" />
                  <Text3>Feature text goes here</Text3>
                </ListItem1>
                <ListItem1>
                  <CheckIcon alt="" src="/check.svg" />
                  <Text3>Feature text goes here</Text3>
                </ListItem1>
                <ListItem1>
                  <CheckIcon alt="" src="/check.svg" />
                  <Text3>Feature text goes here</Text3>
                </ListItem1>
                <ListItem1>
                  <CheckIcon alt="" src="/check.svg" />
                  <Text3>Feature text goes here</Text3>
                </ListItem1>
              </List1>
            </Content1>
          </Content2>
          <Divider />
          <Button1>
            <Button>Get started</Button>
          </Button1>
        </Content3>
      </Content4>
    </PricingRoot>
  );
};

export default Pricing7;
