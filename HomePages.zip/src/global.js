import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--text-small-link: Roboto;

/* font sizes */
--text-small-link-size: 14px;
--text-tiny-normal-size: 12px;
--text-regular-normal-size: 16px;
--heading-h5-size: 24px;
--font-size-lgi: 19px;
--text-medium-normal-size: 18px;
--heading-h2-size: 48px;
--font-size-10xl: 29px;
--font-size-19xl: 38px;
--font-size-7xl: 26px;
--heading-h4-size: 32px;
--heading-h1-size: 56px;
--heading-h6-size: 20px;
--heading-h3-size: 40px;
--font-size-15xl: 34px;
--font-size-26xl: 45px;

/* Colors */
--white: #fff;
--black: #000;
--color-darkslategray-100: #333;
--color-darkslategray-200: rgba(51, 51, 51, 0.09);
--color-dimgray: #505050;
--light-grey: #f4f4f4;
--color-gainsboro-100: #dbdbdb;
--neutral-gray: #8d8d8d;

/* Gaps */
--gap-13xl: 32px;
--gap-base: 16px;
--gap-xl: 20px;
--gap-xs: 12px;
--gap-5xl: 24px;
--gap-21xl: 40px;
--gap-61xl: 80px;
--gap-5xs: 8px;
--gap-9xs: 4px;
--gap-29xl: 48px;
--gap-mini: 15px;
--gap-45xl: 64px;
--gap-0: 0px;
--gap-4xl: 23px;
--gap-12xl: 31px;
--gap-3xs: 10px;
--gap-18xl: 37px;
--gap-lg: 18px;

/* Paddings */
--padding-61xl: 80px;
--padding-45xl: 64px;
--padding-33xl: 52px;
--padding-13xl: 32px;
--padding-29xl: 48px;
--padding-xs: 12px;
--padding-4xl: 23px;
--padding-smi: 13px;
--padding-2xs: 11px;
--padding-5xs: 8px;
--padding-93xl: 112px;
--padding-28xl: 47px;
--padding-54xl: 73px;
--padding-5xl: 24px;
--padding-9xs: 4px;
--padding-2xl: 21px;
--padding-12xl: 31px;
--padding-53xl: 72px;
--padding-xl: 20px;
--padding-14xl: 33px;
--padding-base: 16px;
--padding-mid: 17px;
--padding-lgi: 19px;
--padding-21xl: 40px;
--padding-15xl: 34px;
--padding-77xl: 96px;
--padding-10xs: 3px;
--padding-9xl: 28px;
--padding-37xl: 56px;
--padding-17xl: 36px;
--padding-18xl: 37px;
--padding-12xs: 1px;
--padding-mini: 15px;

/* Border radiuses */
--br-31xl: 50px;

}
`;
