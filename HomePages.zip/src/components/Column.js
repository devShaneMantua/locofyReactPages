import styled from "styled-components";
import FrameComponent from "./FrameComponent";
import List from "./List";

const Heading = styled.b`
  position: relative;
  line-height: 140%;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 22px;
  }
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const HeadingParent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const ColumnInner = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  border-top: 1px solid var(--black);
  box-sizing: border-box;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs);
  background-color: var(--black);
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const ColumnRoot = styled.div`
  width: 416px;
  border: 1px solid var(--black);
  box-sizing: border-box;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-12xl);
  gap: var(--gap-13xl);
  text-align: center;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    padding-top: var(--padding-2xl);
    padding-bottom: var(--padding-2xl);
    box-sizing: border-box;
  }
`;

const Column = () => {
  return (
    <ColumnRoot>
      <ColumnInner>
        <HeadingParent>
          <Heading>Enterprise plan</Heading>
          <Text1>Lorem ipsum dolor sit amet</Text1>
        </HeadingParent>
      </ColumnInner>
      <Divider />
      <FrameComponent prop="$49" text="or $499 yearly" />
      <Button1>
        <Button>Get started</Button>
      </Button1>
      <Divider />
      <List propAlignSelf="stretch" propPadding="var(--padding-5xs) 0px" />
    </ColumnRoot>
  );
};

export default Column;
