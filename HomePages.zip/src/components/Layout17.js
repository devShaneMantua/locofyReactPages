import styled from "styled-components";

const IconRelume = styled.input`
  margin: 0;
  height: 32px;
  width: 32px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h5-size);
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const WednesdayToSaturday = styled.p`
  margin: 0;
`;
const TextText = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 227px;
  max-width: 100%;
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 304px;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Content2 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 227px;
  max-width: 100%;
`;
const IconRelume1 = styled.img`
  height: 32px;
  width: 32px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const P = styled.p`
  margin: 0;
  text-decoration: underline;
`;
const ButtonInstance = styled.div`
  align-self: stretch;
  height: 48px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-29xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-5xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;

const Layout17 = () => {
  return (
    <LayoutRoot>
      <Column>
        <IconRelume type="checkbox" />
        <Content>
          <Heading>Open hours</Heading>
          <TextText>
            <WednesdayToSaturday>Wednesday to Saturday</WednesdayToSaturday>
            <WednesdayToSaturday>
              12:00 pm - 3:00 pm, 6:00 pm - 9:30 pm
            </WednesdayToSaturday>
          </TextText>
          <TextText>
            <WednesdayToSaturday>Sunday</WednesdayToSaturday>
            <WednesdayToSaturday>
              12:00 pm - 3:00 pm, 6:00 pm - 8:00 pm
            </WednesdayToSaturday>
          </TextText>
        </Content>
      </Column>
      <Column>
        <IconRelume type="checkbox" />
        <Content2>
          <Content1>
            <Heading>Location</Heading>
            <TextText>123 Sample St, Sydney NSW 2000 AU</TextText>
            <Button1>
              <Button>Get directions</Button>
              <IconChevronRight
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button1>
          </Content1>
        </Content2>
      </Column>
      <Column>
        <IconRelume1 loading="eager" alt="" src="/icon--relume-2.svg" />
        <Content2>
          <Content1>
            <Heading>Contact us</Heading>
            <TextText>
              <WednesdayToSaturday>{`Bookings & Enquiries`}</WednesdayToSaturday>
              <P>+61 2 91234 4567</P>
            </TextText>
            <ButtonInstance>
              <WednesdayToSaturday>
                Private Dining Enquiries
              </WednesdayToSaturday>
              <P>‍+61 2 91234 4568</P>
            </ButtonInstance>
          </Content1>
        </Content2>
      </Column>
    </LayoutRoot>
  );
};

export default Layout17;
