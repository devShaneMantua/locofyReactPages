import SectionTitle from "./SectionTitle";
import Row from "./Row";
import styled from "styled-components";

const BlogRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 1050px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-21xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;

const Blog4 = () => {
  return (
    <BlogRoot>
      <SectionTitle
        subheading="Events"
        heading="What's happening"
        propMinHeight="unset"
        propHeight="unset"
      />
      <Row
        heading="Event title heading will go here"
        button="Get directions"
        heading1="Event title heading will go here"
        button1="Get directions"
        heading2="Event title heading will go here"
        button2="Get directions"
      />
    </BlogRoot>
  );
};

export default Blog4;
