import styled from "styled-components";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
  text-align: ${(p) => p.propTextAlign};
`;
const InfoFrame = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: ${(p) => p.propTextAlign1};
`;
const RowCard = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
  display: ${(p) => p.buttonDisplay};
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-lgi) var(--padding-xs)
    var(--padding-4xl);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
  padding: ${(p) => p.propPadding};
`;
const ButtonTopRoot = styled.div`
  width: 560px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h4-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const FAQRow = ({
  button,
  propTextAlign,
  propTextAlign1,
  propPadding,
  buttonDisplay,
}) => {
  return (
    <ButtonTopRoot>
      <RowCard>
        <Heading propTextAlign={propTextAlign}>Still have questions?</Heading>
        <InfoFrame propTextAlign1={propTextAlign1}>
          Support details to capture customers that might be on the fence.
        </InfoFrame>
      </RowCard>
      <Button1 propPadding={propPadding}>
        <Button buttonDisplay={buttonDisplay}>{button}</Button>
      </Button1>
    </ButtonTopRoot>
  );
};

export default FAQRow;
