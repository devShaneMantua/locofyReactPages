import styled from "styled-components";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const HeadingText = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 240px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Heading1 = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const FrameQuestion = styled.div`
  align-self: stretch;
  height: 96px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Column = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
`;
const Row = styled.div`
  align-self: stretch;
  display: grid;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  grid-template-columns: repeat(3, minmax(304px, 1fr));
  @media screen and (max-width: 1200px) {
    justify-content: center;
    grid-template-columns: repeat(2, minmax(304px, 527px));
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-5xl);
    grid-template-columns: minmax(304px, 1fr);
  }
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h5-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-5xl);
  }
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1050px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-21xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Layout18 = () => {
  return (
    <LayoutRoot>
      <SectionTitle>
        <Subheading>More features</Subheading>
        <Content>
          <Heading>Call out other valuable features</Heading>
          <HeadingText>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros.
          </HeadingText>
        </Content>
      </SectionTitle>
      <Content2>
        <Row>
          <Column>
            <PlaceholderImage
              loading="eager"
              alt=""
              src="/placeholder--image-8@2x.png"
            />
            <Content1>
              <Heading1>Highlight feature four</Heading1>
              <FrameQuestion>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla.
              </FrameQuestion>
            </Content1>
          </Column>
          <Column>
            <PlaceholderImage
              loading="eager"
              alt=""
              src="/placeholder--image-9@2x.png"
            />
            <Content1>
              <Heading1>Highlight feature five</Heading1>
              <FrameQuestion>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla.
              </FrameQuestion>
            </Content1>
          </Column>
          <Column>
            <PlaceholderImage
              loading="eager"
              alt=""
              src="/placeholder--image-10@2x.png"
            />
            <Content1>
              <Heading1>Highlight feature six</Heading1>
              <FrameQuestion>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique. Duis
                cursus, mi quis viverra ornare, eros dolor interdum nulla.
              </FrameQuestion>
            </Content1>
          </Column>
        </Row>
      </Content2>
    </LayoutRoot>
  );
};

export default Layout18;
