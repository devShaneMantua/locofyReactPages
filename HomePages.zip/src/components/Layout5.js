import styled from "styled-components";
import Column5 from "./Column5";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: var(--heading-h2-size);
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const ButtonGroup = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const Row = styled.div`
  width: 1312px;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-29xl);
  max-width: 100%;
  font-size: var(--heading-h5-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-5xl);
  }
`;
const LayoutRoot = styled.section`
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1050px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-21xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Layout5 = () => {
  return (
    <LayoutRoot>
      <ButtonGroup>
        <Subheading>Customers</Subheading>
        <Heading>
          Short headline about who the product or service is for
        </Heading>
      </ButtonGroup>
      <Row>
        <Column5
          placeholderImage="/placeholder--image-8@2x.png"
          heading="Customer group one"
        />
        <Column5
          placeholderImage="/placeholder--image-9@2x.png"
          heading="Customer group two"
        />
        <Column5
          placeholderImage="/placeholder--image-10@2x.png"
          heading="Customer group three"
        />
      </Row>
    </LayoutRoot>
  );
};

export default Layout5;
