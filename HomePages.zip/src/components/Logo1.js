import styled from "styled-components";

const Heading = styled.b`
  width: 610px;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
  padding-left: var(--padding-xl);
  padding-right: var(--padding-xl);
`;
const FrameWrapperIcon = styled.img`
  position: absolute;
  top: calc(50% - 14.2px);
  left: calc(50% - 57px);
  width: 114px;
  height: 28.7px;
`;
const WebflowBlack = styled.div`
  height: 48px;
  width: 200px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const RelumeBlack = styled.img`
  align-self: stretch;
  width: 200px;
  position: relative;
  max-height: 100%;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 56px;
`;
const WebflowBlack1 = styled.img`
  height: 48px;
  width: 200px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const WebflowBlackParent = styled.div`
  width: 1460px;
  overflow-x: auto;
  flex-shrink: 0;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: 0px var(--padding-xl) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const FrameWrapper = styled.div`
  width: 1492px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px 0px 0px;
  box-sizing: border-box;
  max-width: 104%;
  flex-shrink: 0;
`;
const Logo3Inner = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px 0px 0px 0px;
  box-sizing: border-box;
  max-width: 100%;
`;
const LogoRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) 0px;
  box-sizing: border-box;
  gap: var(--gap-29xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-5xl);
  }
`;

const Logo1 = () => {
  return (
    <LogoRoot>
      <Heading>
        Trusted by the world's best companies [social proof to build
        credibility]
      </Heading>
      <Logo3Inner>
        <FrameWrapper>
          <WebflowBlackParent>
            <WebflowBlack>
              <FrameWrapperIcon loading="eager" alt="" src="/vector.svg" />
            </WebflowBlack>
            <RelumeBlack loading="eager" alt="" src="/relume--black1.svg" />
            <WebflowBlack1 loading="eager" alt="" src="/webflow--black2.svg" />
            <RelumeBlack loading="eager" alt="" src="/relume--black1.svg" />
            <WebflowBlack1 loading="eager" alt="" src="/webflow--black2.svg" />
            <RelumeBlack loading="eager" alt="" src="/relume--black1.svg" />
            <WebflowBlack1 loading="eager" alt="" src="/webflow--black2.svg" />
          </WebflowBlackParent>
        </FrameWrapper>
      </Logo3Inner>
    </LogoRoot>
  );
};

export default Logo1;
