import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 300px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Frame = styled.div`
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Info = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-5xs);
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  &:hover {
    background-color: var(--color-gainsboro-100);
  }
`;
const Text1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Info1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h5-size);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  font-size: var(--text-regular-normal-size);
`;
const Card = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const RowRoot = styled.div`
  align-self: stretch;
  display: grid;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  grid-template-columns: repeat(3, minmax(312px, 1fr));
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1200px) {
    justify-content: center;
    grid-template-columns: repeat(2, minmax(312px, 541px));
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-base);
    grid-template-columns: minmax(312px, 1fr);
  }
`;

const Row = ({ heading, button, heading1, button1, heading2, button2 }) => {
  return (
    <RowRoot>
      <Card>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-71@2x.png"
        />
        <Content>
          <Info1>
            <Info>
              <Frame>Category</Frame>
            </Info>
            <Text1>5 min read</Text1>
          </Info1>
          <Title>
            <Heading>{heading}</Heading>
            <Text2>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </Text2>
          </Title>
        </Content>
        <Button1>
          <Button>{button}</Button>
          <IconChevronRight
            loading="eager"
            alt=""
            src="/icon--chevron-right.svg"
          />
        </Button1>
      </Card>
      <Card>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-71@2x.png"
        />
        <Content>
          <Info1>
            <Info>
              <Frame>Category</Frame>
            </Info>
            <Text1>5 min read</Text1>
          </Info1>
          <Title>
            <Heading>{heading1}</Heading>
            <Text2>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </Text2>
          </Title>
        </Content>
        <Button1>
          <Button>{button1}</Button>
          <IconChevronRight
            loading="eager"
            alt=""
            src="/icon--chevron-right.svg"
          />
        </Button1>
      </Card>
      <Card>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-71@2x.png"
        />
        <Content>
          <Info1>
            <Info>
              <Frame>Category</Frame>
            </Info>
            <Text1>5 min read</Text1>
          </Info1>
          <Title>
            <Heading>{heading2}</Heading>
            <Text2>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </Text2>
          </Title>
        </Content>
        <Button1>
          <Button>{button2}</Button>
          <IconChevronRight
            loading="eager"
            alt=""
            src="/icon--chevron-right.svg"
          />
        </Button1>
      </Card>
    </RowRoot>
  );
};

export default Row;
