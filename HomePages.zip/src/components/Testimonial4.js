import styled from "styled-components";

const WebflowBlack = styled.img`
  width: 120px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Quote = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 102px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const AvatarImageIcon = styled.img`
  width: 56px;
  height: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  width: 300px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-normal-size);
`;
const Content = styled.div`
  width: 768px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
`;
const TestimonialRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1050px) {
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-5xl);
  }
`;

const Testimonial4 = () => {
  return (
    <TestimonialRoot>
      <Content>
        <WebflowBlack loading="eager" alt="" src="/webflow--black.svg" />
        <Quote>
          "A customer testimonial that highlights features and answers potential
          customer doubts about your product or service. Showcase testimonials
          from a similar demographic to your customers."
        </Quote>
        <Avatar>
          <AvatarImageIcon loading="eager" alt="" src="/avatar-image2@2x.png" />
          <AvatarContent>
            <Heading>Customer name</Heading>
            <Heading1>Position, Company name</Heading1>
          </AvatarContent>
        </Avatar>
      </Content>
    </TestimonialRoot>
  );
};

export default Testimonial4;
