import styled from "styled-components";

const Check = styled.input`
  margin: 0;
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Text1 = styled.div`
  position: relative;
  line-height: 150%;
  flex: ${(p) => p.propFlex1};
`;
const ListItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Text2 = styled.div`
  position: relative;
  line-height: 150%;
  flex: ${(p) => p.propFlex2};
`;
const Text3 = styled.div`
  position: relative;
  line-height: 150%;
  flex: ${(p) => p.propFlex3};
`;
const Text4 = styled.div`
  position: relative;
  line-height: 150%;
  flex: ${(p) => p.propFlex4};
`;
const FormGroup = styled.div`
  position: relative;
  line-height: 150%;
  flex: ${(p) => p.propFlex5};
`;
const ListRoot = styled.div`align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-base);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  align-self: ${(p) => p.propAlignSelf}
  padding: ${(p) => p.propPadding}
  flex: ${(p) => p.propFlex}
  min-width: ${(p) => p.propMinWidth}
`;

const List = ({
  propAlignSelf,
  propPadding,
  propFlex,
  propMinWidth,
  propFlex1,
  propFlex2,
  propFlex3,
  propFlex4,
  propFlex5,
}) => {
  return (
    <ListRoot
      propAlignSelf={propAlignSelf}
      propPadding={propPadding}
      propFlex={propFlex}
      propMinWidth={propMinWidth}
    >
      <ListItem>
        <Check type="checkbox" />
        <Text1 propFlex1={propFlex1}>Feature text goes here</Text1>
      </ListItem>
      <ListItem>
        <Check type="checkbox" />
        <Text2 propFlex2={propFlex2}>Feature text goes here</Text2>
      </ListItem>
      <ListItem>
        <Check type="checkbox" />
        <Text3 propFlex3={propFlex3}>Feature text goes here</Text3>
      </ListItem>
      <ListItem>
        <Check type="checkbox" />
        <Text4 propFlex4={propFlex4}>Feature text goes here</Text4>
      </ListItem>
      <ListItem>
        <Check type="checkbox" />
        <FormGroup propFlex5={propFlex5}>Feature text goes here</FormGroup>
      </ListItem>
    </ListRoot>
  );
};

export default List;
