import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  width: 141px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column1 = styled.div`
  width: 141px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Links = styled.div`
  flex: 1;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  min-width: 479px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-xl);
    min-width: 100%;
  }
`;
const RowFrameFooter = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const ContentFrameHeader = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Placeholder = styled.input`
  width: 100%;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  flex: 1;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
  min-width: 205px;
  max-width: 100%;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-smi) var(--padding-xs)
    var(--padding-2xs);
  min-width: 237px;
  max-width: 100%;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-4xl);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--text-tiny-normal-size);
`;
const Newslatter = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 500px;
  max-width: 100%;
  @media screen and (max-width: 1225px) {
    flex: 1;
  }
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  min-height: 248px;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 1225px) {
    flex-wrap: wrap;
  }
`;
const FooterFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-29xl);
  box-sizing: border-box;
  max-width: 100%;
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const HeadingText = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link2 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const Link3 = styled.div`
  flex: 1;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
  min-width: 68px;
`;
const FooterLinks1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 224px;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Credits = styled.div`
  width: 589px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const IconFacebook = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const SocialLinks = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 1050px) {
    flex-wrap: wrap;
  }
`;
const FooterRoot = styled.footer`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-base);
    padding: var(--padding-33xl) var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const Footer = () => {
  return (
    <FooterRoot>
      <FooterFrame>
        <Content>
          <Links>
            <Column>
              <LogoIcon alt="" src="/logo.svg" />
            </Column>
            <Column1>
              <Heading>Column One</Heading>
              <FooterLinks>
                <Link1>
                  <Link>Link One</Link>
                </Link1>
                <Link1>
                  <Link>Link Two</Link>
                </Link1>
                <Link1>
                  <Link>Link Three</Link>
                </Link1>
                <Link1>
                  <Link>Link Four</Link>
                </Link1>
                <Link1>
                  <Link>Link Five</Link>
                </Link1>
              </FooterLinks>
            </Column1>
            <Column1>
              <Heading>Column Two</Heading>
              <FooterLinks>
                <Link1>
                  <Link>Link Six</Link>
                </Link1>
                <Link1>
                  <Link>Link Seven</Link>
                </Link1>
                <Link1>
                  <Link>Link Eight</Link>
                </Link1>
                <Link1>
                  <Link>Link Nine</Link>
                </Link1>
                <Link1>
                  <Link>Link Ten</Link>
                </Link1>
              </FooterLinks>
            </Column1>
            <Column1>
              <Heading>Column Three</Heading>
              <FooterLinks>
                <Link1>
                  <Link>Link Eleven</Link>
                </Link1>
                <Link1>
                  <Link>Link Twelve</Link>
                </Link1>
                <Link1>
                  <Link>Link Thirteen</Link>
                </Link1>
                <Link1>
                  <Link>Link Fourteen</Link>
                </Link1>
                <Link1>
                  <Link>Link Fifteen</Link>
                </Link1>
              </FooterLinks>
            </Column1>
          </Links>
          <Newslatter>
            <ContentFrameHeader>
              <Heading>Subscribe</Heading>
              <RowFrameFooter>
                Join our newsletter to stay up to date on features and releases.
              </RowFrameFooter>
            </ContentFrameHeader>
            <Actions>
              <Form>
                <TextInput>
                  <Placeholder placeholder="Enter your email" type="text" />
                </TextInput>
                <Button1>
                  <Button>Subscribe</Button>
                </Button1>
              </Form>
              <RowFrameFooter>
                {`By subscribing you agree to with our `}
                <PrivacyPolicy>Privacy Policy</PrivacyPolicy> and provide
                consent to receive updates from our company.
              </RowFrameFooter>
            </Actions>
          </Newslatter>
        </Content>
      </FooterFrame>
      <Divider />
      <Row>
        <Credits>
          <HeadingText>© 2023 Relume. All rights reserved.</HeadingText>
          <FooterLinks1>
            <Link2>Privacy Policy</Link2>
            <Link3>Terms of Service</Link3>
            <Link3>Cookies Settings</Link3>
          </FooterLinks1>
        </Credits>
        <SocialLinks>
          <IconFacebook alt="" src="/icon--facebook.svg" />
          <IconFacebook alt="" src="/icon--instagram.svg" />
          <IconFacebook alt="" src="/icon--twitter.svg" />
          <IconFacebook alt="" src="/icon--linkedin.svg" />
        </SocialLinks>
      </Row>
    </FooterRoot>
  );
};

export default Footer;
