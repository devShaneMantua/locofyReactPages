import styled from "styled-components";
import Content1 from "./Content1";

const PlaceholderImage = styled.img`
  height: 640px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 400px;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1325px) {
    gap: var(--gap-21xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-xl);
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
`;

const Layout14 = () => {
  return (
    <LayoutRoot>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image-7@2x.png"
      />
      <Content1
        subheading="Feature one"
        heading="Describe how feature one works"
      />
    </LayoutRoot>
  );
};

export default Layout14;
