import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Socialiconsrow = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const P = styled.p`
  margin: 0;
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const IconFacebook = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const SocialLinks = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Column = styled.div`
  width: 864px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 864px;
  max-width: 100%;
  @media screen and (max-width: 1200px) {
    flex: 1;
  }
  @media screen and (max-width: 1050px) {
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
`;
const LinkList = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
  min-width: 117px;
`;
const Column1 = styled.div`
  width: 384px;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 250px;
  max-width: 100%;
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  @media screen and (max-width: 1200px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const TextLabel = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const LinkText = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const CookiesSettings = styled.div`
  align-self: stretch;
  width: 105px;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: none;
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const DividerFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  @media screen and (max-width: 750px) {
    gap: var(--gap-base);
  }
`;
const FooterRoot = styled.footer`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-21xl);
    padding: var(--padding-33xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;

const Footer5 = () => {
  return (
    <FooterRoot>
      <Content2>
        <Column>
          <LogoIcon loading="eager" alt="" src="/logo.svg" />
          <Content1>
            <Content>
              <Text1>Address:</Text1>
              <Socialiconsrow>
                Level 1, 12 Sample St, Sydney NSW 2000
              </Socialiconsrow>
            </Content>
            <Content>
              <Text1>Contact:</Text1>
              <Text2>
                <P>1800 123 4567</P>
                <P>info@relume.io</P>
              </Text2>
            </Content>
            <SocialLinks>
              <IconFacebook loading="eager" alt="" src="/icon--facebook.svg" />
              <IconFacebook loading="eager" alt="" src="/icon--instagram.svg" />
              <IconFacebook loading="eager" alt="" src="/icon--twitter.svg" />
              <IconFacebook loading="eager" alt="" src="/icon--linkedin.svg" />
            </SocialLinks>
          </Content1>
        </Column>
        <Column1>
          <LinkList>
            <Text1>Link One</Text1>
            <Text1>Link Two</Text1>
            <Text1>Link Three</Text1>
            <Text1>Link Four</Text1>
            <Text1>Link Five</Text1>
          </LinkList>
          <LinkList>
            <Text1>Link Six</Text1>
            <Text1>Link Seven</Text1>
            <Text1>Link Eight</Text1>
            <Text1>Link Nine</Text1>
            <Text1>Link Ten</Text1>
          </LinkList>
        </Column1>
      </Content2>
      <DividerFrame>
        <Divider />
        <Row>
          <TextLabel>© 2023 Relume. All rights reserved.</TextLabel>
          <LinkText>
            <Link>Privacy Policy</Link>
            <Link>Terms of Service</Link>
          </LinkText>
          <CookiesSettings>Cookies Settings</CookiesSettings>
        </Row>
      </DividerFrame>
    </FooterRoot>
  );
};

export default Footer5;
