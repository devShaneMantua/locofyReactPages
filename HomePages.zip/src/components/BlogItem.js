import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 105px;
  width: 160px;
  position: relative;
  object-fit: cover;
  @media screen and (max-width: 450px) {
    flex: 1;
  }
`;
const ArticleTitle = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const LoremIpsumDolor = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const ReadMore = styled.div`
  position: relative;
  font-size: var(--text-small-link-size);
  text-decoration: underline;
  line-height: 150%;
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  min-width: 187px;
`;
const BlogItemRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;

const BlogItem = () => {
  return (
    <BlogItemRoot>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image1@2x.png"
      />
      <Content1>
        <Content>
          <ArticleTitle>Article Title</ArticleTitle>
          <LoremIpsumDolor>
            Lorem ipsum dolor sit amet consectetur elit
          </LoremIpsumDolor>
        </Content>
        <ReadMore>Read more</ReadMore>
      </Content1>
    </BlogItemRoot>
  );
};

export default BlogItem;
