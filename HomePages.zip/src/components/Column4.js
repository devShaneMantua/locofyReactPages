import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 240px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const DescribeFeatureOne = styled.p`
  margin: 0;
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 68px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const DividerVertical = styled.div`
  align-self: stretch;
  height: 96px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
  white-space: nowrap;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const ColumnRoot = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
`;

const Column4 = ({ placeholderImage, describeFeatureOneAndIts }) => {
  return (
    <ColumnRoot>
      <PlaceholderImage alt="" src={placeholderImage} />
      <Content1>
        <Content>
          <Heading>
            <DescribeFeatureOne>{describeFeatureOneAndIts}</DescribeFeatureOne>
            <DescribeFeatureOne>benefits</DescribeFeatureOne>
          </Heading>
          <DividerVertical>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla.
          </DividerVertical>
        </Content>
        <Button1>
          <Button>Learn more</Button>
          <IconChevronRight
            loading="eager"
            alt=""
            src="/icon--chevron-right.svg"
          />
        </Button1>
      </Content1>
    </ColumnRoot>
  );
};

export default Column4;
