import styled from "styled-components";

const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Placeholder = styled.input`
  width: 100%;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  flex: 1;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
  min-width: 145px;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-smi) var(--padding-xs)
    var(--padding-2xs);
  min-width: 172px;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-4xl);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const BySubscribingYouContainer = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Actions = styled.div`
  width: 400px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--text-tiny-normal-size);
`;
const Newsletter = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 1200px) {
    flex-wrap: wrap;
  }
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Link1 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Link2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 176px;
  max-width: 180px;
`;
const Links = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-xl);
  }
`;
const LogoIcon = styled.img`
  height: 27px;
  width: 63px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const TextContent = styled.div`
  position: relative;
  line-height: 150%;
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--gap-xl);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const ColumnFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-base);
  }
`;
const FooterRoot = styled.footer`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  z-index: 1;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1050px) {
    padding-top: var(--padding-33xl);
    padding-bottom: var(--padding-33xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-21xl);
    padding-left: var(--padding-21xl);
    padding-right: var(--padding-21xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
    padding-top: var(--padding-15xl);
    padding-bottom: var(--padding-15xl);
    box-sizing: border-box;
  }
`;

const Footer2 = () => {
  return (
    <FooterRoot>
      <Newsletter>
        <Content>
          <Heading>Join our newsletter</Heading>
          <Link>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</Link>
        </Content>
        <Actions>
          <Form>
            <TextInput>
              <Placeholder placeholder="Enter your email" type="text" />
            </TextInput>
            <Button1>
              <Button>Subscribe</Button>
            </Button1>
          </Form>
          <BySubscribingYouContainer>
            {`By subscribing you agree to with our `}
            <PrivacyPolicy>Privacy Policy</PrivacyPolicy>
          </BySubscribingYouContainer>
        </Actions>
      </Newsletter>
      <Divider />
      <Links>
        <Column>
          <Heading>Column One</Heading>
          <FooterLinks>
            <Link2>
              <Link1>Link One</Link1>
            </Link2>
            <Link2>
              <Link1>Link Two</Link1>
            </Link2>
            <Link2>
              <Link1>Link Three</Link1>
            </Link2>
            <Link2>
              <Link1>Link Four</Link1>
            </Link2>
            <Link2>
              <Link1>Link Five</Link1>
            </Link2>
          </FooterLinks>
        </Column>
        <Column>
          <Heading>Column Two</Heading>
          <FooterLinks>
            <Link2>
              <Link1>Link Six</Link1>
            </Link2>
            <Link2>
              <Link1>Link Seven</Link1>
            </Link2>
            <Link2>
              <Link1>Link Eight</Link1>
            </Link2>
            <Link2>
              <Link1>Link Nine</Link1>
            </Link2>
            <Link2>
              <Link1>Link Ten</Link1>
            </Link2>
          </FooterLinks>
        </Column>
        <Column>
          <Heading>Column Three</Heading>
          <FooterLinks>
            <Link2>
              <Link1>Link Eleven</Link1>
            </Link2>
            <Link2>
              <Link1>Link Twelve</Link1>
            </Link2>
            <Link2>
              <Link1>Link Thirteen</Link1>
            </Link2>
            <Link2>
              <Link1>Link Fourteen</Link1>
            </Link2>
            <Link2>
              <Link1>Link Fifteen</Link1>
            </Link2>
          </FooterLinks>
        </Column>
        <Column>
          <Heading>Column Four</Heading>
          <FooterLinks>
            <Link2>
              <Link1>Link Sixteen</Link1>
            </Link2>
            <Link2>
              <Link1>Link Seventeen</Link1>
            </Link2>
            <Link2>
              <Link1>Link Eightteen</Link1>
            </Link2>
            <Link2>
              <Link1>Link Nineteen</Link1>
            </Link2>
            <Link2>
              <Link1>Link Twenty</Link1>
            </Link2>
          </FooterLinks>
        </Column>
        <Column>
          <Heading>Column Five</Heading>
          <FooterLinks>
            <Link2>
              <Link1>Link Twenty One</Link1>
            </Link2>
            <Link2>
              <Link1>Link Twenty Two</Link1>
            </Link2>
            <Link2>
              <Link1>Link Twenty Three</Link1>
            </Link2>
            <Link2>
              <Link1>Link Twenty Four</Link1>
            </Link2>
            <Link2>
              <Link1>Link Twenty Five</Link1>
            </Link2>
          </FooterLinks>
        </Column>
        <Column>
          <Heading>Column Six</Heading>
          <FooterLinks>
            <Link2>
              <Link1>Link Twenty Six</Link1>
            </Link2>
            <Link2>
              <Link1>Link Twenty Seven</Link1>
            </Link2>
            <Link2>
              <Link1>Link Twenty Eight</Link1>
            </Link2>
            <Link2>
              <Link1>Link Twenty Nine</Link1>
            </Link2>
            <Link2>
              <Link1>Link Thirty</Link1>
            </Link2>
          </FooterLinks>
        </Column>
      </Links>
      <ColumnFrame>
        <Divider />
        <Row>
          <LogoIcon loading="eager" alt="" src="/logo.svg" />
          <TextContent>© 2023 Relume. All rights reserved.</TextContent>
        </Row>
      </ColumnFrame>
    </FooterRoot>
  );
};

export default Footer2;
