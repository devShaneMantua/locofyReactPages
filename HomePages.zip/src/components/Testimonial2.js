import styled from "styled-components";

const IconSet = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.h3`
  margin: 0;
  width: 768px;
  height: 102px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const Divider = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Footer = styled.div`
  position: relative;
  line-height: 150%;
`;
const Icon = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider1 = styled.div`
  height: 62px;
  width: 1px;
  position: relative;
  border-right: 1px solid var(--black);
  box-sizing: border-box;
  @media screen and (max-width: 450px) {
    width: 100px;
    height: 1px;
    border-top: 1px solid var(--black);
    box-sizing: border-box;
  }
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const AvatarImageParent = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const TestimonialRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
`;

const Testimonial2 = () => {
  return (
    <TestimonialRoot>
      <Stars>
        <IconSet loading="eager" alt="" src="/info-frame.svg" />
        <IconSet loading="eager" alt="" src="/info-frame.svg" />
        <IconSet loading="eager" alt="" src="/info-frame.svg" />
        <IconSet loading="eager" alt="" src="/info-frame.svg" />
        <IconSet loading="eager" alt="" src="/info-frame.svg" />
      </Stars>
      <Quote>
        "A customer testimonial that highlights features and answers potential
        customer doubts about your product or service. Showcase testimonials
        from a similar demographic to your customers."
      </Quote>
      <AvatarImageParent>
        <AvatarImageIcon loading="eager" alt="" src="/avatar-image1@2x.png" />
        <Icon>
          <Divider>Customer Name</Divider>
          <Footer>Position, Company name</Footer>
        </Icon>
        <Divider1 />
        <WebflowBlack loading="eager" alt="" src="/webflow--black1.svg" />
      </AvatarImageParent>
    </TestimonialRoot>
  );
};

export default Testimonial2;
