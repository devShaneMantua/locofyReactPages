import styled from "styled-components";
import QADividers from "./QADividers";
import FAQRow from "./FAQRow";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const QuestionCard = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const FrameQuad = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const FaqRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1050px) {
    gap: var(--gap-21xl);
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;

const FAQ2 = () => {
  return (
    <FaqRoot>
      <FrameQuad>
        <Heading>Frequently asked questions</Heading>
        <QuestionCard>
          Frequently asked questions ordered by popularity. Remember that if the
          visitor has not committed to the call to action, they may still have
          questions (doubts) that can be answered.
        </QuestionCard>
      </FrameQuad>
      <QADividers
        propWidth="768px"
        propFlexWrap="wrap"
        propFlexWrap1="wrap"
        propFlexWrap2="wrap"
        propFlexWrap3="wrap"
        propFlexWrap4="wrap"
      />
      <FAQRow
        button="Contact us"
        propTextAlign="center"
        propTextAlign1="center"
        propPadding="var(--padding-xs) var(--padding-lgi) var(--padding-xs) var(--padding-4xl)"
      />
    </FaqRoot>
  );
};

export default FAQ2;
