import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const FAQHeader = styled.div`
  width: 131px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Link = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link1 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
  min-width: 49px;
`;
const Link2 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
  min-width: 44px;
`;
const LinkFrame = styled.div`
  width: 463px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-9xs) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-12xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
    gap: var(--gap-mini);
  }
`;
const IconFacebook = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const DividerFrame = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
`;
const LogoFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: space-between;
  min-height: 75px;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 1050px) {
    flex-wrap: wrap;
  }
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const CTA = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link3 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const ContentContainer = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-10xs) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-4xl);
  max-width: 100%;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const FooterRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  max-width: 100%;
  z-index: 1;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-base);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const Footer1 = () => {
  return (
    <FooterRoot>
      <LogoFrame>
        <FAQHeader>
          <LogoIcon loading="eager" alt="" src="/logo.svg" />
        </FAQHeader>
        <LinkFrame>
          <Link>Link One</Link>
          <Link>Link Two</Link>
          <Link1>Link Three</Link1>
          <Link2>Link Four</Link2>
          <Link>Link Five</Link>
        </LinkFrame>
        <DividerFrame>
          <IconFacebook alt="" src="/icon--facebook1.svg" />
          <IconFacebook alt="" src="/icon--instagram1.svg" />
          <IconFacebook alt="" src="/icon--twitter1.svg" />
          <IconFacebook alt="" src="/icon--linkedin1.svg" />
        </DividerFrame>
      </LogoFrame>
      <Divider />
      <ContentContainer>
        <CTA>© 2023 Relume. All rights reserved.</CTA>
        <Link3>Privacy Policy</Link3>
        <Link3>Terms of Service</Link3>
        <Link3>Cookies Settings</Link3>
      </ContentContainer>
    </FooterRoot>
  );
};

export default Footer1;
