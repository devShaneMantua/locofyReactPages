import styled from "styled-components";

const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Question = styled.b`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  min-width: 153px;
  max-width: 100%;
`;
const Icon = styled.img`
  height: 32px;
  width: 32px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const QuestionQuestion = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
  flex-wrap: ${(p) => p.propFlexWrap};
`;
const QuestionQuestion1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
  flex-wrap: ${(p) => p.propFlexWrap1};
`;
const QuestionQuestion2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
  flex-wrap: ${(p) => p.propFlexWrap2};
`;
const QuestionQuestion3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
  flex-wrap: ${(p) => p.propFlexWrap3};
`;
const QuestionQuestion4 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
  flex-wrap: ${(p) => p.propFlexWrap4};
`;
const DividerFrameQRoot = styled.div`width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  width: ${(p) => p.propWidth}
  flex: ${(p) => p.propFlex}
  min-width: ${(p) => p.propMinWidth}
`;

const QADividers = ({
  propWidth,
  propFlex,
  propMinWidth,
  propFlexWrap,
  propFlexWrap1,
  propFlexWrap2,
  propFlexWrap3,
  propFlexWrap4,
}) => {
  return (
    <DividerFrameQRoot
      propWidth={propWidth}
      propFlex={propFlex}
      propMinWidth={propMinWidth}
    >
      <Divider />
      <QuestionQuestion propFlexWrap={propFlexWrap}>
        <Question>Question text goes here</Question>
        <Icon loading="eager" alt="" src="/icon1.svg" />
      </QuestionQuestion>
      <Divider />
      <QuestionQuestion1 propFlexWrap1={propFlexWrap1}>
        <Question>Question text goes here</Question>
        <Icon loading="eager" alt="" src="/icon1.svg" />
      </QuestionQuestion1>
      <Divider />
      <QuestionQuestion2 propFlexWrap2={propFlexWrap2}>
        <Question>Question text goes here</Question>
        <Icon loading="eager" alt="" src="/icon1.svg" />
      </QuestionQuestion2>
      <Divider />
      <QuestionQuestion3 propFlexWrap3={propFlexWrap3}>
        <Question>Question text goes here</Question>
        <Icon loading="eager" alt="" src="/icon1.svg" />
      </QuestionQuestion3>
      <Divider />
      <QuestionQuestion4 propFlexWrap4={propFlexWrap4}>
        <Question>Question text goes here</Question>
        <Icon loading="eager" alt="" src="/icon1.svg" />
      </QuestionQuestion4>
      <Divider />
    </DividerFrameQRoot>
  );
};

export default QADividers;
