import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 250px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 195px;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 68px;
  position: relative;
  font-size: var(--heading-h5-size);
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const PlaceholderImage1 = styled.img`
  height: 48px;
  width: 48px;
  position: relative;
  object-fit: cover;
  min-height: 48px;
`;
const Label = styled.div`
  position: relative;
  line-height: 150%;
`;
const Div = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Time = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Content2 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 195px;
`;
const Card = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
    gap: var(--gap-base);
  }
`;
const ColumnRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  min-width: 411px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
`;

const Column7 = () => {
  return (
    <ColumnRoot>
      <Card>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-12@2x.png"
        />
        <Content2>
          <Content>
            <Text1>Category</Text1>
            <Heading>Blog title heading will go here</Heading>
            <Text2>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim...
            </Text2>
          </Content>
          <Avatar>
            <PlaceholderImage1
              loading="eager"
              alt=""
              src="/placeholder--image-22@2x.png"
            />
            <Content1>
              <Text1>Full name</Text1>
              <Time>
                <Label>11 Jan 2022</Label>
                <Div>•</Div>
                <Label>5 min read</Label>
              </Time>
            </Content1>
          </Avatar>
        </Content2>
      </Card>
      <Card>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-12@2x.png"
        />
        <Content2>
          <Content>
            <Text1>Category</Text1>
            <Heading>Blog title heading will go here</Heading>
            <Text2>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim...
            </Text2>
          </Content>
          <Avatar>
            <PlaceholderImage1
              loading="eager"
              alt=""
              src="/placeholder--image-22@2x.png"
            />
            <Content1>
              <Text1>Full name</Text1>
              <Time>
                <Label>11 Jan 2022</Label>
                <Div>•</Div>
                <Label>5 min read</Label>
              </Time>
            </Content1>
          </Avatar>
        </Content2>
      </Card>
    </ColumnRoot>
  );
};

export default Column7;
