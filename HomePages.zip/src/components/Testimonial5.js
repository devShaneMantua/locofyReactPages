import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 640px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 400px;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const FooterLinkIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const ACustomerTestimonial = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 136px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Divider = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const RowTextLink = styled.div`
  position: relative;
  line-height: 150%;
`;
const DividerParent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider1 = styled.div`
  height: 62px;
  width: 1px;
  position: relative;
  border-right: 1px solid var(--black);
  box-sizing: border-box;
  @media screen and (max-width: 450px) {
    width: 100px;
    height: 1px;
    border-top: 1px solid var(--black);
    box-sizing: border-box;
  }
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Link = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xl);
  max-width: 100%;
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const ColumnLinks = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  box-sizing: border-box;
  gap: var(--gap-13xl);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
    min-width: 100%;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;
const Dot = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--black);
`;
const Dot1 = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--neutral-gray);
`;
const SliderDots = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Icon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xs);
  background-color: transparent;
  height: 48px;
  width: 48px;
  border-radius: var(--br-31xl);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const ColumnParent = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-mini);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--gap-xl);
`;
const TestimonialRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const Testimonial5 = () => {
  return (
    <TestimonialRoot>
      <Text1>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-32@2x.png"
        />
        <ColumnLinks>
          <Stars>
            <FooterLinkIcon loading="eager" alt="" src="/info-frame.svg" />
            <FooterLinkIcon loading="eager" alt="" src="/info-frame.svg" />
            <FooterLinkIcon loading="eager" alt="" src="/info-frame.svg" />
            <FooterLinkIcon loading="eager" alt="" src="/info-frame.svg" />
            <FooterLinkIcon loading="eager" alt="" src="/info-frame.svg" />
          </Stars>
          <ACustomerTestimonial>
            "A customer testimonial that highlights features and answers
            potential customer doubts about your product or service. Showcase
            testimonials from a similar demographic to your customers."
          </ACustomerTestimonial>
          <Link>
            <DividerParent>
              <Divider>Name Surname</Divider>
              <RowTextLink>Position, Company name</RowTextLink>
            </DividerParent>
            <Divider1 />
            <WebflowBlack loading="eager" alt="" src="/webflow--black1.svg" />
          </Link>
        </ColumnLinks>
      </Text1>
      <Content>
        <SliderDots>
          <Dot />
          <Dot1 />
        </SliderDots>
        <ColumnParent>
          <Button>
            <Icon alt="" src="/icon.svg" />
          </Button>
          <Button>
            <Icon alt="" src="/icon-1.svg" />
          </Button>
        </ColumnParent>
      </Content>
    </TestimonialRoot>
  );
};

export default Testimonial5;
