import styled from "styled-components";
import List from "./List";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h2-size);
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  text-align: left;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Button = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const ColumnFooter = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  text-align: left;
`;
const TextInput = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const RowFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Icon = styled.img`
  height: 32px;
  width: 32px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading1 = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 22px;
  }
`;
const ColumnHeadings = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 364px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const ListItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const List = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  box-sizing: border-box;
  gap: var(--gap-13xl);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 1325px) {
    flex: 1;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
    min-width: 100%;
  }
`;
const Heading2 = styled.h3`
  margin: 0;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const ListItemContent = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const HeadingParent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Span = styled.span``;
const Mo = styled.span`
  font-size: var(--heading-h4-size);
`;
const Price = styled.b`
  position: relative;
  line-height: 67px;
  font-size: var(--heading-h1-size);
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-7xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
  }
`;
const PriceTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  border-top: 1px solid var(--black);
  box-sizing: border-box;
`;
const LayoutFrame = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-5xl);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  flex-shrink: 0;
  text-align: left;
  font-size: var(--text-regular-normal-size);
`;
const Button1 = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
  white-space: nowrap;
`;
const Button2 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs);
  background-color: var(--black);
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Content3 = styled.div`
  flex: 0.8961;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-12xl);
  gap: var(--gap-13xl);
  min-width: 400px;
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h5-size);
  @media screen and (max-width: 1325px) {
    flex: 1;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
    padding-top: var(--padding-2xl);
    padding-bottom: var(--padding-2xl);
    box-sizing: border-box;
    min-width: 100%;
  }
`;
const HeadingLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h6-size);
  @media screen and (max-width: 1325px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;
const PricingRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;

const Pricing = () => {
  return (
    <PricingRoot>
      <RowFrame>
        <TextInput>
          <Button>
            <Subheading>Pricing</Subheading>
            <Heading>Simple pricing</Heading>
          </Button>
          <ColumnFooter>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique.
          </ColumnFooter>
        </TextInput>
      </RowFrame>
      <HeadingLinks>
        <List>
          <ListItem>
            <Icon loading="eager" alt="" src="/icon-10.svg" />
            <Content>
              <Heading1>Highlight benefit one</Heading1>
              <ColumnHeadings>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique.
              </ColumnHeadings>
            </Content>
          </ListItem>
          <ListItem>
            <Icon loading="eager" alt="" src="/icon-10.svg" />
            <Content>
              <Heading1>Highlight benefit two</Heading1>
              <ColumnHeadings>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique.
              </ColumnHeadings>
            </Content>
          </ListItem>
          <ListItem>
            <Icon loading="eager" alt="" src="/icon-10.svg" />
            <Content>
              <Heading1>Highlight benefit three</Heading1>
              <ColumnHeadings>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros elementum tristique.
              </ColumnHeadings>
            </Content>
          </ListItem>
        </List>
        <Content3>
          <PriceTitle>
            <HeadingParent>
              <Heading2>Basic plan</Heading2>
              <ListItemContent>Lorem ipsum dolor sit amet</ListItemContent>
            </HeadingParent>
            <Price>
              <Span>$19</Span>
              <Mo>/mo</Mo>
            </Price>
          </PriceTitle>
          <Divider />
          <Content2>
            <LayoutFrame>Includes:</LayoutFrame>
            <Content1>
              <List
                propAlignSelf="unset"
                propPadding="unset"
                propFlex="1"
                propMinWidth="172px"
                propFlex1="1"
                propFlex2="1"
                propFlex3="1"
                propFlex4="1"
                propFlex5="1"
              />
              <List
                propAlignSelf="unset"
                propPadding="unset"
                propFlex="1"
                propMinWidth="172px"
                propFlex1="1"
                propFlex2="1"
                propFlex3="1"
                propFlex4="1"
                propFlex5="1"
              />
            </Content1>
          </Content2>
          <Divider />
          <Button2>
            <Button1>Get started</Button1>
          </Button2>
        </Content3>
      </HeadingLinks>
    </PricingRoot>
  );
};

export default Pricing;
