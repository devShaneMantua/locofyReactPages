import styled from "styled-components";

const Span = styled.span`
  line-height: 120%;
`;
const Mo = styled.span`
  font-size: var(--heading-h4-size);
  line-height: 130%;
`;
const Price = styled.b`
  height: 67px;
  position: relative;
  display: inline-block;
  @media screen and (max-width: 750px) {
    font-size: var(--font-size-7xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
  }
`;
const FooterLinksList = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const PlaceholderImage = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const RowCardRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: center;
  font-size: var(--heading-h1-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const FrameComponent = ({ prop, text }) => {
  return (
    <RowCardRoot>
      <PlaceholderImage>
        <Price>
          <Span>{prop}</Span>
          <Mo>/mo</Mo>
        </Price>
        <FooterLinksList>{text}</FooterLinksList>
      </PlaceholderImage>
    </RowCardRoot>
  );
};

export default FrameComponent;
