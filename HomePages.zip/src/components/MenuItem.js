import styled from "styled-components";

const IconRelume = styled.input`
  margin: 0;
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const PageOne = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const LoremIpsumDolor = styled.div`
  position: relative;
  font-size: var(--text-small-link-size);
  line-height: 150%;
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 179px;
`;
const MenuItemRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  box-sizing: border-box;
  gap: var(--gap-xs);
  min-width: 287px;
  max-width: 312px;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;

const MenuItem = ({ pageOne }) => {
  return (
    <MenuItemRoot>
      <IconRelume type="checkbox" />
      <Content>
        <PageOne>{pageOne}</PageOne>
        <LoremIpsumDolor>
          Lorem ipsum dolor sit amet consectetur elit
        </LoremIpsumDolor>
      </Content>
    </MenuItemRoot>
  );
};

export default MenuItem;
