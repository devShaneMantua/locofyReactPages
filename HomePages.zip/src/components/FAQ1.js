import styled from "styled-components";
import FAQRow from "./FAQRow";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const LinkLinkLink = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Question = styled.input`
  width: calc(100% - 78px);
  border: none;
  outline: none;
  display: inline-block;
  font-family: var(--text-small-link);
  font-size: var(--text-medium-normal-size);
  background-color: transparent;
  height: 27px;
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 700;
  color: var(--black);
  text-align: left;
  min-width: 300px;
  max-width: 100%;
`;
const PlusIcon = styled.img`
  height: 32px;
  width: 32px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const AccordionItem = styled.div`
  align-self: stretch;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  padding: var(--padding-xl) var(--padding-4xl);
  row-gap: 20px;
  max-width: 100%;
`;
const Accordion = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const Container = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 1050px) {
    gap: var(--gap-21xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;
const FaqRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1200px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1050px) {
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    padding-top: var(--padding-28xl);
    padding-bottom: var(--padding-28xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-5xl);
  }
`;

const FAQ1 = () => {
  return (
    <FaqRoot>
      <Container>
        <SectionTitle>
          <Heading>Frequently asked questions</Heading>
          <LinkLinkLink>
            Frequently asked questions ordered by popularity. Remember that if
            the visitor has not committed to the call to action, they may still
            have questions (doubts) that can be answered.
          </LinkLinkLink>
        </SectionTitle>
        <Accordion>
          <AccordionItem>
            <Question placeholder="Question text goes here" type="text" />
            <PlusIcon alt="" src="/plus.svg" />
          </AccordionItem>
          <AccordionItem>
            <Question placeholder="Question text goes here" type="text" />
            <PlusIcon alt="" src="/plus.svg" />
          </AccordionItem>
          <AccordionItem>
            <Question placeholder="Question text goes here" type="text" />
            <PlusIcon alt="" src="/plus.svg" />
          </AccordionItem>
          <AccordionItem>
            <Question placeholder="Question text goes here" type="text" />
            <PlusIcon alt="" src="/plus.svg" />
          </AccordionItem>
          <AccordionItem>
            <Question placeholder="Question text goes here" type="text" />
            <PlusIcon alt="" src="/plus.svg" />
          </AccordionItem>
        </Accordion>
        <FAQRow
          button="Chat to sales"
          propTextAlign="center"
          propTextAlign1="center"
          propPadding="var(--padding-xs) var(--padding-2xl)"
          buttonDisplay="inline-block"
        />
      </Container>
    </FaqRoot>
  );
};

export default FAQ1;
