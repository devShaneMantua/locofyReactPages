import styled from "styled-components";

const CardRowIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.div`
  align-self: stretch;
  height: 108px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: contain;
`;
const NameSurname = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const PositionCompanyName = styled.div`
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xl);
  font-size: var(--text-regular-normal-size);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const ColumnRoot = styled.div`
  width: 600px;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-14xl) var(--padding-13xl)
    var(--padding-12xl);
  gap: var(--gap-5xl);
  max-width: 100%;
  flex-shrink: 0;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
`;

const Column3 = () => {
  return (
    <ColumnRoot>
      <Stars>
        <CardRowIcon alt="" src="/info-frame.svg" />
        <CardRowIcon alt="" src="/info-frame.svg" />
        <CardRowIcon alt="" src="/info-frame.svg" />
        <CardRowIcon alt="" src="/info-frame.svg" />
        <CardRowIcon alt="" src="/info-frame.svg" />
      </Stars>
      <Content>
        <Quote>
          "A customer testimonial that highlights features and answers potential
          customer doubts about your product or service. Showcase testimonials
          from a similar demographic to your customers."
        </Quote>
        <Avatar>
          <AvatarImageIcon loading="eager" alt="" src="/avatar-image@2x.png" />
          <AvatarContent>
            <NameSurname>Name Surname</NameSurname>
            <PositionCompanyName>Position, Company name</PositionCompanyName>
          </AvatarContent>
        </Avatar>
      </Content>
    </ColumnRoot>
  );
};

export default Column3;
