import styled from "styled-components";

const AvatarGroupIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.b`
  align-self: stretch;
  height: 112px;
  position: relative;
  line-height: 140%;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 22px;
  }
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const TextRow = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const TextPair = styled.div`
  position: relative;
  line-height: 150%;
`;
const InnerFrame = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider = styled.div`
  height: 62px;
  width: 1px;
  position: relative;
  border-right: 1px solid var(--black);
  box-sizing: border-box;
  @media screen and (max-width: 750px) {
    width: 100px;
    height: 1px;
    border-top: 1px solid var(--black);
    box-sizing: border-box;
  }
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const ContainerFrame = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xl);
  max-width: 100%;
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const TextContainerRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 395px;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 750px) {
    gap: var(--gap-base);
    min-width: 100%;
  }
`;

const ContentFrame = () => {
  return (
    <TextContainerRoot>
      <Stars>
        <AvatarGroupIcon loading="eager" alt="" src="/info-frame.svg" />
        <AvatarGroupIcon loading="eager" alt="" src="/info-frame.svg" />
        <AvatarGroupIcon loading="eager" alt="" src="/info-frame.svg" />
        <AvatarGroupIcon alt="" src="/info-frame.svg" />
        <AvatarGroupIcon alt="" src="/info-frame.svg" />
      </Stars>
      <Quote>
        "A customer testimonial that highlights features and answers potential
        customer doubts about your product or service. Showcase testimonials
        from a similar demographic to your customers."
      </Quote>
      <ContainerFrame>
        <AvatarImageIcon loading="eager" alt="" src="/avatar-image1@2x.png" />
        <InnerFrame>
          <TextRow>Name Surname</TextRow>
          <TextPair>Position, Company name</TextPair>
        </InnerFrame>
        <Divider />
        <WebflowBlack loading="eager" alt="" src="/webflow--black1.svg" />
      </ContainerFrame>
    </TextContainerRoot>
  );
};

export default ContentFrame;
