import SectionTitle from "./SectionTitle";
import Card from "./Card";
import styled from "styled-components";

const Row = styled.div`
  align-self: stretch;
  display: grid;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  grid-template-columns: repeat(3, minmax(312px, 1fr));
  @media screen and (max-width: 1050px) {
    justify-content: center;
    grid-template-columns: repeat(2, minmax(312px, 541px));
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-base);
    grid-template-columns: minmax(312px, 1fr);
  }
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  max-width: 100%;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
`;
const BlogRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1225px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-21xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;

const Blog = () => {
  return (
    <BlogRoot>
      <SectionTitle
        subheading="Blog"
        heading="Introduce customer success stories"
        propMinHeight="265px"
        propHeight="116px"
      />
      <Content>
        <Row>
          <Card />
          <Card />
          <Card />
        </Row>
      </Content>
    </BlogRoot>
  );
};

export default Blog;
