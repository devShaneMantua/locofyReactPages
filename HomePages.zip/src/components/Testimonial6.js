import styled from "styled-components";

const CustomerStories = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h2-size);
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const TextInput = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const PlaceholderLightbox = styled.img`
  height: 640px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  min-width: 400px;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const ButtonIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 136px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Footer = styled.div`
  position: relative;
  line-height: 150%;
`;
const QuestionParent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider = styled.div`
  height: 62px;
  width: 1px;
  position: relative;
  border-right: 1px solid var(--black);
  box-sizing: border-box;
  @media screen and (max-width: 450px) {
    width: 100px;
    height: 1px;
    border-top: 1px solid var(--black);
    box-sizing: border-box;
  }
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Text1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xl);
  max-width: 100%;
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Link = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  box-sizing: border-box;
  gap: var(--gap-13xl);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
    min-width: 100%;
  }
`;
const Divider1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;
const Dot = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--black);
`;
const Dot1 = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--neutral-gray);
`;
const SliderDots = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Icon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xs);
  background-color: transparent;
  height: 48px;
  width: 48px;
  border-radius: var(--br-31xl);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const ButtonParent = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-mini);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--gap-xl);
`;
const DividerParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h5-size);
`;
const TestimonialRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;

const Testimonial6 = () => {
  return (
    <TestimonialRoot>
      <TextInput>
        <CustomerStories>Customer Stories</CustomerStories>
        <Heading>Don’t just take our word for it</Heading>
      </TextInput>
      <DividerParent>
        <Divider1>
          <PlaceholderLightbox
            loading="eager"
            alt=""
            src="/placeholder--lightbox-1.svg"
          />
          <Link>
            <Stars>
              <ButtonIcon alt="" src="/info-frame.svg" />
              <ButtonIcon alt="" src="/info-frame.svg" />
              <ButtonIcon alt="" src="/info-frame.svg" />
              <ButtonIcon alt="" src="/info-frame.svg" />
              <ButtonIcon alt="" src="/info-frame.svg" />
            </Stars>
            <Quote>
              "A testimonial that shares a customer's positive experience with
              your company and answers potential customer doubts. Showcase
              testimonials from a similar demographic to your customers."
            </Quote>
            <Text1>
              <QuestionParent>
                <CustomerStories>Name Surname</CustomerStories>
                <Footer>Position, Company name</Footer>
              </QuestionParent>
              <Divider />
              <WebflowBlack loading="eager" alt="" src="/webflow--black1.svg" />
            </Text1>
          </Link>
        </Divider1>
        <Row>
          <SliderDots>
            <Dot />
            <Dot1 />
          </SliderDots>
          <ButtonParent>
            <Button>
              <Icon alt="" src="/icon.svg" />
            </Button>
            <Button>
              <Icon alt="" src="/icon-1.svg" />
            </Button>
          </ButtonParent>
        </Row>
      </DividerParent>
    </TestimonialRoot>
  );
};

export default Testimonial6;
