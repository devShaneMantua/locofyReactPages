import styled from "styled-components";
import FAQRow from "./FAQRow";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const HeadingParent = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-height: 196px;
  max-width: 100%;
`;
const Divider = styled.div`
  height: 1px;
  flex: 1;
  position: relative;
  background-color: var(--black);
  min-width: 406px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const DividerParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-13xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
`;
const Question = styled.b`
  width: 580px;
  position: relative;
  line-height: 150%;
  display: inline-block;
  min-width: 153px;
  max-width: 100%;
`;
const Icon = styled.img`
  height: 32px;
  width: 32px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Question1 = styled.b`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  min-width: 153px;
  max-width: 100%;
`;
const IconParent = styled.div`
  width: 676px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
    gap: var(--gap-13xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
`;
const QuestionParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
`;
const FrameParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xl);
  min-height: 405px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-normal-size);
`;
const FaqRoot = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 800px) {
    padding: var(--padding-28xl) var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const FAQ4 = () => {
  return (
    <FaqRoot>
      <HeadingParent>
        <Heading>Frequently asked questions</Heading>
        <Text1>
          Frequently asked questions ordered by popularity. Remember that if the
          visitor has not committed to the call to action, they may still have
          questions (doubts) that can be answered.
        </Text1>
      </HeadingParent>
      <DividerParent>
        <Divider />
        <Divider />
      </DividerParent>
      <FrameParent>
        <QuestionParent>
          <Question>Question text goes here</Question>
          <IconParent>
            <Icon loading="eager" alt="" src="/icon1.svg" />
            <Question1>Question text goes here</Question1>
          </IconParent>
          <Icon loading="eager" alt="" src="/icon1.svg" />
        </QuestionParent>
        <DividerParent>
          <Divider />
          <Divider />
        </DividerParent>
        <QuestionParent>
          <Question>Question text goes here</Question>
          <IconParent>
            <Icon loading="eager" alt="" src="/icon1.svg" />
            <Question1>Question text goes here</Question1>
          </IconParent>
          <Icon loading="eager" alt="" src="/icon1.svg" />
        </QuestionParent>
        <DividerParent>
          <Divider />
          <Divider />
        </DividerParent>
        <QuestionParent>
          <Question>Question text goes here</Question>
          <IconParent>
            <Icon loading="eager" alt="" src="/icon1.svg" />
            <Question1>Question text goes here</Question1>
          </IconParent>
          <Icon loading="eager" alt="" src="/icon1.svg" />
        </QuestionParent>
        <DividerParent>
          <Divider />
          <Divider />
        </DividerParent>
        <QuestionParent>
          <Question>Question text goes here</Question>
          <IconParent>
            <Icon loading="eager" alt="" src="/icon1.svg" />
            <Question1>Question text goes here</Question1>
          </IconParent>
          <Icon loading="eager" alt="" src="/icon1.svg" />
        </QuestionParent>
        <DividerParent>
          <Divider />
          <Divider />
        </DividerParent>
        <QuestionParent>
          <Question>Question text goes here</Question>
          <IconParent>
            <Icon loading="eager" alt="" src="/icon1.svg" />
            <Question1>Question text goes here</Question1>
          </IconParent>
          <Icon alt="" src="/icon1.svg" />
        </QuestionParent>
        <DividerParent>
          <Divider />
          <Divider />
        </DividerParent>
      </FrameParent>
      <FAQRow
        button="Call us 1800 123 456"
        propTextAlign="center"
        propTextAlign1="center"
        propPadding="var(--padding-xs) var(--padding-lgi) var(--padding-xs) var(--padding-4xl)"
        buttonDisplay="inline-block"
      />
    </FaqRoot>
  );
};

export default FAQ4;
