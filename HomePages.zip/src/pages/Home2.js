import Navbar1 from "../components/Navbar1";
import Header1 from "../components/Header1";
import Column6 from "../components/Column6";
import styled from "styled-components";
import Layout4 from "../components/Layout4";
import Layout3 from "../components/Layout3";
import Testimonial2 from "../components/Testimonial2";
import Layout2 from "../components/Layout2";
import Testimonial1 from "../components/Testimonial1";
import CTA from "../components/CTA";
import FAQ from "../components/FAQ";
import Footer1 from "../components/Footer1";

const Layout = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-29xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-5xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;
const HomeRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Home2 = () => {
  return (
    <HomeRoot>
      <Navbar1 button="Try for free" buttonWidth="120px" />
      <Header1 />
      <Layout>
        <Column6
          heading="Highlight benefit one"
          propTextAlign="left"
          propTextAlign1="left"
        />
        <Column6
          heading="Highlight benefit two"
          propTextAlign="left"
          propTextAlign1="left"
        />
        <Column6
          heading="Highlight benefit three"
          propTextAlign="left"
          propTextAlign1="left"
        />
      </Layout>
      <Layout4 />
      <Layout3
        placeholderImage="/placeholder--image-7@2x.png"
        subheading="Feature one"
        featureOne="feature one"
      />
      <Testimonial2 />
      <Layout2 />
      <Testimonial1 />
      <Layout3
        placeholderImage="/placeholder--image-31@2x.png"
        subheading="Feature three"
        featureOne="feature three"
      />
      <CTA />
      <FAQ />
      <Footer1 />
    </HomeRoot>
  );
};

export default Home2;
