import Navbar3 from "../components/Navbar3";
import Header6 from "../components/Header6";
import Layout19 from "../components/Layout19";
import Layout18 from "../components/Layout18";
import Testimonial7 from "../components/Testimonial7";
import styled from "styled-components";
import FAQ5 from "../components/FAQ5";
import Footer2 from "../components/Footer2";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const ButtonInstance = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const HeadingTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--white);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-lgi) var(--padding-xs)
    var(--padding-4xl);
  background-color: var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Cta = styled.section`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1050px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 750px) {
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-54xl);
    padding-bottom: var(--padding-54xl);
    box-sizing: border-box;
  }
`;
const HomeRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
`;

const Home5 = () => {
  return (
    <HomeRoot>
      <Navbar3
        button="Contact us"
        button1="Book a demo"
        columnWidth="689px"
        buttonWidth="unset"
        buttonWidth1="119px"
        buttonWidth2="unset"
        buttonDisplay="inline-block"
        buttonFlex="unset"
      />
      <Header6 />
      <Layout19
        subheading="Feature one"
        heading="Describe how feature one works"
      />
      <Layout19
        subheading="Feature two"
        heading="Describe how feature two works"
      />
      <Layout19
        subheading="Feature one"
        heading="Describe how feature three works"
      />
      <Layout18 />
      <Testimonial7 />
      <Cta>
        <HeadingTitle>
          <Heading>Call to action that invites visitor to book a demo</Heading>
          <ButtonInstance>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</ButtonInstance>
        </HeadingTitle>
        <Button1>
          <Button>Book a demo</Button>
        </Button1>
      </Cta>
      <FAQ5 />
      <Footer2 />
    </HomeRoot>
  );
};

export default Home5;
