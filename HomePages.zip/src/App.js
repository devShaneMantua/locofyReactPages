import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Home3 from "./pages/Home3";
import Home from "./pages/Home5";
import Home6 from "./pages/Home6";
import Home5 from "./pages/Home51";
import Home4 from "./pages/Home4";
import Home2 from "./pages/Home2";
import Home1 from "./pages/Home1";
import Home7 from "./pages/Home";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/home-8":
        title = "";
        metaDescription = "";
        break;
      case "/home-7":
        title = "";
        metaDescription = "";
        break;
      case "/home-6":
        title = "";
        metaDescription = "";
        break;
      case "/home-5":
        title = "";
        metaDescription = "";
        break;
      case "/home-3":
        title = "";
        metaDescription = "";
        break;
      case "/home-2":
        title = "";
        metaDescription = "";
        break;
      case "/home-1":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<Home3 />} />
      <Route path="/home-8" element={<Home />} />
      <Route path="/home-7" element={<Home6 />} />
      <Route path="/home-6" element={<Home5 />} />
      <Route path="/home-5" element={<Home4 />} />
      <Route path="/home-3" element={<Home2 />} />
      <Route path="/home-2" element={<Home1 />} />
      <Route path="/home-1" element={<Home7 />} />
    </Routes>
  );
}
export default App;
