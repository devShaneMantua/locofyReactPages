import Navbar from "../components/Navbar";
import Header from "../components/Header";
import Layout3 from "../components/Layout3";
import Layout2 from "../components/Layout2";
import Layout1 from "../components/Layout1";
import Testimonial from "../components/Testimonial";
import Layout from "../components/Layout";
import CTA from "../components/CTA";
import FAQ from "../components/FAQ";
import Footer from "../components/Footer";
import styled from "styled-components";

const HomeRoot = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px 0px;
  box-sizing: border-box;
  letter-spacing: normal;
`;

const Home = () => {
  return (
    <HomeRoot>
      <Navbar />
      <Header />
      <Layout3 />
      <Layout2 />
      <Layout1
        placeholderImage="/placeholder--image-1@2x.png"
        subheading="Feature one"
        featureOne="feature one"
      />
      <Testimonial
        avatarImage="/avatar-image@2x.png"
        testimonialcontainer="Shane Del Moira Mantua"
      />
      <Layout />
      <Testimonial
        avatarImage="/avatar-image-1@2x.png"
        testimonialcontainer="Shane Del Moira Mantua"
      />
      <Layout1
        placeholderImage="/placeholder--image-3@2x.png"
        subheading="Feature three"
        featureOne="feature three"
      />
      <CTA />
      <FAQ />
      <Footer />
    </HomeRoot>
  );
};

export default Home;
