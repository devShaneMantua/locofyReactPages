import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Linkframe = styled.div`
  width: 132px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Link = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link1 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
  min-width: 49px;
`;
const Link2 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
  min-width: 44px;
`;
const Linksframe = styled.div`
  width: 463px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 32px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 450px) {
    gap: 16px;
  }
`;
const IconFacebook = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Socialicons = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 12px;
`;
const Logoframe = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: space-between;
  padding: 0px 20px;
  box-sizing: border-box;
  min-height: 75px;
  gap: 20px;
  max-width: 100%;
  @media screen and (max-width: 1100px) {
    flex-wrap: wrap;
  }
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: #000;
`;
const LinkedInicon = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link3 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const Twittericon = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 24px;
  max-width: 100%;
  font-size: 14px;
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const FooterRoot = styled.section`
  align-self: stretch;
  background-color: #fff;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 80px 37px 37px;
  box-sizing: border-box;
  gap: 32px;
  max-width: 100%;
  z-index: 1;
  text-align: left;
  font-size: 16px;
  color: #000;
  font-family: Roboto;
  @media screen and (max-width: 750px) {
    gap: 16px;
  }
`;

const Footer = () => {
  return (
    <FooterRoot>
      <Logoframe>
        <Linkframe>
          <LogoIcon loading="eager" alt="" src="/logo.svg" />
        </Linkframe>
        <Linksframe>
          <Link>Link One</Link>
          <Link>Link Two</Link>
          <Link1>Link Three</Link1>
          <Link2>Link Four</Link2>
          <Link>Link Five</Link>
        </Linksframe>
        <Socialicons>
          <IconFacebook loading="eager" alt="" src="/icon--facebook.svg" />
          <IconFacebook loading="eager" alt="" src="/icon--instagram.svg" />
          <IconFacebook loading="eager" alt="" src="/icon--twitter.svg" />
          <IconFacebook loading="eager" alt="" src="/icon--linkedin.svg" />
        </Socialicons>
      </Logoframe>
      <Divider />
      <Twittericon>
        <LinkedInicon>© 2023 Relume. All rights reserved.</LinkedInicon>
        <Link3>Privacy Policy</Link3>
        <Link3>Terms of Service</Link3>
        <Link3>Cookies Settings</Link3>
      </Twittericon>
    </FooterRoot>
  );
};

export default Footer;
