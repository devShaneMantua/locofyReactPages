import { Button } from "@mui/material";
import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 640px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: contain;
  min-width: 400px;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const DescribeBenefitOf = styled.p`
  margin: 0;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 750px) {
    font-size: 38px;
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: 29px;
    line-height: 35px;
  }
`;
const Vector = styled.div`
  align-self: stretch;
  height: 54px;
  position: relative;
  font-size: 18px;
  line-height: 150%;
  display: inline-block;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 24px;
  text-align: left;
  font-size: 48px;
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 16px;
`;
const Button1 = styled(Button)`
  align-self: stretch;
  flex: 1;
`;
const Actions = styled.div`
  width: 129px;
  height: 64px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: 16px 0px 0px;
  box-sizing: border-box;
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 24px;
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: #fff;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: 112px 64px;
  box-sizing: border-box;
  gap: 80px;
  max-width: 100%;
  text-align: center;
  font-size: 16px;
  color: #000;
  font-family: Roboto;
  @media screen and (max-width: 1250px) {
    gap: 40px;
    padding-left: 32px;
    padding-right: 32px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 1100px) {
    padding-top: 73px;
    padding-bottom: 73px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: 20px;
  }
  @media screen and (max-width: 450px) {
    padding-top: 47px;
    padding-bottom: 47px;
    box-sizing: border-box;
  }
`;

const Layout1 = ({ placeholderImage, subheading, featureOne }) => {
  return (
    <LayoutRoot>
      <PlaceholderImage alt="" src={placeholderImage} />
      <Content1>
        <SectionTitle>
          <Subheading>{subheading}</Subheading>
          <Content>
            <Heading>
              <DescribeBenefitOf>Describe benefit of</DescribeBenefitOf>
              <DescribeBenefitOf>{featureOne}</DescribeBenefitOf>
            </Heading>
            <Vector>
              Highlight Unique Selling Proposition (USP) with a short summary of
              the key feature and how it benefits customers.
            </Vector>
          </Content>
        </SectionTitle>
        <Actions>
          <Button1
            disableElevation={true}
            variant="outlined"
            sx={{
              textTransform: "none",
              color: "#000",
              fontSize: "16",
              borderColor: "#000",
              borderRadius: "0px 0px 0px 0px",
              "&:hover": { borderColor: "#000" },
            }}
          >
            Learn more
          </Button1>
        </Actions>
      </Content1>
    </LayoutRoot>
  );
};

export default Layout1;
