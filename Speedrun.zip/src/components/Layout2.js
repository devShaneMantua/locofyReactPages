import { Button } from "@mui/material";
import styled from "styled-components";
import FrameComponent from "./FrameComponent";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 174px;
  position: relative;
  font-size: 48px;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 750px) {
    font-size: 38px;
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: 29px;
    line-height: 35px;
  }
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 16px;
`;
const Button1 = styled(Button)`
  align-self: stretch;
  flex: 1;
`;
const Actions = styled.div`
  width: 129px;
  height: 64px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: 16px 0px 0px;
  box-sizing: border-box;
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 32px;
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: 16px;
    min-width: 100%;
  }
`;
const HeaderTextIcon = styled.img`
  width: 39px;
  height: 39px;
  position: relative;
`;
const Content1 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 39px;
  height: 39px;
`;
const Heading1 = styled.b`
  flex: 1;
  position: relative;
  line-height: 140%;
  display: inline-block;
  min-width: 198px;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    font-size: 16px;
    line-height: 22px;
  }
`;
const CTAFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 40px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
    gap: 20px;
  }
`;
const SocialMediaIcons = styled.div`
  width: 537px;
  position: relative;
  font-size: 16px;
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
  margin-top: -1px;
`;
const FrameWithVectorDivider = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  max-width: 100%;
`;
const QuestionIconQuestion = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 16px;
  min-width: 400px;
  max-width: 100%;
  font-size: 20px;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: #fff;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 112px 64px;
  box-sizing: border-box;
  gap: 80px;
  max-width: 100%;
  text-align: left;
  font-size: 16px;
  color: #000;
  font-family: Roboto;
  @media screen and (max-width: 1250px) {
    gap: 40px;
    padding-left: 32px;
    padding-right: 32px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 1100px) {
    padding-top: 73px;
    padding-bottom: 73px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: 20px;
  }
  @media screen and (max-width: 450px) {
    padding-top: 47px;
    padding-bottom: 47px;
    box-sizing: border-box;
  }
`;

const Layout2 = () => {
  return (
    <LayoutRoot>
      <Column>
        <Content>
          <Subheading>How it works</Subheading>
          <Heading>
            Headline with USP related to how your product or service works
          </Heading>
        </Content>
        <Actions>
          <Button1
            disableElevation={true}
            variant="outlined"
            sx={{
              textTransform: "none",
              color: "#000",
              fontSize: "16",
              borderColor: "#000",
              borderRadius: "0px 0px 0px 0px",
              "&:hover": { borderColor: "#000" },
            }}
          >
            Learn more
          </Button1>
        </Actions>
      </Column>
      <QuestionIconQuestion>
        <FrameComponent heading="Short summary of step one" />
        <FrameComponent heading="Short summary of step two" />
        <FrameComponent heading="Short summary of step three" />
        <FrameWithVectorDivider>
          <CTAFrame>
            <Content1>
              <HeaderTextIcon alt="" src="/vector.svg" />
            </Content1>
            <Heading1>Short summary of step four</Heading1>
          </CTAFrame>
          <SocialMediaIcons>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique.
          </SocialMediaIcons>
        </FrameWithVectorDivider>
      </QuestionIconQuestion>
    </LayoutRoot>
  );
};

export default Layout2;
