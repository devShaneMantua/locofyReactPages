import {
  TextField,
  InputAdornment,
  Icon,
  IconButton,
  Button,
} from "@mui/material";
import styled from "styled-components";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 750px) {
    font-size: 38px;
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: 29px;
    line-height: 35px;
  }
`;
const ActionsButtonGroup = styled.div`
  align-self: stretch;
  position: relative;
  font-size: 18px;
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 24px;
`;
const TextInput = styled(TextField)`
  border: none;
  background-color: transparent;
  height: 48px;
  flex: 1;
  font-family: Roboto;
  font-size: 16px;
  color: #505050;
  min-width: 232px;
  max-width: 100%;
`;
const Button1 = styled(Button)`
  height: 48px;
  width: 140px;
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 16px;
  max-width: 100%;
`;
const ByClickingSign = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Actions = styled.div`
  width: 513px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 16px 0px 0px;
  box-sizing: border-box;
  gap: 16px;
  max-width: 100%;
  font-size: 12px;
`;
const Content1 = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: 24px;
  max-width: 100%;
`;
const CtaRoot = styled.section`
  align-self: stretch;
  background-color: #fff;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 112px 64px;
  box-sizing: border-box;
  max-width: 100%;
  text-align: center;
  font-size: 48px;
  color: #000;
  font-family: Roboto;
  @media screen and (max-width: 1100px) {
    padding-left: 32px;
    padding-right: 32px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    padding-top: 73px;
    padding-bottom: 73px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: 24px;
  }
`;

const CTA = () => {
  return (
    <CtaRoot>
      <Content1>
        <Content>
          <Heading>
            Call to action that invites visitor to try the product for free
          </Heading>
          <ActionsButtonGroup>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique.
          </ActionsButtonGroup>
        </Content>
        <Actions>
          <Form>
            <TextInput
              placeholder="Enter your email"
              variant="outlined"
              sx={{
                "& fieldset": { borderColor: "#000" },
                "& .MuiInputBase-root": {
                  height: "48px",
                  backgroundColor: "#fff",
                  borderRadius: "0px 0px 0px 0px",
                },
                "& .MuiInputBase-input": { color: "#505050" },
              }}
            />
            <Button1
              disableElevation={true}
              variant="contained"
              sx={{
                textTransform: "none",
                color: "#fff",
                fontSize: "16",
                background: "#000",
                borderRadius: "0px 0px 0px 0px",
                "&:hover": { background: "#000" },
                width: 142,
                height: 50,
              }}
            >
              Try it for free
            </Button1>
          </Form>
          <ByClickingSign>
            By clicking Sign Up you're confirming that you agree with our Terms
            and Conditions.
          </ByClickingSign>
        </Actions>
      </Content1>
    </CtaRoot>
  );
};

export default CTA;
