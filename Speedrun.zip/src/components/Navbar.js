import {
  Select,
  InputLabel,
  MenuItem,
  FormHelperText,
  FormControl,
  InputAdornment,
  Button,
} from "@mui/material";
import styled from "styled-components";

const Untitled97202308181553081Icon = styled.img`
  height: 49px;
  width: 116px;
  position: relative;
  object-fit: contain;
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Link = styled.div`
  position: relative;
  line-height: 150%;
`;
const Inputlabel1 = styled(InputLabel)``;
const Others = styled(MenuItem)``;
const Select1 = styled(Select)``;
const Formhelpertext1 = styled(FormHelperText)``;
const NavLinkDropdown = styled(FormControl)`
  height: 24px;
  width: 76px;
  font-family: Roboto;
  font-size: 16px;
  color: #000;
`;
const Column1 = styled.div`
  width: 315px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: 20px;
  @media screen and (max-width: 1250px) {
    display: none;
  }
`;
const Button1 = styled(Button)`
  width: 118px;
  height: 40px;
`;
const Column2 = styled.div`
  flex: 1;
  background-color: #fff;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: center;
  max-width: 100%;
`;
const Container = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: 32px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: 16px;
  }
`;
const NavbarRoot = styled.header`
  align-self: stretch;
  height: 72px;
  background-color: #fff;
  box-shadow: 0px -1px 0px #000 inset;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0px 64px;
  box-sizing: border-box;
  top: 0;
  z-index: 99;
  position: sticky;
  max-width: 100%;
  text-align: left;
  font-size: 16px;
  color: #000;
  font-family: Roboto;
  @media screen and (max-width: 750px) {
    padding-left: 32px;
    padding-right: 32px;
    box-sizing: border-box;
  }
`;

const Navbar = () => {
  return (
    <NavbarRoot>
      <Container>
        <Column>
          <Untitled97202308181553081Icon
            loading="eager"
            alt=""
            src="/untitled97-20230818155308-1@2x.png"
          />
        </Column>
        <Column1>
          <Link>Home</Link>
          <Link>About</Link>
          <Link>Contact</Link>
          <NavLinkDropdown
            variant="standard"
            sx={{
              borderTopWidth: "1px",
              borderRightWidth: "1px",
              borderBottomWidth: "1px",
              borderLeftWidth: "1px",
              borderRadius: "0px 0px 0px 0px",
              width: "76px",
              height: "24px",
              m: 0,
              p: 0,
              "& .MuiInputBase-root": {
                m: 0,
                p: 0,
                minHeight: "24px",
                justifyContent: "center",
                display: "inline-flex",
              },
              "& .MuiInputLabel-root": {
                m: 0,
                p: 0,
                minHeight: "24px",
                display: "inline-flex",
              },
              "& .MuiMenuItem-root": {
                m: 0,
                p: 0,
                height: "24px",
                display: "inline-flex",
              },
              "& .MuiSelect-select": {
                m: 0,
                p: 0,
                height: "24px",
                alignItems: "center",
                display: "inline-flex",
              },
              "& .MuiInput-input": { m: 0, p: 0 },
              "& .MuiInputBase-input": {
                color: "#000",
                fontSize: 16,
                fontWeight: "Regular",
                fontFamily: "Roboto",
                textAlign: "left",
                p: "0 !important",
              },
            }}
          >
            <Inputlabel1 color="primary" />
            <Select1
              color="primary"
              disableUnderline
              displayEmpty
              IconComponent={() => (
                <img
                  width="24px"
                  height="24px"
                  src="/chevron-down.svg"
                  style={{}}
                />
              )}
            >
              <Others>Others</Others>
            </Select1>
            <Formhelpertext1 />
          </NavLinkDropdown>
        </Column1>
        <Column2>
          <Button1
            disableElevation={true}
            variant="contained"
            sx={{
              textTransform: "none",
              color: "#fff",
              fontSize: "16",
              background: "#000",
              borderRadius: "0px 0px 0px 0px",
              "&:hover": { background: "#000" },
              width: 120,
              height: 42,
            }}
          >
            Try for free
          </Button1>
        </Column2>
      </Container>
    </NavbarRoot>
  );
};

export default Navbar;
