import styled from "styled-components";

const VectorGroupIcon = styled.img`
  width: 39px;
  height: 39px;
  position: relative;
`;
const Divider = styled.div`
  width: 41px;
  flex: 1;
  position: relative;
  border-right: 2px solid #000;
  box-sizing: border-box;
`;
const Content = styled.div`
  height: 155px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: 16px;
`;
const Heading = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
  @media screen and (max-width: 450px) {
    font-size: 16px;
    line-height: 22px;
  }
`;
const ActionsColumn = styled.div`
  align-self: stretch;
  position: relative;
  font-size: 16px;
  line-height: 150%;
`;
const TextHeadingFrame = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 10px;
  min-width: 349px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const FrameQuestionIconDividerRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 40px;
  max-width: 100%;
  text-align: left;
  font-size: 20px;
  color: #000;
  font-family: Roboto;
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
    gap: 20px;
  }
`;

const FrameComponent = ({ heading }) => {
  return (
    <FrameQuestionIconDividerRoot>
      <Content>
        <VectorGroupIcon loading="eager" alt="" src="/vector.svg" />
        <Divider />
      </Content>
      <TextHeadingFrame>
        <Heading>{heading}</Heading>
        <ActionsColumn>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique.
        </ActionsColumn>
      </TextHeadingFrame>
    </FrameQuestionIconDividerRoot>
  );
};

export default FrameComponent;
