import { Button } from "@mui/material";
import styled from "styled-components";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 116px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 750px) {
    font-size: 38px;
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: 29px;
    line-height: 35px;
  }
`;
const FAQtext = styled.div`
  align-self: stretch;
  position: relative;
  font-size: 18px;
  line-height: 150%;
`;
const Button1 = styled(Button)`
  width: 125px;
  height: 48px;
`;
const FAQquestion = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 24px;
  min-width: 500px;
  max-width: 100%;
  @media screen and (max-width: 1250px) {
    flex: 1;
  }
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: #000;
`;
const Question = styled.b`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  min-width: 153px;
  max-width: 100%;
`;
const Icon1 = styled.img`
  height: 32px;
  width: 32px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Questionframe = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: 12px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const FAQdivider = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 20px;
  min-width: 476px;
  max-width: 100%;
  font-size: 18px;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const FaqRoot = styled.section`
  align-self: stretch;
  background-color: #fff;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 112px 64px;
  box-sizing: border-box;
  gap: 80px;
  max-width: 100%;
  text-align: left;
  font-size: 48px;
  color: #000;
  font-family: Roboto;
  @media screen and (max-width: 1250px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 750px) {
    gap: 40px;
    padding: 73px 32px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: 20px;
  }
`;

const FAQ = () => {
  return (
    <FaqRoot>
      <FAQquestion>
        <Heading>Frequently asked questions</Heading>
        <FAQtext>
          Frequently asked questions ordered by popularity. Remember that if the
          visitor has not committed to the call to action, they may still have
          questions (doubts) that can be answered.
        </FAQtext>
        <Button1
          disableElevation={true}
          variant="outlined"
          sx={{
            textTransform: "none",
            color: "#000",
            fontSize: "16",
            borderColor: "#000",
            borderRadius: "0px 0px 0px 0px",
            "&:hover": { borderColor: "#000" },
            width: 127,
            height: 50,
          }}
        >
          Contact us
        </Button1>
      </FAQquestion>
      <FAQdivider>
        <Divider />
        <Questionframe>
          <Question>Question text goes here</Question>
          <Icon1 loading="eager" alt="" src="/icon.svg" />
        </Questionframe>
        <Divider />
        <Questionframe>
          <Question>Question text goes here</Question>
          <Icon1 alt="" src="/icon.svg" />
        </Questionframe>
        <Divider />
        <Questionframe>
          <Question>Question text goes here</Question>
          <Icon1 alt="" src="/icon.svg" />
        </Questionframe>
        <Divider />
        <Questionframe>
          <Question>Question text goes here</Question>
          <Icon1 alt="" src="/icon.svg" />
        </Questionframe>
        <Divider />
        <Questionframe>
          <Question>Question text goes here</Question>
          <Icon1 alt="" src="/icon.svg" />
        </Questionframe>
        <Divider />
      </FAQdivider>
    </FaqRoot>
  );
};

export default FAQ;
