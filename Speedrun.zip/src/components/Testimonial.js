import styled from "styled-components";

const AvatarImageFrame = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 4px;
`;
const Quote = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 102px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: 19px;
    line-height: 27px;
  }
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: contain;
`;
const TestimonialContainer = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const InnerFrame = styled.div`
  position: relative;
  line-height: 150%;
`;
const Divider = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider1 = styled.div`
  height: 62px;
  width: 1px;
  position: relative;
  border-right: 1px solid #000;
  box-sizing: border-box;
  @media screen and (max-width: 450px) {
    width: 100px;
    height: 1px;
    border-top: 1px solid #000;
    box-sizing: border-box;
  }
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const CTATextLinkLinks = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: 20px;
  max-width: 100%;
  text-align: left;
  font-size: 16px;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content = styled.div`
  width: 768px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: 32px;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    gap: 16px;
  }
`;
const TestimonialRoot = styled.section`
  align-self: stretch;
  background-color: #fff;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: 112px;
  box-sizing: border-box;
  max-width: 100%;
  text-align: center;
  font-size: 24px;
  color: #000;
  font-family: Roboto;
  @media screen and (max-width: 1100px) {
    padding-left: 56px;
    padding-right: 56px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: 24px;
    padding: 73px 28px;
    box-sizing: border-box;
  }
`;

const Testimonial = ({ avatarImage, testimonialcontainer }) => {
  return (
    <TestimonialRoot>
      <Content>
        <Stars>
          <AvatarImageFrame alt="" src="/vector-4.svg" />
          <AvatarImageFrame alt="" src="/vector-4.svg" />
          <AvatarImageFrame alt="" src="/vector-4.svg" />
          <AvatarImageFrame alt="" src="/vector-4.svg" />
          <AvatarImageFrame alt="" src="/vector-4.svg" />
        </Stars>
        <Quote>
          "A customer testimonial that highlights features and answers potential
          customer doubts about your product or service. Showcase testimonials
          from a similar demographic to your customers."
        </Quote>
        <CTATextLinkLinks>
          <AvatarImageIcon loading="eager" alt="" src={avatarImage} />
          <Divider>
            <TestimonialContainer>{testimonialcontainer}</TestimonialContainer>
            <InnerFrame>Position, Company name</InnerFrame>
          </Divider>
          <Divider1 />
          <WebflowBlack loading="eager" alt="" src="/webflow--black.svg" />
        </CTATextLinkLinks>
      </Content>
    </TestimonialRoot>
  );
};

export default Testimonial;
