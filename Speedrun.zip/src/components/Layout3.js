import styled from "styled-components";

const IconFrame = styled.input`
  margin: 0;
  width: 24px;
  height: 24px;
  position: relative;
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: 19px;
    line-height: 27px;
  }
`;
const ContentHeadingText = styled.div`
  align-self: stretch;
  height: 96px;
  position: relative;
  font-size: 16px;
  line-height: 150%;
  display: inline-block;
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 24px;
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 24px;
  min-width: 304px;
  max-width: 100%;
`;
const IconFrame1 = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
  position: absolute;
  left: 10px;
  top: 6px;
  transform: scale(1.871);
`;
const WrapperIconFrame = styled.div`
  width: 24px;
  height: 24px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
`;
const LayoutRoot = styled.section`
  align-self: stretch;
  background-color: #fff;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: 112px 64px;
  box-sizing: border-box;
  gap: 48px;
  max-width: 100%;
  text-align: left;
  font-size: 24px;
  color: #000;
  font-family: Roboto;
  @media screen and (max-width: 750px) {
    gap: 24px;
    padding-left: 32px;
    padding-right: 32px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-top: 73px;
    padding-bottom: 73px;
    box-sizing: border-box;
  }
`;

const Layout3 = () => {
  return (
    <LayoutRoot>
      <Column>
        <IconFrame type="checkbox" />
        <SectionTitle>
          <Heading>Highlight benefit one</Heading>
          <ContentHeadingText>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla.
          </ContentHeadingText>
        </SectionTitle>
      </Column>
      <Column>
        <WrapperIconFrame>
          <IconFrame1 alt="" src="/icon-frame-1.svg" />
        </WrapperIconFrame>
        <SectionTitle>
          <Heading>Highlight benefit two</Heading>
          <ContentHeadingText>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla.
          </ContentHeadingText>
        </SectionTitle>
      </Column>
      <Column>
        <IconFrame type="checkbox" />
        <SectionTitle>
          <Heading>Highlight benefit three</Heading>
          <ContentHeadingText>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla.
          </ContentHeadingText>
        </SectionTitle>
      </Column>
    </LayoutRoot>
  );
};

export default Layout3;
