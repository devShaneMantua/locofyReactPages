import {
  TextField,
  InputAdornment,
  Icon,
  IconButton,
  Button,
} from "@mui/material";
import styled from "styled-components";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 134px;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 750px) {
    font-size: 45px;
    line-height: 54px;
  }
  @media screen and (max-width: 450px) {
    font-size: 34px;
    line-height: 40px;
  }
`;
const TextVectorContent = styled.div`
  align-self: stretch;
  position: relative;
  font-size: 18px;
  line-height: 150%;
`;
const SectionTitle = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 24px;
`;
const TextInput = styled(TextField)`
  border: none;
  background-color: transparent;
  height: 48px;
  flex: 1;
  font-family: Roboto;
  font-size: 16px;
  color: #505050;
  min-width: 232px;
  max-width: 100%;
`;
const Button1 = styled(Button)`
  height: 48px;
  width: 140px;
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 16px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const TermsAndConditions = styled.span`
  text-decoration: underline;
`;
const ByClickingSignContainer = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Actions = styled.div`
  width: 513px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 16px 0px 0px;
  box-sizing: border-box;
  gap: 16px;
  max-width: 100%;
  font-size: 12px;
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 24px;
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const PlaceholderImage = styled.img`
  height: 640px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: contain;
  min-width: 400px;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const HeaderRoot = styled.section`
  align-self: stretch;
  background-color: #fff;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: 112px 64px;
  box-sizing: border-box;
  gap: 80px;
  max-width: 100%;
  text-align: left;
  font-size: 56px;
  color: #000;
  font-family: Roboto;
  @media screen and (max-width: 1250px) {
    gap: 40px;
    padding-left: 32px;
    padding-right: 32px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 1100px) {
    padding-top: 73px;
    padding-bottom: 73px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: 20px;
  }
  @media screen and (max-width: 450px) {
    padding-top: 47px;
    padding-bottom: 47px;
    box-sizing: border-box;
  }
`;

const Header = () => {
  return (
    <HeaderRoot>
      <Content>
        <SectionTitle>
          <Heading>Resonate with the visitor's problem</Heading>
          <TextVectorContent>
            Describe exactly what your product or service does to solve this
            problem. Avoid using verbose words or phrases.
          </TextVectorContent>
        </SectionTitle>
        <Actions>
          <Form>
            <TextInput
              placeholder="Enter your email"
              variant="outlined"
              sx={{
                "& fieldset": { borderColor: "#000" },
                "& .MuiInputBase-root": {
                  height: "48px",
                  backgroundColor: "#fff",
                  borderRadius: "0px 0px 0px 0px",
                },
                "& .MuiInputBase-input": { color: "#505050" },
              }}
            />
            <Button1
              disableElevation={true}
              variant="contained"
              sx={{
                textTransform: "none",
                color: "#fff",
                fontSize: "16",
                background: "#000",
                borderRadius: "0px 0px 0px 0px",
                "&:hover": { background: "#000" },
                width: 142,
                height: 50,
              }}
            >
              Try it for free
            </Button1>
          </Form>
          <ByClickingSignContainer>
            {`By clicking Sign Up you're confirming that you agree with our `}
            <TermsAndConditions>Terms and Conditions</TermsAndConditions>.
          </ByClickingSignContainer>
        </Actions>
      </Content>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image@2x.png"
      />
    </HeaderRoot>
  );
};

export default Header;
