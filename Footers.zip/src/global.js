import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--text-small-link: Roboto;

/* font sizes */
--text-small-link-size: 14px;
--text-regular-semi-bold-size: 16px;
--font-size-xs: 12px;
--text-medium-semi-bold-size: 18px;

/* Colors */
--color-darkslategray-100: #333;
--color-darkslategray-200: rgba(51, 51, 51, 0.09);
--white: #fff;
--black: #000;
--color-dimgray: #505050;

/* Gaps */
--gap-6xl: 25px;
--gap-61xl: 80px;
--gap-21xl: 40px;
--gap-xl: 20px;
--gap-13xl: 32px;
--gap-base: 16px;
--gap-5xl: 24px;
--gap-45xl: 64px;
--gap-xs: 12px;
--gap-9xs: 4px;
--gap-14xl: 33px;

/* Paddings */
--padding-61xl: 80px;
--padding-45xl: 64px;
--padding-33xl: 52px;
--padding-13xl: 32px;
--padding-15xl: 34px;
--padding-5xs: 8px;
--padding-xs: 12px;
--padding-4xl: 23px;
--padding-smi: 13px;
--padding-2xs: 11px;
--padding-241xl: 260px;
--padding-xl: 20px;
--padding-29xl: 48px;
--padding-30xl: 49px;
--padding-28xl: 47px;
--padding-5xl: 24px;
--padding-23xl: 42px;

}
`;
