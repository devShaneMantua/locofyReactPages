import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const LinkNode = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  white-space: nowrap;
`;
const Placeholder = styled.input`
  width: 100%;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-semi-bold-size);
  background-color: transparent;
  height: 24px;
  flex: 1;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
  min-width: 205px;
  max-width: 100%;
  white-space: nowrap;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-smi) var(--padding-xs)
    var(--padding-2xs);
  max-width: 100%;
  min-width: ${(p) => p.buttonMinWidth};
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-4xl);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const SubmitButton = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--font-size-xs);
`;
const Newsletter = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  min-width: ${(p) => p.linkNodeMinWidth};
`;
const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  white-space: nowrap;
`;
const Link = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  white-space: nowrap;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: ${(p) => p.footerLinksMinWidth};
`;
const Column1 = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: ${(p) => p.footerLinksMinWidth1};
`;
const IconFacebook = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Facebook = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-xs);
`;
const Column2 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: ${(p) => p.socialLinksMinWidth};
`;
const Links = styled.div`width: 588px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
  gap: var(--gap-xl);
  
  }
  width: ${(p) => p.headingWidth}
  min-width: ${(p) => p.headingMinWidth}
`;
const CardRoot = styled.div`align-self: stretch;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  padding: var(--padding-29xl) var(--padding-30xl) var(--padding-29xl) var(--padding-28xl);
  gap: var(--gap-xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1350px) {
  padding-left: var(--padding-4xl);
  padding-right: var(--padding-5xl);
  box-sizing: border-box;
  
  }
  border: ${(p) => p.logoIconBorder}
  padding: ${(p) => p.logoIconPadding}
  min-height: ${(p) => p.logoIconMinHeight}
`;

const Card2 = ({
  logoIconBorder,
  logoIconPadding,
  logoIconMinHeight,
  linkNodeMinWidth,
  buttonMinWidth,
  headingWidth,
  headingMinWidth,
  footerLinksMinWidth,
  footerLinksMinWidth1,
  socialLinksMinWidth,
}) => {
  return (
    <CardRoot
      logoIconBorder={logoIconBorder}
      logoIconPadding={logoIconPadding}
      logoIconMinHeight={logoIconMinHeight}
    >
      <Newsletter linkNodeMinWidth={linkNodeMinWidth}>
        <LogoIcon loading="eager" alt="" src="/logo.svg" />
        <LinkNode>
          Join our newsletter to stay up to date on features and releases.
        </LinkNode>
        <Actions>
          <Form>
            <TextInput buttonMinWidth={buttonMinWidth}>
              <Placeholder placeholder="Enter your email" type="text" />
            </TextInput>
            <Button1>
              <Button>Subscribe</Button>
            </Button1>
          </Form>
          <SubmitButton>
            {`By subscribing you agree to with our `}
            <PrivacyPolicy>Privacy Policy</PrivacyPolicy> and provide consent to
            receive updates from our company.
          </SubmitButton>
        </Actions>
      </Newsletter>
      <Links headingWidth={headingWidth} headingMinWidth={headingMinWidth}>
        <Column footerLinksMinWidth={footerLinksMinWidth}>
          <Heading>Column One</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link One</Link>
            </Link1>
            <Link1>
              <Link>Link Two</Link>
            </Link1>
            <Link1>
              <Link>Link Three</Link>
            </Link1>
            <Link1>
              <Link>Link Four</Link>
            </Link1>
            <Link1>
              <Link>Link Five</Link>
            </Link1>
          </FooterLinks>
        </Column>
        <Column1 footerLinksMinWidth1={footerLinksMinWidth1}>
          <Heading>Column Two</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Six</Link>
            </Link1>
            <Link1>
              <Link>Link Seven</Link>
            </Link1>
            <Link1>
              <Link>Link Eight</Link>
            </Link1>
            <Link1>
              <Link>Link Nine</Link>
            </Link1>
            <Link1>
              <Link>Link Ten</Link>
            </Link1>
          </FooterLinks>
        </Column1>
        <Column2 socialLinksMinWidth={socialLinksMinWidth}>
          <Heading>Follow Us</Heading>
          <FooterLinks>
            <Link2>
              <IconFacebook loading="eager" alt="" src="/icon--facebook.svg" />
              <Facebook>Facebook</Facebook>
            </Link2>
            <Link2>
              <IconFacebook loading="eager" alt="" src="/icon--instagram.svg" />
              <Facebook>Instagram</Facebook>
            </Link2>
            <Link2>
              <IconFacebook loading="eager" alt="" src="/icon--twitter.svg" />
              <Facebook>Twitter</Facebook>
            </Link2>
            <Link2>
              <IconFacebook loading="eager" alt="" src="/icon--linkedin.svg" />
              <Facebook>LinkedIn</Facebook>
            </Link2>
          </FooterLinks>
        </Column2>
      </Links>
    </CardRoot>
  );
};

export default Card2;
