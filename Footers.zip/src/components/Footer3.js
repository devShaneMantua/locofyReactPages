import styled from "styled-components";

const LogoIcon = styled.img`
  height: 27px;
  width: 63px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Logo = styled.div`
  width: 392.5px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  max-width: 100%;
`;
const Link = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link1 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
  min-width: 49px;
`;
const Link2 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
  min-width: 44px;
`;
const Links = styled.div`
  width: 463px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  padding: 0px 0px 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const IconFacebook = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const SocialLinks = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px 0px 0px var(--padding-241xl);
  box-sizing: border-box;
  gap: var(--gap-xs);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
    padding-left: var(--padding-xl);
    box-sizing: border-box;
  }
`;
const Content = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-14xl);
  max-width: 100%;
  @media screen and (max-width: 1350px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
  }
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Text1 = styled.div`
  position: relative;
  line-height: 150%;
  flex-shrink: 0;
`;
const Link3 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const Link4 = styled.div`
  flex: 1;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
  min-width: 68px;
`;
const FooterLinks = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 224px;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Row = styled.div`
  width: 570px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-6xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const Credits = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
  }
`;
const FooterRoot = styled.section`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;

const Footer3 = () => {
  return (
    <FooterRoot>
      <Content>
        <Logo>
          <LogoIcon alt="" src="/logo.svg" />
        </Logo>
        <Links>
          <Link>Link One</Link>
          <Link>Link Two</Link>
          <Link1>Link Three</Link1>
          <Link2>Link Four</Link2>
          <Link>Link Five</Link>
        </Links>
        <SocialLinks>
          <IconFacebook alt="" src="/icon--facebook-5.svg" />
          <IconFacebook alt="" src="/icon--instagram-5.svg" />
          <IconFacebook alt="" src="/icon--twitter-5.svg" />
          <IconFacebook alt="" src="/icon--linkedin-5.svg" />
        </SocialLinks>
      </Content>
      <Credits>
        <Divider />
        <Row>
          <Text1>2023 Relume. All right reserved.</Text1>
          <FooterLinks>
            <Link3>Privacy Policy</Link3>
            <Link4>Terms of Service</Link4>
            <Link4>Cookies Settings</Link4>
          </FooterLinks>
        </Row>
      </Credits>
    </FooterRoot>
  );
};

export default Footer3;
