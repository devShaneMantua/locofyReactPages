import Newsletter from "./Newsletter";
import styled from "styled-components";

const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 182px;
  max-width: 185px;
`;
const Links = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  @media screen and (max-width: 1350px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-xl);
  }
`;
const LogoIcon = styled.img`
  height: 27px;
  width: 63px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Text1 = styled.div`
  position: relative;
  line-height: 150%;
`;
const Credits = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--gap-xl);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Credits1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
  }
`;
const Container = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;
const FooterRoot = styled.section`
  width: 1440px;
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
    padding: var(--padding-33xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
    padding-top: var(--padding-15xl);
    padding-bottom: var(--padding-15xl);
    box-sizing: border-box;
  }
`;

const Footer1 = () => {
  return (
    <FooterRoot>
      <Container>
        <Newsletter />
        <Divider />
        <Links>
          <Column>
            <Heading>Column One</Heading>
            <FooterLinks>
              <Link1>
                <Link>Link One</Link>
              </Link1>
              <Link1>
                <Link>Link Two</Link>
              </Link1>
              <Link1>
                <Link>Link Three</Link>
              </Link1>
              <Link1>
                <Link>Link Four</Link>
              </Link1>
              <Link1>
                <Link>Link Five</Link>
              </Link1>
            </FooterLinks>
          </Column>
          <Column>
            <Heading>Column Two</Heading>
            <FooterLinks>
              <Link1>
                <Link>Link Six</Link>
              </Link1>
              <Link1>
                <Link>Link Seven</Link>
              </Link1>
              <Link1>
                <Link>Link Eight</Link>
              </Link1>
              <Link1>
                <Link>Link Nine</Link>
              </Link1>
              <Link1>
                <Link>Link Ten</Link>
              </Link1>
            </FooterLinks>
          </Column>
          <Column>
            <Heading>Column Three</Heading>
            <FooterLinks>
              <Link1>
                <Link>Link Eleven</Link>
              </Link1>
              <Link1>
                <Link>Link Twelve</Link>
              </Link1>
              <Link1>
                <Link>Link Thirteen</Link>
              </Link1>
              <Link1>
                <Link>Link Fourteen</Link>
              </Link1>
              <Link1>
                <Link>Link Fifteen</Link>
              </Link1>
            </FooterLinks>
          </Column>
          <Column>
            <Heading>Column Four</Heading>
            <FooterLinks>
              <Link1>
                <Link>Link Sixteen</Link>
              </Link1>
              <Link1>
                <Link>Link Seventeen</Link>
              </Link1>
              <Link1>
                <Link>Link Eightteen</Link>
              </Link1>
              <Link1>
                <Link>Link Nineteen</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty</Link>
              </Link1>
            </FooterLinks>
          </Column>
          <Column>
            <Heading>Column Five</Heading>
            <FooterLinks>
              <Link1>
                <Link>Link Twenty One</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty Two</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty Three</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty Four</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty Five</Link>
              </Link1>
            </FooterLinks>
          </Column>
          <Column>
            <Heading>Column Six</Heading>
            <FooterLinks>
              <Link1>
                <Link>Link Twenty Six</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty Seven</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty Eight</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty Nine</Link>
              </Link1>
              <Link1>
                <Link>Link Thirty</Link>
              </Link1>
            </FooterLinks>
          </Column>
        </Links>
        <Credits1>
          <Divider />
          <Row>
            <LogoIcon alt="" src="/logo.svg" />
            <Credits>
              <Text1>© 2023 Relume. All rights reserved.</Text1>
            </Credits>
          </Row>
        </Credits1>
      </Container>
    </FooterRoot>
  );
};

export default Footer1;
