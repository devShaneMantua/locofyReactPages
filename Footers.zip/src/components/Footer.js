import Card1 from "./Card1";
import styled from "styled-components";

const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Text1 = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const CookiesSettings = styled.div`
  align-self: stretch;
  width: 105px;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: none;
`;
const FooterLinks = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const Credits = styled.footer`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
  }
`;
const FooterRoot = styled.section`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
    padding: var(--padding-33xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;

const Footer = () => {
  return (
    <FooterRoot>
      <Card1
        propBorder="unset"
        propPadding="unset"
        propMinWidth="864px"
        propWidth="384px"
        propMinWidth1="250px"
        propMinWidth2="117px"
        propMinWidth3="117px"
      />
      <Credits>
        <Divider />
        <Row>
          <Text1>© 2023 Relume. All rights reserved.</Text1>
          <FooterLinks>
            <Link>Privacy Policy</Link>
            <Link>Terms of Service</Link>
            <CookiesSettings>Cookies Settings</CookiesSettings>
          </FooterLinks>
        </Row>
      </Credits>
    </FooterRoot>
  );
};

export default Footer;
