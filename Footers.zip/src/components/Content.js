import styled from "styled-components";

const LogoIcon = styled.img`height: 27px;
  width: 63px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  width: ${(p) => p.propWidth1}
  align-self: ${(p) => p.propAlignSelf}
`;
const Logo = styled.div`overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  flex-direction: ${(p) => p.propFlexDirection}
  width: ${(p) => p.propWidth}
`;
const Link = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link1 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
  min-width: 49px;
`;
const Link2 = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
  min-width: 44px;
`;
const Links = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  padding: 0px 0px 0px 0px;
  gap: var(--gap-xl);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
    justify-content: center;
  }
  padding: ${(p) => p.propPadding};
`;
const ContentRoot = styled.div`
  width: 464px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
`;

const Content = ({
  propFlexDirection,
  propWidth,
  propWidth1,
  propAlignSelf,
  propPadding,
}) => {
  return (
    <ContentRoot>
      <Logo propFlexDirection={propFlexDirection} propWidth={propWidth}>
        <LogoIcon
          alt=""
          src="/logo.svg"
          propWidth1={propWidth1}
          propAlignSelf={propAlignSelf}
        />
      </Logo>
      <Links propPadding={propPadding}>
        <Link>Link One</Link>
        <Link>Link Two</Link>
        <Link1>Link Three</Link1>
        <Link2>Link Four</Link2>
        <Link>Link Five</Link>
      </Links>
    </ContentRoot>
  );
};

export default Content;
