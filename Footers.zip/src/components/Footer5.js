import Card1 from "./Card1";
import styled from "styled-components";

const NewsletterForm = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const Link1 = styled.div`
  flex: 1;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
  min-width: 68px;
`;
const FooterLinks = styled.div`
  width: 345px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const Credits = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
  }
`;
const FooterRoot = styled.section`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
    padding: var(--padding-33xl) var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const Footer5 = () => {
  return (
    <FooterRoot>
      <Card1
        propBorder="1px solid var(--black)"
        propPadding="var(--padding-29xl) var(--padding-30xl) var(--padding-29xl) var(--padding-28xl)"
        propWidth="288px"
        propMinWidth1="187px"
        propMinWidth2="86px"
        propMinWidth3="86px"
      />
      <Credits>
        <Row>
          <NewsletterForm>© 2023 Relume. All rights reserved.</NewsletterForm>
          <FooterLinks>
            <Link>Privacy Policy</Link>
            <Link1>Terms of Service</Link1>
            <Link1>Cookies Settings</Link1>
          </FooterLinks>
        </Row>
      </Credits>
    </FooterRoot>
  );
};

export default Footer5;
