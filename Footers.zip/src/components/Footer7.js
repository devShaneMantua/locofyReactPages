import Newsletter from "./Newsletter";
import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 182px;
  max-width: 185px;
`;
const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column1 = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 182px;
  max-width: 185px;
`;
const Links = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  font-size: var(--text-regular-semi-bold-size);
  @media screen and (max-width: 1350px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 800px) {
    gap: var(--gap-xl);
  }
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Text1 = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link2 = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const Link3 = styled.div`
  flex: 1;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
  min-width: 68px;
`;
const FooterLinks1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 224px;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Credits = styled.div`
  width: 589px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const IconFacebook = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const SocialLinks = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 1125px) {
    flex-wrap: wrap;
  }
`;
const Credits1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
  }
`;
const Container = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;
const FooterRoot = styled.section`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
    padding: var(--padding-33xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;

const Footer7 = () => {
  return (
    <FooterRoot>
      <Container>
        <Newsletter />
        <Links>
          <Column>
            <LogoIcon alt="" src="/logo.svg" />
          </Column>
          <Column1>
            <Heading>Column One</Heading>
            <FooterLinks>
              <Link1>
                <Link>Link One</Link>
              </Link1>
              <Link1>
                <Link>Link Two</Link>
              </Link1>
              <Link1>
                <Link>Link Three</Link>
              </Link1>
              <Link1>
                <Link>Link Four</Link>
              </Link1>
              <Link1>
                <Link>Link Five</Link>
              </Link1>
            </FooterLinks>
          </Column1>
          <Column1>
            <Heading>Column Two</Heading>
            <FooterLinks>
              <Link1>
                <Link>Link Six</Link>
              </Link1>
              <Link1>
                <Link>Link Seven</Link>
              </Link1>
              <Link1>
                <Link>Link Eight</Link>
              </Link1>
              <Link1>
                <Link>Link Nine</Link>
              </Link1>
              <Link1>
                <Link>Link Ten</Link>
              </Link1>
            </FooterLinks>
          </Column1>
          <Column1>
            <Heading>Column Three</Heading>
            <FooterLinks>
              <Link1>
                <Link>Link Eleven</Link>
              </Link1>
              <Link1>
                <Link>Link Twelve</Link>
              </Link1>
              <Link1>
                <Link>Link Thirteen</Link>
              </Link1>
              <Link1>
                <Link>Link Fourteen</Link>
              </Link1>
              <Link1>
                <Link>Link Fifteen</Link>
              </Link1>
            </FooterLinks>
          </Column1>
          <Column1>
            <Heading>Column Four</Heading>
            <FooterLinks>
              <Link1>
                <Link>Link Sixteen</Link>
              </Link1>
              <Link1>
                <Link>Link Seventeen</Link>
              </Link1>
              <Link1>
                <Link>Link Eightteen</Link>
              </Link1>
              <Link1>
                <Link>Link Nineteen</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty</Link>
              </Link1>
            </FooterLinks>
          </Column1>
          <Column1>
            <Heading>Column Five</Heading>
            <FooterLinks>
              <Link1>
                <Link>Link Twenty One</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty Two</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty Three</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty Four</Link>
              </Link1>
              <Link1>
                <Link>Link Twenty Five</Link>
              </Link1>
            </FooterLinks>
          </Column1>
        </Links>
        <Credits1>
          <Divider />
          <Row>
            <Credits>
              <Text1>© 2023 Relume. All rights reserved.</Text1>
              <FooterLinks1>
                <Link2>Privacy Policy</Link2>
                <Link3>Terms of Service</Link3>
                <Link3>Cookies Settings</Link3>
              </FooterLinks1>
            </Credits>
            <SocialLinks>
              <IconFacebook alt="" src="/icon--facebook.svg" />
              <IconFacebook alt="" src="/icon--instagram.svg" />
              <IconFacebook alt="" src="/icon--twitter.svg" />
              <IconFacebook alt="" src="/icon--linkedin.svg" />
            </SocialLinks>
          </Row>
        </Credits1>
      </Container>
    </FooterRoot>
  );
};

export default Footer7;
