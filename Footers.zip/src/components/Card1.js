import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const DividerVertical = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const P = styled.p`
  margin: 0;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const IconFacebook = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const SocialLinks = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Column = styled.div`
  width: 864px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    gap: var(--gap-base);
  }
  min-width: ${(p) => p.propMinWidth};
`;
const LinkList = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
  min-width: 86px;
  min-width: ${(p) => p.propMinWidth2};
`;
const LinkList1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
  min-width: 86px;
  min-width: ${(p) => p.propMinWidth3};
`;
const Column1 = styled.div`width: 288px;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 187px;
  font-size: var(--text-regular-semi-bold-size);
  @media screen and (max-width: 450px) {
  flex-wrap: wrap;
  
  }
  width: ${(p) => p.propWidth}
  min-width: ${(p) => p.propMinWidth1}
`;
const CardRoot = styled.div`align-self: stretch;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-29xl) var(--padding-30xl) var(--padding-29xl) var(--padding-28xl);
  gap: var(--gap-45xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1350px) {
  flex-wrap: wrap;
  padding-left: var(--padding-4xl);
  padding-right: var(--padding-5xl);
  box-sizing: border-box;
  
  }
  @media screen and (max-width: 800px) {
  gap: var(--gap-13xl);
  
  }
  @media screen and (max-width: 450px) {
  gap: var(--gap-base);
  
  }
  border: ${(p) => p.propBorder}
  padding: ${(p) => p.propPadding}
`;

const Card1 = ({
  propBorder,
  propPadding,
  propMinWidth,
  propWidth,
  propMinWidth1,
  propMinWidth2,
  propMinWidth3,
}) => {
  return (
    <CardRoot propBorder={propBorder} propPadding={propPadding}>
      <Column propMinWidth={propMinWidth}>
        <LogoIcon alt="" src="/logo.svg" />
        <Content1>
          <Content>
            <Heading>Address:</Heading>
            <DividerVertical>
              Level 1, 12 Sample St, Sydney NSW 2000
            </DividerVertical>
          </Content>
          <Content>
            <Heading>Contact:</Heading>
            <Text1>
              <P>1800 123 4567</P>
              <P>info@relume.io</P>
            </Text1>
          </Content>
          <SocialLinks>
            <IconFacebook alt="" src="/icon--facebook.svg" />
            <IconFacebook alt="" src="/icon--instagram.svg" />
            <IconFacebook alt="" src="/icon--twitter.svg" />
            <IconFacebook alt="" src="/icon--linkedin.svg" />
          </SocialLinks>
        </Content1>
      </Column>
      <Column1 propWidth={propWidth} propMinWidth1={propMinWidth1}>
        <LinkList propMinWidth2={propMinWidth2}>
          <Heading>Link One</Heading>
          <Heading>Link Two</Heading>
          <Heading>Link Three</Heading>
          <Heading>Link Four</Heading>
          <Heading>Link Five</Heading>
        </LinkList>
        <LinkList1 propMinWidth3={propMinWidth3}>
          <Heading>Link Six</Heading>
          <Heading>Link Seven</Heading>
          <Heading>Link Eight</Heading>
          <Heading>Link Nine</Heading>
          <Heading>Link Ten</Heading>
        </LinkList1>
      </Column1>
    </CardRoot>
  );
};

export default Card1;
