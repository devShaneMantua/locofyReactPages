import Card2 from "./Card2";
import styled from "styled-components";

const Text1 = styled.div`
  position: relative;
  line-height: 150%;
  white-space: nowrap;
`;
const Link = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  white-space: nowrap;
`;
const Link1 = styled.div`
  flex: 1;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  white-space: nowrap;
`;
const FooterLinks = styled.div`
  width: 345px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
`;
const Credits = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  font-size: var(--text-small-link-size);
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
  }
`;
const FooterRoot = styled.header`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
    padding: var(--padding-23xl) var(--padding-13xl);
    box-sizing: border-box;
  }
`;

const Footer10 = () => {
  return (
    <FooterRoot>
      <Card2
        logoIconBorder="1px solid var(--black)"
        logoIconPadding="var(--padding-29xl) var(--padding-30xl) var(--padding-29xl) var(--padding-28xl)"
        headingWidth="588px"
      />
      <Credits>
        <Row>
          <Text1>© 2023 Relume. All rights reserved.</Text1>
          <FooterLinks>
            <Link>Privacy Policy</Link>
            <Link1>Terms of Service</Link1>
            <Link1>Cookies Settings</Link1>
          </FooterLinks>
        </Row>
      </Credits>
    </FooterRoot>
  );
};

export default Footer10;
