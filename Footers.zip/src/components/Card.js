import styled from "styled-components";

const LogoIcon = styled.img`
  width: 63px;
  height: 27px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Column = styled.div`
  width: 117px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  width: ${(p) => p.propWidth};
`;
const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const Link1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
`;
const FooterLinks = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--text-small-link-size);
`;
const Column1 = styled.div`
  width: 117px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  width: ${(p) => p.propWidth1};
`;
const Column2 = styled.div`
  width: 117px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  width: ${(p) => p.propWidth2};
`;
const Column3 = styled.div`
  width: 117px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  width: ${(p) => p.propWidth3};
`;
const Links = styled.div`
  flex: 1;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  min-width: 382px;
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-xl);
    min-width: 100%;
  }
  min-width: ${(p) => p.propMinWidth};
`;
const SocialIconsFrame = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const HeadingTextContent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Placeholder = styled.input`
  width: 100%;
  border: none;
  outline: none;
  font-family: var(--text-small-link);
  font-size: var(--text-regular-semi-bold-size);
  background-color: transparent;
  height: 24px;
  flex: 1;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
  min-width: 205px;
  max-width: 100%;
`;
const TextInput = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-smi) var(--padding-xs)
    var(--padding-2xs);
  min-width: 237px;
  max-width: 100%;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-semi-bold-size);
  line-height: 150%;
  font-family: var(--text-small-link);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-4xl);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Form = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const PrivacyPolicy = styled.span`
  text-decoration: underline;
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--font-size-xs);
`;
const Newslatter = styled.div`
  width: 500px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 500px;
  max-width: 100%;
  @media screen and (max-width: 1125px) {
    flex: 1;
  }
  @media screen and (max-width: 800px) {
    min-width: 100%;
  }
`;
const CardRoot = styled.div`align-self: stretch;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  padding: var(--padding-29xl) var(--padding-30xl) var(--padding-29xl) var(--padding-28xl);
  gap: var(--gap-xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-semi-bold-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 1350px) {
  padding-left: var(--padding-4xl);
  padding-right: var(--padding-5xl);
  box-sizing: border-box;
  
  }
  @media screen and (max-width: 1125px) {
  flex-wrap: wrap;
  
  }
  border: ${(p) => p.propBorder}
  padding: ${(p) => p.propPadding}
  min-height: ${(p) => p.propMinHeight}
`;

const Card = ({
  propBorder,
  propPadding,
  propMinHeight,
  propMinWidth,
  propWidth,
  propWidth1,
  propWidth2,
  propWidth3,
}) => {
  return (
    <CardRoot
      propBorder={propBorder}
      propPadding={propPadding}
      propMinHeight={propMinHeight}
    >
      <Links propMinWidth={propMinWidth}>
        <Column propWidth={propWidth}>
          <LogoIcon alt="" src="/logo.svg" />
        </Column>
        <Column1 propWidth1={propWidth1}>
          <Heading>Column One</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link One</Link>
            </Link1>
            <Link1>
              <Link>Link Two</Link>
            </Link1>
            <Link1>
              <Link>Link Three</Link>
            </Link1>
            <Link1>
              <Link>Link Four</Link>
            </Link1>
            <Link1>
              <Link>Link Five</Link>
            </Link1>
          </FooterLinks>
        </Column1>
        <Column2 propWidth2={propWidth2}>
          <Heading>Column Two</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Six</Link>
            </Link1>
            <Link1>
              <Link>Link Seven</Link>
            </Link1>
            <Link1>
              <Link>Link Eight</Link>
            </Link1>
            <Link1>
              <Link>Link Nine</Link>
            </Link1>
            <Link1>
              <Link>Link Ten</Link>
            </Link1>
          </FooterLinks>
        </Column2>
        <Column3 propWidth3={propWidth3}>
          <Heading>Column Three</Heading>
          <FooterLinks>
            <Link1>
              <Link>Link Eleven</Link>
            </Link1>
            <Link1>
              <Link>Link Twelve</Link>
            </Link1>
            <Link1>
              <Link>Link Thirteen</Link>
            </Link1>
            <Link1>
              <Link>Link Fourteen</Link>
            </Link1>
            <Link1>
              <Link>Link Fifteen</Link>
            </Link1>
          </FooterLinks>
        </Column3>
      </Links>
      <Newslatter>
        <HeadingTextContent>
          <Heading>Subscribe</Heading>
          <SocialIconsFrame>
            Join our newsletter to stay up to date on features and releases.
          </SocialIconsFrame>
        </HeadingTextContent>
        <Actions>
          <Form>
            <TextInput>
              <Placeholder placeholder="Enter your email" type="text" />
            </TextInput>
            <Button1>
              <Button>Subscribe</Button>
            </Button1>
          </Form>
          <SocialIconsFrame>
            {`By subscribing you agree to with our `}
            <PrivacyPolicy>Privacy Policy</PrivacyPolicy> and provide consent to
            receive updates from our company.
          </SocialIconsFrame>
        </Actions>
      </Newslatter>
    </CardRoot>
  );
};

export default Card;
