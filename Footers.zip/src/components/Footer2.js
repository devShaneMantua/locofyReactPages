import Card from "./Card";
import styled from "styled-components";

const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Contentframe = styled.div`
  position: relative;
  line-height: 150%;
`;
const Link = styled.div`
  position: relative;
  text-decoration: underline;
  line-height: 150%;
`;
const Link1 = styled.div`
  flex: 1;
  position: relative;
  text-decoration: underline;
  line-height: 150%;
  display: inline-block;
  min-width: 68px;
`;
const FooterLinks = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 224px;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Credits = styled.div`
  width: 589px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
const IconFacebook = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const SocialLinks = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 1125px) {
    flex-wrap: wrap;
  }
`;
const Credits1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 800px) {
    gap: var(--gap-base);
  }
`;
const FooterRoot = styled.section`
  width: 1440px;
  background-color: var(--white);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-61xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-link-size);
  color: var(--black);
  font-family: var(--text-small-link);
  @media screen and (max-width: 800px) {
    gap: var(--gap-21xl);
    padding: var(--padding-33xl) var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-xl);
  }
`;

const Footer2 = () => {
  return (
    <FooterRoot>
      <Card
        propBorder="unset"
        propPadding="unset"
        propMinHeight="248px"
        propMinWidth="479px"
        propWidth="141px"
        propWidth1="141px"
        propWidth2="141px"
        propWidth3="141px"
      />
      <Credits1>
        <Divider />
        <Row>
          <Credits>
            <Contentframe>© 2023 Relume. All rights reserved.</Contentframe>
            <FooterLinks>
              <Link>Privacy Policy</Link>
              <Link1>Terms of Service</Link1>
              <Link1>Cookies Settings</Link1>
            </FooterLinks>
          </Credits>
          <SocialLinks>
            <IconFacebook alt="" src="/icon--facebook.svg" />
            <IconFacebook alt="" src="/icon--instagram.svg" />
            <IconFacebook alt="" src="/icon--twitter.svg" />
            <IconFacebook alt="" src="/icon--linkedin.svg" />
          </SocialLinks>
        </Row>
      </Credits1>
    </FooterRoot>
  );
};

export default Footer2;
