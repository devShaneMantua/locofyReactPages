import Footer10 from "../components/Footer10";
import Footer9 from "../components/Footer9";
import Footer8 from "../components/Footer8";
import Footer7 from "../components/Footer7";
import Footer6 from "../components/Footer6";
import Footer5 from "../components/Footer5";
import Footer4 from "../components/Footer4";
import Footer3 from "../components/Footer3";
import Footer2 from "../components/Footer2";
import Footer1 from "../components/Footer1";
import Footer from "../components/Footer";
import styled from "styled-components";

const FootersRoot = styled.div`
  width: 100%;
  position: relative;
  background-color: #404040;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: 100px;
  min-height: 6751px;
  letter-spacing: normal;
  @media screen and (max-width: 800px) {
    gap: 50px;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-6xl);
  }
`;

const Footers = () => {
  return (
    <FootersRoot>
      <Footer10 />
      <Footer9 />
      <Footer8 />
      <Footer7 />
      <Footer6 />
      <Footer5 />
      <Footer4 />
      <Footer3 />
      <Footer2 />
      <Footer1 />
      <Footer />
    </FootersRoot>
  );
};

export default Footers;
