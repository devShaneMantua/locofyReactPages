import styled from "styled-components";

const Heading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 24px;
  }
  align-self: ${(p) => p.headingTextAlignSelf};
`;
const HeadingText = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  min-width: 689px;
  max-width: 100%;
  @media screen and (max-width: 1100px) {
    min-width: 100%;
  }
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-lgi);
  background-color: transparent;
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Button2 = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--white);
  text-align: left;
`;
const Button3 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-lgi);
  background-color: var(--black);
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Actions = styled.div`
  width: 192px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const TableHeaderRoot = styled.section`width: 1312px;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-5xl) var(--padding-6xl) var(--padding-5xl) var(--padding-4xl);
  gap: var(--gap-xs);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-large-semi-bold-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  width: ${(p) => p.contentWidth}
  align-self: ${(p) => p.contentAlignSelf}
`;

const TableHeader1 = ({
  contentWidth,
  contentAlignSelf,
  headingTextAlignSelf,
}) => {
  return (
    <TableHeaderRoot
      contentWidth={contentWidth}
      contentAlignSelf={contentAlignSelf}
    >
      <Content>
        <Heading headingTextAlignSelf={headingTextAlignSelf}>
          Table Header
        </Heading>
        <HeadingText>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        </HeadingText>
      </Content>
      <Actions>
        <Button1>
          <Button>Button</Button>
        </Button1>
        <Button3>
          <Button2>Button</Button2>
        </Button3>
      </Actions>
    </TableHeaderRoot>
  );
};

export default TableHeader1;
