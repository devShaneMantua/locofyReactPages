import styled from "styled-components";

const Name1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const TableHeader = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl);
`;
const FullName = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const TableCell = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
`;
const TableColumn = styled.div`width: 397px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  width: ${(p) => p.tableCellWidth}
  flex: ${(p) => p.tableCellFlex}
  min-width: ${(p) => p.tableCellMinWidth}
`;
const Company = styled.input`
  width: 68px;
  border: none;
  outline: none;
  font-weight: 600;
  font-family: var(--text-regular-normal);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  position: relative;
  line-height: 150%;
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const CompanyName = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const TableColumn1 = styled.div`
  width: 256px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Number1 = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
`;
const TableHeader1 = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-base) var(--padding-27xl) var(--padding-base)
    var(--padding-5xl);
  background-color: transparent;
  border-bottom: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  &:hover {
    background-color: var(--color-darkslategray-200);
  }
`;
const TableColumn2 = styled.div`
  width: 128px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Ico24ArrowsArrowDown = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  min-height: 24px;
`;
const TableColumn3 = styled.div`
  width: 192px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const TableHeader2 = styled.input`
  border: none;
  outline: none;
  background-color: transparent;
  align-self: stretch;
  height: 56px;
  border-bottom: 1px solid var(--black);
  box-sizing: border-box;
  overflow: hidden;
  flex-shrink: 0;
  min-width: 50px;
`;
const TableCell1 = styled.div`
  border-bottom: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
`;
const TableColumn4 = styled.div`
  width: 83px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const TableContainerRoot = styled.div`width: 1312px;
  border-right: 1px solid var(--black);
  border-left: 1px solid var(--black);
  box-sizing: border-box;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  width: ${(p) => p.fullNameWidth}
  overflow-x: ${(p) => p.fullNameOverflowX}
  align-self: ${(p) => p.fullNameAlignSelf}
  overflow: ${(p) => p.fullNameOverflow}
  flex-wrap: ${(p) => p.fullNameFlexWrap}
  row-gap: ${(p) => p.fullNameRowGap}
`;

const TableContainer = ({
  fullNameWidth,
  fullNameOverflowX,
  fullNameAlignSelf,
  fullNameOverflow,
  fullNameFlexWrap,
  fullNameRowGap,
  tableCellWidth,
  tableCellFlex,
  tableCellMinWidth,
}) => {
  return (
    <TableContainerRoot
      fullNameWidth={fullNameWidth}
      fullNameOverflowX={fullNameOverflowX}
      fullNameAlignSelf={fullNameAlignSelf}
      fullNameOverflow={fullNameOverflow}
      fullNameFlexWrap={fullNameFlexWrap}
      fullNameRowGap={fullNameRowGap}
    >
      <TableColumn
        tableCellWidth={tableCellWidth}
        tableCellFlex={tableCellFlex}
        tableCellMinWidth={tableCellMinWidth}
      >
        <TableHeader>
          <Name1>Name</Name1>
        </TableHeader>
        <TableCell>
          <FullName>Full name</FullName>
        </TableCell>
        <TableCell>
          <FullName>Full name</FullName>
        </TableCell>
        <TableCell>
          <FullName>Full name</FullName>
        </TableCell>
        <TableCell>
          <FullName>Full name</FullName>
        </TableCell>
        <TableCell>
          <FullName>Full name</FullName>
        </TableCell>
        <TableCell>
          <FullName>Full name</FullName>
        </TableCell>
      </TableColumn>
      <TableColumn1>
        <TableHeader>
          <Company placeholder="Company" type="text" />
        </TableHeader>
        <TableCell>
          <CompanyName>Company name</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Company name</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Company name</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Company name</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Company name</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Company name</CompanyName>
        </TableCell>
      </TableColumn1>
      <TableColumn2>
        <TableHeader1>
          <Number1>Number</Number1>
        </TableHeader1>
        <TableCell>
          <CompanyName>14</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>14</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>14</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>14</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>14</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>14</CompanyName>
        </TableCell>
      </TableColumn2>
      <TableColumn1>
        <TableHeader>
          <Name1>Team</Name1>
        </TableHeader>
        <TableCell>
          <CompanyName>Team name</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Team name</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Team name</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Team name</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Team name</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Team name</CompanyName>
        </TableCell>
      </TableColumn1>
      <TableColumn3>
        <TableHeader>
          <Name1>Date</Name1>
          <Ico24ArrowsArrowDown
            alt=""
            src="/ico--24--arrows--arrow-downward.svg"
          />
        </TableHeader>
        <TableCell>
          <CompanyName>Jan 11, 2050</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Jan 11, 2050</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Jan 11, 2050</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Jan 11, 2050</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Jan 11, 2050</CompanyName>
        </TableCell>
        <TableCell>
          <CompanyName>Jan 11, 2050</CompanyName>
        </TableCell>
      </TableColumn3>
      <TableColumn4>
        <TableHeader2 type="text" />
        <TableCell1>
          <Name1>View</Name1>
        </TableCell1>
        <TableCell1>
          <Name1>View</Name1>
        </TableCell1>
        <TableCell1>
          <Name1>View</Name1>
        </TableCell1>
        <TableCell1>
          <Name1>View</Name1>
        </TableCell1>
        <TableCell1>
          <Name1>View</Name1>
        </TableCell1>
        <TableCell1>
          <Name1>View</Name1>
        </TableCell1>
      </TableColumn4>
    </TableContainerRoot>
  );
};

export default TableContainer;
