import styled from "styled-components";

const ImageIcon = styled.img`
  height: 48px;
  width: 48px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
  min-height: 48px;
`;
const FullName = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const Namerelumeio = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-small-normal-size);
  line-height: 150%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const Text1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 271px;
  max-width: 100%;
`;
const TableCellRoot = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl);
  gap: var(--gap-xs);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const TableCell1 = () => {
  return (
    <TableCellRoot>
      <ImageIcon loading="eager" alt="" src="/image@2x.png" />
      <Text1>
        <FullName>Full name</FullName>
        <Namerelumeio>name@relume.io</Namerelumeio>
      </Text1>
    </TableCellRoot>
  );
};

export default TableCell1;
