import styled from "styled-components";

const Date1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Ico24ArrowsArrowDown = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  min-height: 24px;
`;
const TableHeader = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl);
`;
const Jan = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const TableCell = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
`;
const PlaceholderImage = styled.img`
  width: 403.6px;
  height: 227px;
  position: absolute;
  margin: 0 !important;
  top: 28px;
  left: -238.4px;
  object-fit: cover;
`;
const TableCell1 = styled.div`
  align-self: stretch;
  height: 283px;
  background-color: var(--light-grey);
  border-bottom: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
  position: relative;
`;
const TableCell2 = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
`;
const TableColumnRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 257px;
  max-width: 262px;
  z-index: 1;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const TableColumn = () => {
  return (
    <TableColumnRoot>
      <TableHeader>
        <Date1>Date</Date1>
        <Ico24ArrowsArrowDown
          alt=""
          src="/ico--24--arrows--arrow-downward.svg"
        />
      </TableHeader>
      <TableCell>
        <Jan>Jan 11, 2050</Jan>
      </TableCell>
      <TableCell1>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image@2x.png"
        />
      </TableCell1>
      <TableCell2>
        <Jan>Jan 11, 2050</Jan>
      </TableCell2>
      <TableCell2>
        <Jan>Jan 11, 2050</Jan>
      </TableCell2>
      <TableCell2>
        <Jan>Jan 11, 2050</Jan>
      </TableCell2>
      <TableCell2>
        <Jan>Jan 11, 2050</Jan>
      </TableCell2>
      <TableCell2>
        <Jan>Jan 11, 2050</Jan>
      </TableCell2>
    </TableColumnRoot>
  );
};

export default TableColumn;
