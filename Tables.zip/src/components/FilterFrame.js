import styled from "styled-components";
import TableContainer from "./TableContainer";

const SearchIcon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Search = styled.input`
  width: calc(100% - 50px);
  border: none;
  outline: none;
  font-family: var(--text-regular-normal);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  flex: 1;
  position: relative;
  line-height: 150%;
  color: var(--color-dimgray);
  text-align: left;
  display: inline-block;
  min-width: 144px;
`;
const Input = styled.div`
  height: 42px;
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-5xs) var(--padding-sm) var(--padding-5xs)
    var(--padding-xs);
  gap: var(--gap-5xs);
`;
const IconFilters = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
  white-space: nowrap;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-lgi);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-xs);
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Actions = styled.div`
  height: 40px;
  width: 429px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
  @media screen and (max-width: 1275px) {
    display: none;
  }
`;
const TableColumnFrame = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
  white-space: nowrap;
  @media screen and (max-width: 1100px) {
    display: none;
  }
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
`;
const FiltersButtonFrame = styled.img`
  height: 10.5px;
  width: 10.5px;
  position: relative;
`;
const Clear = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-9xs);
  box-sizing: border-box;
  width: 18.5px;
  height: 18.5px;
`;
const Tag = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-5xs) var(--padding-xs) var(--padding-5xs)
    var(--padding-base);
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Tags = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  @media screen and (max-width: 450px) {
    display: none;
  }
`;
const Row1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
`;
const TableFilters = styled.div`
  align-self: stretch;
  border-right: 1px solid var(--black);
  border-bottom: 1px solid var(--black);
  border-left: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-5xl) var(--padding-4xl);
  gap: var(--gap-xs);
  top: 0;
  z-index: 99;
  position: sticky;
  max-width: 100%;
`;
const FilterFrameRoot = styled.section`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-height: 708px;
  max-width: 100%;
  text-align: right;
  font-size: var(--text-small-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const FilterFrame = () => {
  return (
    <FilterFrameRoot>
      <TableFilters>
        <Row>
          <Actions>
            <Input>
              <SearchIcon alt="" src="/search.svg" />
              <Search placeholder="Search" type="text" />
            </Input>
            <Button1>
              <IconFilters alt="" src="/icon--filters.svg" />
              <Button>Filters</Button>
            </Button1>
          </Actions>
          <TableColumnFrame>Showing 1-50 of 500</TableColumnFrame>
        </Row>
        <Row1>
          <Tags>
            <Tag>
              <Button>Tag</Button>
              <Clear>
                <FiltersButtonFrame alt="" src="/filters-button-frame.svg" />
              </Clear>
            </Tag>
            <Tag>
              <Button>Tag</Button>
              <Clear>
                <FiltersButtonFrame alt="" src="/filters-button-frame.svg" />
              </Clear>
            </Tag>
            <Tag>
              <Button>Tag</Button>
              <Clear>
                <FiltersButtonFrame alt="" src="/filters-button-frame.svg" />
              </Clear>
            </Tag>
          </Tags>
        </Row1>
      </TableFilters>
      <TableContainer
        fullNameWidth="unset"
        fullNameOverflowX="unset"
        fullNameAlignSelf="stretch"
        fullNameOverflow="hidden"
        fullNameFlexWrap="wrap"
        fullNameRowGap="20px"
        tableCellWidth="unset"
        tableCellFlex="1"
        tableCellMinWidth="258px"
      />
    </FilterFrameRoot>
  );
};

export default FilterFrame;
