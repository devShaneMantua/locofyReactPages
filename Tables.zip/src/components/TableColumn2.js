import styled from "styled-components";

const Company = styled.input`
  width: 68px;
  border: none;
  outline: none;
  font-weight: 600;
  font-family: var(--text-regular-normal);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  position: relative;
  line-height: 150%;
  color: var(--black);
  text-align: left;
  display: inline-block;
  width: ${(p) => p.propWidth};
`;
const TableHeader = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl);
`;
const CompanyName = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const TableCell = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
`;
const JobTitle = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const WebDeveloper = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Div = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-decoration: ${(p) => p.propTextDecoration};
`;
const TableCell1 = styled.div`
  align-self: stretch;
  background-color: var(--light-grey);
  border-bottom: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
  gap: var(--gap-21xl);
  font-size: var(--text-small-normal-size);
  @media screen and (max-width: 450px) {
    gap: var(--gap-21xl);
  }
`;
const TableCell2 = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
`;
const TableColumnRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 257px;
  max-width: 262px;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const TableColumn2 = ({
  companyPlaceholder,
  companyName,
  jobTitle,
  webDeveloper,
  phone,
  prop,
  languages,
  english,
  companyName1,
  companyName2,
  companyName3,
  companyName4,
  companyName5,
  propWidth,
  propTextDecoration,
}) => {
  return (
    <TableColumnRoot>
      <TableHeader>
        <Company
          placeholder={companyPlaceholder}
          type="text"
          propWidth={propWidth}
        />
      </TableHeader>
      <TableCell>
        <CompanyName>{companyName}</CompanyName>
      </TableCell>
      <TableCell1>
        <Content>
          <JobTitle>{jobTitle}</JobTitle>
          <WebDeveloper>{webDeveloper}</WebDeveloper>
        </Content>
        <Content>
          <JobTitle>{phone}</JobTitle>
          <Div propTextDecoration={propTextDecoration}>{prop}</Div>
        </Content>
        <Content>
          <JobTitle>{languages}</JobTitle>
          <WebDeveloper>{english}</WebDeveloper>
        </Content>
      </TableCell1>
      <TableCell2>
        <CompanyName>{companyName1}</CompanyName>
      </TableCell2>
      <TableCell2>
        <CompanyName>{companyName2}</CompanyName>
      </TableCell2>
      <TableCell2>
        <CompanyName>{companyName3}</CompanyName>
      </TableCell2>
      <TableCell2>
        <CompanyName>{companyName4}</CompanyName>
      </TableCell2>
      <TableCell2>
        <CompanyName>{companyName5}</CompanyName>
      </TableCell2>
    </TableColumnRoot>
  );
};

export default TableColumn2;
