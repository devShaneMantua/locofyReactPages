import styled from "styled-components";

const ChevronUpIcon = styled.img`
  width: 12.6px;
  height: 7.1px;
  position: relative;
  object-fit: contain;
`;
const ChevronUp = styled.div`
  height: 24px;
  width: 24px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) 0px;
  box-sizing: border-box;
`;
const FullName = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const TableCellRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-9xl) var(--padding-xl);
  gap: var(--gap-xs);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  border-bottom: ${(p) => p.propBorderBottom};
`;

const TableCell = ({ vector, propBorderBottom }) => {
  return (
    <TableCellRoot propBorderBottom={propBorderBottom}>
      <ChevronUp>
        <ChevronUpIcon loading="eager" alt="" src={vector} />
      </ChevronUp>
      <FullName>Full name</FullName>
    </TableCellRoot>
  );
};

export default TableCell;
