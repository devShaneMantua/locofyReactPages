import styled from "styled-components";

const Team = styled.input`
  width: 41px;
  border: none;
  outline: none;
  font-weight: 600;
  font-family: var(--text-regular-normal);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  position: relative;
  line-height: 150%;
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const TableHeader = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl);
`;
const TeamName = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const TableCell = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
`;
const TableCell1 = styled.div`
  align-self: stretch;
  height: 283px;
  background-color: var(--light-grey);
  border-bottom: 1px solid var(--black);
  box-sizing: border-box;
`;
const TableCell2 = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
`;
const TableColumnRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 257px;
  max-width: 262px;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const TableColumn1 = () => {
  return (
    <TableColumnRoot>
      <TableHeader>
        <Team placeholder="Team" type="text" />
      </TableHeader>
      <TableCell>
        <TeamName>Team name</TeamName>
      </TableCell>
      <TableCell1 />
      <TableCell2>
        <TeamName>Team name</TeamName>
      </TableCell2>
      <TableCell2>
        <TeamName>Team name</TeamName>
      </TableCell2>
      <TableCell2>
        <TeamName>Team name</TeamName>
      </TableCell2>
      <TableCell2>
        <TeamName>Team name</TeamName>
      </TableCell2>
      <TableCell2>
        <TeamName>Team name</TeamName>
      </TableCell2>
    </TableColumnRoot>
  );
};

export default TableColumn1;
