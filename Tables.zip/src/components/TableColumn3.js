import styled from "styled-components";
import TableCell from "./TableCell";

const Name1 = styled.input`
  width: 43px;
  border: none;
  outline: none;
  font-weight: 600;
  font-family: var(--text-regular-normal);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  position: relative;
  line-height: 150%;
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const TableHeader = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl);
`;
const DateJoined = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const CompanyCell = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const TableCell1 = styled.div`
  align-self: stretch;
  background-color: var(--light-grey);
  border-bottom: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl) var(--padding-9xl)
    var(--padding-37xl);
  gap: var(--gap-21xl);
  font-size: var(--text-small-normal-size);
  @media screen and (max-width: 450px) {
    gap: var(--gap-21xl);
    padding-left: var(--padding-xl);
    box-sizing: border-box;
  }
`;
const TableColumnRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 257px;
  max-width: 262px;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const TableColumn3 = () => {
  return (
    <TableColumnRoot>
      <TableHeader>
        <Name1 placeholder="Name" type="text" />
      </TableHeader>
      <TableCell vector="/vector.svg" />
      <TableCell1>
        <Content>
          <DateJoined>Date joined</DateJoined>
          <CompanyCell>1/11/2050</CompanyCell>
        </Content>
        <Content>
          <DateJoined>Address</DateJoined>
          <CompanyCell>123 Sample St, Sydney</CompanyCell>
        </Content>
        <Content>
          <DateJoined>Skills</DateJoined>
          <CompanyCell>Webflow, Figma</CompanyCell>
        </Content>
      </TableCell1>
      <TableCell
        vector="/vector-1.svg"
        propBorderBottom="1px solid var(--black)"
      />
      <TableCell
        vector="/vector-1.svg"
        propBorderBottom="1px solid var(--black)"
      />
      <TableCell
        vector="/vector-1.svg"
        propBorderBottom="1px solid var(--black)"
      />
      <TableCell
        vector="/vector-1.svg"
        propBorderBottom="1px solid var(--black)"
      />
      <TableCell
        vector="/vector-1.svg"
        propBorderBottom="1px solid var(--black)"
      />
    </TableColumnRoot>
  );
};

export default TableColumn3;
