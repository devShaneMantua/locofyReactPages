import styled from "styled-components";

const Company = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const TableHeader = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl);
`;
const CompanyName = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const TableCell = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
`;
const TableColumnRoot = styled.div`
  width: 192px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const TableColumn4 = ({
  company,
  companyName,
  companyName1,
  companyName2,
  companyName3,
  companyName4,
  companyName5,
}) => {
  return (
    <TableColumnRoot>
      <TableHeader>
        <Company>{company}</Company>
      </TableHeader>
      <TableCell>
        <CompanyName>{companyName}</CompanyName>
      </TableCell>
      <TableCell>
        <CompanyName>{companyName1}</CompanyName>
      </TableCell>
      <TableCell>
        <CompanyName>{companyName2}</CompanyName>
      </TableCell>
      <TableCell>
        <CompanyName>{companyName3}</CompanyName>
      </TableCell>
      <TableCell>
        <CompanyName>{companyName4}</CompanyName>
      </TableCell>
      <TableCell>
        <CompanyName>{companyName5}</CompanyName>
      </TableCell>
    </TableColumnRoot>
  );
};

export default TableColumn4;
