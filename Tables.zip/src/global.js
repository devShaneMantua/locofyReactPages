import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--text-regular-normal: Roboto;

/* font sizes */
--text-regular-normal-size: 16px;
--text-medium-normal-size: 18px;
--text-large-semi-bold-size: 20px;
--text-small-normal-size: 14px;

/* Colors */
--white: #fff;
--black: #000;
--color-darkslategray-100: #333;
--color-darkslategray-200: rgba(51, 51, 51, 0.09);
--light-grey: #f4f4f4;
--color-dimgray: #505050;

/* Gaps */
--gap-13xl: 32px;
--gap-xl: 20px;
--gap-xs: 12px;
--gap-11xs: 2px;
--gap-base: 16px;
--gap-5xs: 8px;
--gap-21xl: 40px;
--gap-9xs: 4px;

/* Paddings */
--padding-93xl: 112px;
--padding-xl: 20px;
--padding-5xs: 8px;
--padding-2xl: 21px;
--padding-lgi: 19px;
--padding-mini: 15px;
--padding-base: 16px;
--padding-sm: 14px;
--padding-9xl: 28px;
--padding-5xl: 24px;
--padding-27xl: 46px;
--padding-6xl: 25px;
--padding-4xl: 23px;
--padding-xs: 12px;
--padding-9xs: 4px;
--padding-37xl: 56px;

/* Border radiuses */
--br-5xs: 8px;

}
`;
