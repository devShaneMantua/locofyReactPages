import TableHeader from "../components/TableHeader";
import TableContainer from "../components/TableContainer";
import styled from "styled-components";

const FrameContainer = styled.section`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const IconChevronLeft = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-2xl) var(--padding-5xs)
    var(--padding-lgi);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const TableColumn = styled.div`
  position: relative;
  line-height: 150%;
`;
const Content = styled.div`
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-sm) var(--padding-5xs)
    var(--padding-mini);
`;
const Content1 = styled.div`
  border-radius: var(--br-5xs);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-mini) var(--padding-5xs)
    var(--padding-base);
`;
const PaginationNumber = styled.div`
  border-radius: var(--br-5xs);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const ContentParent = styled.div`
  width: 166px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-11xs);
`;
const PageButtons = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const TableRoot = styled.footer`
  width: 100%;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  letter-spacing: normal;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
  }
`;

const Table = () => {
  return (
    <TableRoot>
      <FrameContainer>
        <TableHeader />
        <TableContainer />
      </FrameContainer>
      <PageButtons>
        <Button1>
          <IconChevronLeft alt="" src="/icon--chevron-left.svg" />
          <Button>Prev</Button>
        </Button1>
        <ContentParent>
          <Content>
            <TableColumn>1</TableColumn>
          </Content>
          <PaginationNumber>
            <Content1>
              <TableColumn>2</TableColumn>
            </Content1>
          </PaginationNumber>
          <PaginationNumber>
            <Content1>
              <TableColumn>3</TableColumn>
            </Content1>
          </PaginationNumber>
          <PaginationNumber>
            <Content1>
              <TableColumn>4</TableColumn>
            </Content1>
          </PaginationNumber>
        </ContentParent>
        <Button1>
          <Button>Next</Button>
          <IconChevronLeft alt="" src="/icon--chevron-right.svg" />
        </Button1>
      </PageButtons>
    </TableRoot>
  );
};

export default Table;
