import TableHeader1 from "../components/TableHeader1";
import TableColumn3 from "../components/TableColumn3";
import TableColumn2 from "../components/TableColumn2";
import TableColumn1 from "../components/TableColumn1";
import TableColumn from "../components/TableColumn";
import styled from "styled-components";

const TableContainer = styled.section`
  align-self: stretch;
  border-right: 1px solid var(--black);
  border-left: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: center;
  row-gap: 20px;
`;
const TableHeaderParent = styled.main`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const IconChevronLeft = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-2xl) var(--padding-5xs)
    var(--padding-lgi);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const PaginationNumber = styled.div`
  position: relative;
  line-height: 150%;
`;
const Content = styled.div`
  flex: 1;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-sm) var(--padding-5xs)
    var(--padding-mini);
`;
const Content1 = styled.div`
  border-radius: var(--br-5xs);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-mini) var(--padding-5xs)
    var(--padding-base);
`;
const PaginationNumber1 = styled.div`
  border-radius: var(--br-5xs);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const ContentPaginationFrame = styled.div`
  width: 166px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-11xs);
`;
const PageButtons = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const TableRoot = styled.footer`
  width: 100%;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  letter-spacing: normal;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
  }
`;

const Table2 = () => {
  return (
    <TableRoot>
      <TableHeaderParent>
        <TableHeader1
          contentWidth="unset"
          contentAlignSelf="stretch"
          headingTextAlignSelf="unset"
        />
        <TableContainer>
          <TableColumn3 />
          <TableColumn2
            companyPlaceholder="Company"
            companyName="Company name"
            jobTitle="Job title"
            webDeveloper="Web developer"
            phone="Phone"
            prop="+1 (555) 000-0000"
            languages="Languages"
            english="English"
            companyName1="Company name"
            companyName2="Company name"
            companyName3="Company name"
            companyName4="Company name"
            companyName5="Company name"
          />
          <TableColumn2
            companyPlaceholder="Number"
            companyName="14"
            jobTitle="Level"
            webDeveloper="2"
            phone="Email"
            prop="hello@relume.io"
            languages="Experience"
            english="5+ years"
            companyName1="14"
            companyName2="14"
            companyName3="14"
            companyName4="14"
            companyName5="14"
            propWidth="58px"
            propTextDecoration="none"
          />
          <TableColumn1 />
          <TableColumn />
        </TableContainer>
      </TableHeaderParent>
      <PageButtons>
        <Button1>
          <IconChevronLeft alt="" src="/icon--chevron-left.svg" />
          <Button>Prev</Button>
        </Button1>
        <ContentPaginationFrame>
          <Content>
            <PaginationNumber>1</PaginationNumber>
          </Content>
          <PaginationNumber1>
            <Content1>
              <PaginationNumber>2</PaginationNumber>
            </Content1>
          </PaginationNumber1>
          <PaginationNumber1>
            <Content1>
              <PaginationNumber>3</PaginationNumber>
            </Content1>
          </PaginationNumber1>
          <PaginationNumber1>
            <Content1>
              <PaginationNumber>4</PaginationNumber>
            </Content1>
          </PaginationNumber1>
        </ContentPaginationFrame>
        <Button1>
          <Button>Next</Button>
          <IconChevronLeft alt="" src="/icon--chevron-right.svg" />
        </Button1>
      </PageButtons>
    </TableRoot>
  );
};

export default Table2;
