import TableHeader from "../components/TableHeader";
import styled from "styled-components";
import TableCell1 from "../components/TableCell1";
import TableColumn4 from "../components/TableColumn4";

const Name1 = styled.input`
  width: 43px;
  border: none;
  outline: none;
  font-weight: 600;
  font-family: var(--text-regular-normal);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  position: relative;
  line-height: 150%;
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const TableHeader1 = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-5xl);
`;
const TableColumn = styled.div`
  width: 525px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Products = styled.input`
  width: 65px;
  border: none;
  outline: none;
  font-weight: 600;
  font-family: var(--text-regular-normal);
  font-size: var(--text-regular-normal-size);
  background-color: transparent;
  height: 24px;
  position: relative;
  line-height: 150%;
  color: var(--black);
  text-align: left;
  display: inline-block;
`;
const ImageIcon = styled.img`
  height: 32px;
  width: 32px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
  min-height: 32px;
`;
const ImageIcon1 = styled.img`
  height: 32px;
  width: 32px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
  min-height: 32px;
  z-index: 1;
  margin-left: -8px;
`;
const ImageIcon2 = styled.img`
  height: 32px;
  width: 32px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
  min-height: 32px;
  z-index: 2;
  margin-left: -8px;
`;
const TableCell = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-5xl);
`;
const TableColumn1 = styled.div`
  width: 192px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Date1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Ico24ArrowsArrowDown = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  min-height: 24px;
`;
const TableHeader2 = styled.div`
  border-bottom: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) 47px var(--padding-base) var(--padding-5xl);
`;
const Div = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;
const TableCell2 = styled.div`
  align-self: stretch;
  border-bottom: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
`;
const TableColumn2 = styled.div`
  width: 128px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const TableHeader3 = styled.input`
  border: none;
  outline: none;
  background-color: transparent;
  align-self: stretch;
  height: 56px;
  border-bottom: 1px solid var(--black);
  box-sizing: border-box;
  overflow: hidden;
  flex-shrink: 0;
  min-width: 50px;
`;
const TableCell3 = styled.div`
  border-bottom: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-9xl) var(--padding-5xl);
`;
const TableColumn3 = styled.div`
  width: 83px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const TableContainer = styled.div`
  width: 1312px;
  border-right: 1px solid var(--black);
  border-left: 1px solid var(--black);
  box-sizing: border-box;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const TableHeaderParent = styled.section`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;
const IconChevronLeft = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-2xl) var(--padding-5xs)
    var(--padding-lgi);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Div1 = styled.div`
  position: relative;
  line-height: 150%;
`;
const Content = styled.div`
  flex: 0.55;
  border: 1px solid var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs);
`;
const Content1 = styled.div`
  flex: 1;
  border-radius: var(--br-5xs);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs);
`;
const PaginationNumber = styled.div`
  flex: 1;
  border-radius: var(--br-5xs);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const ContentParent = styled.div`
  width: 166px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-11xs);
`;
const PageButtons = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  max-width: 100%;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const TableRoot = styled.footer`
  width: 100%;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-13xl);
  letter-spacing: normal;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
  }
`;

const Table3 = () => {
  return (
    <TableRoot>
      <TableHeaderParent>
        <TableHeader headingAlignSelf="unset" />
        <TableContainer>
          <TableColumn>
            <TableHeader1>
              <Name1 placeholder="Name" type="text" />
            </TableHeader1>
            <TableCell1 />
            <TableCell1 />
            <TableCell1 />
            <TableCell1 />
            <TableCell1 />
            <TableCell1 />
          </TableColumn>
          <TableColumn4
            company="Company"
            companyName="Company name"
            companyName1="Company name"
            companyName2="Company name"
            companyName3="Company name"
            companyName4="Company name"
            companyName5="Company name"
          />
          <TableColumn1>
            <TableHeader1>
              <Products placeholder="Products" type="text" />
            </TableHeader1>
            <TableCell>
              <ImageIcon alt="" src="/image-6@2x.png" />
              <ImageIcon1 alt="" src="/image-6@2x.png" />
              <ImageIcon2 loading="eager" alt="" src="/image-6@2x.png" />
            </TableCell>
            <TableCell>
              <ImageIcon alt="" src="/image-6@2x.png" />
              <ImageIcon1 alt="" src="/image-6@2x.png" />
              <ImageIcon2 loading="eager" alt="" src="/image-6@2x.png" />
            </TableCell>
            <TableCell>
              <ImageIcon alt="" src="/image-6@2x.png" />
              <ImageIcon1 alt="" src="/image-6@2x.png" />
              <ImageIcon2 loading="eager" alt="" src="/image-6@2x.png" />
            </TableCell>
            <TableCell>
              <ImageIcon alt="" src="/image-6@2x.png" />
              <ImageIcon1 alt="" src="/image-6@2x.png" />
              <ImageIcon2 loading="eager" alt="" src="/image-6@2x.png" />
            </TableCell>
            <TableCell>
              <ImageIcon alt="" src="/image-6@2x.png" />
              <ImageIcon1 alt="" src="/image-6@2x.png" />
              <ImageIcon2 loading="eager" alt="" src="/image-6@2x.png" />
            </TableCell>
            <TableCell>
              <ImageIcon alt="" src="/image-6@2x.png" />
              <ImageIcon1 alt="" src="/image-6@2x.png" />
              <ImageIcon2 loading="eager" alt="" src="/image-6@2x.png" />
            </TableCell>
          </TableColumn1>
          <TableColumn4
            company="Team"
            companyName="Team name"
            companyName1="Team name"
            companyName2="Team name"
            companyName3="Team name"
            companyName4="Team name"
            companyName5="Team name"
          />
          <TableColumn2>
            <TableHeader2>
              <Date1>Date</Date1>
              <Ico24ArrowsArrowDown
                alt=""
                src="/ico--24--arrows--arrow-downward.svg"
              />
            </TableHeader2>
            <TableCell2>
              <Div>1/11/2050</Div>
            </TableCell2>
            <TableCell2>
              <Div>1/11/2050</Div>
            </TableCell2>
            <TableCell2>
              <Div>1/11/2050</Div>
            </TableCell2>
            <TableCell2>
              <Div>1/11/2050</Div>
            </TableCell2>
            <TableCell2>
              <Div>1/11/2050</Div>
            </TableCell2>
            <TableCell2>
              <Div>1/11/2050</Div>
            </TableCell2>
          </TableColumn2>
          <TableColumn3>
            <TableHeader3 type="text" />
            <TableCell3>
              <Date1>View</Date1>
            </TableCell3>
            <TableCell3>
              <Date1>View</Date1>
            </TableCell3>
            <TableCell3>
              <Date1>View</Date1>
            </TableCell3>
            <TableCell3>
              <Date1>View</Date1>
            </TableCell3>
            <TableCell3>
              <Date1>View</Date1>
            </TableCell3>
            <TableCell3>
              <Date1>View</Date1>
            </TableCell3>
          </TableColumn3>
        </TableContainer>
      </TableHeaderParent>
      <PageButtons>
        <Button1>
          <IconChevronLeft alt="" src="/icon--chevron-left.svg" />
          <Button>Prev</Button>
        </Button1>
        <ContentParent>
          <Content>
            <Div1>1</Div1>
          </Content>
          <PaginationNumber>
            <Content1>
              <Div1>2</Div1>
            </Content1>
          </PaginationNumber>
          <PaginationNumber>
            <Content1>
              <Div1>3</Div1>
            </Content1>
          </PaginationNumber>
          <PaginationNumber>
            <Content1>
              <Div1>4</Div1>
            </Content1>
          </PaginationNumber>
        </ContentParent>
        <Button1>
          <Button>Next</Button>
          <IconChevronLeft alt="" src="/icon--chevron-right.svg" />
        </Button1>
      </PageButtons>
    </TableRoot>
  );
};

export default Table3;
