import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Blog from "./pages/Blog";
import Blog7 from "./pages/Blog7";
import Blog2 from "./pages/Blog2";
import Blog3 from "./pages/Blog3";
import Blog4 from "./pages/Blog4";
import Blog6 from "./pages/Blog6";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/blog-2":
        title = "";
        metaDescription = "";
        break;
      case "/blog-3":
        title = "";
        metaDescription = "";
        break;
      case "/blog-4":
        title = "";
        metaDescription = "";
        break;
      case "/blog-5":
        title = "";
        metaDescription = "";
        break;
      case "/blog-6":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<Blog />} />
      <Route path="/blog-2" element={<Blog7 />} />
      <Route path="/blog-3" element={<Blog2 />} />
      <Route path="/blog-4" element={<Blog3 />} />
      <Route path="/blog-5" element={<Blog4 />} />
      <Route path="/blog-6" element={<Blog6 />} />
    </Routes>
  );
}
export default App;
