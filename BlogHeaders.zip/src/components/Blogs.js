import styled from "styled-components";

const Heading = styled.h2`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 300px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading1 = styled.h2`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h5-size);
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const CategoryLabelSet = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const PlaceholderImage1 = styled.img`
  height: 48px;
  width: 48px;
  position: relative;
  object-fit: cover;
  min-height: 48px;
`;
const Jan = styled.div`
  position: relative;
  line-height: 150%;
`;
const Div = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 7px;
  }
`;
const Time = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 229px;
  max-width: 100%;
`;
const Avatar = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const Card = styled.div`
  width: 416px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  box-sizing: border-box;
  gap: var(--gap-5xl);
`;
const Content2 = styled.div`
  width: 1312px;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: 64px 32px;
  min-height: 1094px;
  max-width: 100%;
  font-size: var(--text-small-normal-size);
  @media screen and (max-width: 750px) {
    gap: 64px 32px;
  }
`;
const BlogsRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-normal);
  @media screen and (max-width: 750px) {
    gap: var(--gap-21xl);
  }
`;

const Blogs = () => {
  return (
    <BlogsRoot>
      <Heading>Featured blog posts</Heading>
      <Content2>
        <Card>
          <PlaceholderImage alt="" src="/placeholder--image-8@2x.png" />
          <Content>
            <Text1>Category</Text1>
            <Heading1>Blog title heading will go here</Heading1>
            <CategoryLabelSet>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </CategoryLabelSet>
          </Content>
          <Avatar>
            <PlaceholderImage1 alt="" src="/placeholder--image-1@2x.png" />
            <Content1>
              <Text1>Full name</Text1>
              <Time>
                <Jan>11 Jan 2022</Jan>
                <Div>•</Div>
                <Jan>5 min read</Jan>
              </Time>
            </Content1>
          </Avatar>
        </Card>
        <Card>
          <PlaceholderImage alt="" src="/placeholder--image-8@2x.png" />
          <Content>
            <Text1>Category</Text1>
            <Heading1>Blog title heading will go here</Heading1>
            <CategoryLabelSet>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </CategoryLabelSet>
          </Content>
          <Avatar>
            <PlaceholderImage1 alt="" src="/placeholder--image-1@2x.png" />
            <Content1>
              <Text1>Full name</Text1>
              <Time>
                <Jan>11 Jan 2022</Jan>
                <Div>•</Div>
                <Jan>5 min read</Jan>
              </Time>
            </Content1>
          </Avatar>
        </Card>
        <Card>
          <PlaceholderImage alt="" src="/placeholder--image-8@2x.png" />
          <Content>
            <Text1>Category</Text1>
            <Heading1>Blog title heading will go here</Heading1>
            <CategoryLabelSet>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </CategoryLabelSet>
          </Content>
          <Avatar>
            <PlaceholderImage1 alt="" src="/placeholder--image-1@2x.png" />
            <Content1>
              <Text1>Full name</Text1>
              <Time>
                <Jan>11 Jan 2022</Jan>
                <Div>•</Div>
                <Jan>5 min read</Jan>
              </Time>
            </Content1>
          </Avatar>
        </Card>
        <Card>
          <PlaceholderImage alt="" src="/placeholder--image-8@2x.png" />
          <Content>
            <Text1>Category</Text1>
            <Heading1>Blog title heading will go here</Heading1>
            <CategoryLabelSet>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </CategoryLabelSet>
          </Content>
          <Avatar>
            <PlaceholderImage1 alt="" src="/placeholder--image-1@2x.png" />
            <Content1>
              <Text1>Full name</Text1>
              <Time>
                <Jan>11 Jan 2022</Jan>
                <Div>•</Div>
                <Jan>5 min read</Jan>
              </Time>
            </Content1>
          </Avatar>
        </Card>
        <Card>
          <PlaceholderImage alt="" src="/placeholder--image-8@2x.png" />
          <Content>
            <Text1>Category</Text1>
            <Heading1>Blog title heading will go here</Heading1>
            <CategoryLabelSet>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </CategoryLabelSet>
          </Content>
          <Avatar>
            <PlaceholderImage1 alt="" src="/placeholder--image-1@2x.png" />
            <Content1>
              <Text1>Full name</Text1>
              <Time>
                <Jan>11 Jan 2022</Jan>
                <Div>•</Div>
                <Jan>5 min read</Jan>
              </Time>
            </Content1>
          </Avatar>
        </Card>
        <Card>
          <PlaceholderImage alt="" src="/placeholder--image-8@2x.png" />
          <Content>
            <Text1>Category</Text1>
            <Heading1>Blog title heading will go here</Heading1>
            <CategoryLabelSet>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </CategoryLabelSet>
          </Content>
          <Avatar>
            <PlaceholderImage1 alt="" src="/placeholder--image-1@2x.png" />
            <Content1>
              <Text1>Full name</Text1>
              <Time>
                <Jan>11 Jan 2022</Jan>
                <Div>•</Div>
                <Jan>5 min read</Jan>
              </Time>
            </Content1>
          </Avatar>
        </Card>
      </Content2>
    </BlogsRoot>
  );
};

export default Blogs;
