import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 250px;
  width: 250px;
  position: relative;
  object-fit: cover;
  @media screen and (max-width: 825px) {
    flex: 1;
  }
`;
const Text1 = styled.div`
  position: relative;
  font-size: var(--text-small-normal-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-small-normal);
  color: var(--black);
  text-align: left;
`;
const TextWrapper = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-5xs);
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  &:hover {
    background-color: var(--color-gainsboro);
  }
`;
const Text2 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Info = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const SubheadingText = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h5-size);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  box-sizing: border-box;
  gap: var(--gap-5xl);
  min-width: 238px;
  max-width: 100%;
`;
const Card = styled.div`
  width: 640px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  @media screen and (max-width: 825px) {
    flex-wrap: wrap;
  }
`;
const RowRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
  @media screen and (max-width: 1400px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 825px) {
    gap: var(--gap-29xl);
  }
`;

const Row = () => {
  return (
    <RowRoot>
      <Card>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-2@2x.png"
        />
        <Content1>
          <Content>
            <Info>
              <TextWrapper>
                <Text1>Category</Text1>
              </TextWrapper>
              <Text2>5 min read</Text2>
            </Info>
            <Title>
              <Heading>Blog title heading will go here</Heading>
              <SubheadingText>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim...
              </SubheadingText>
            </Title>
          </Content>
          <Button1>
            <Button>Read more</Button>
            <IconChevronRight
              loading="eager"
              alt=""
              src="/icon--chevron-right.svg"
            />
          </Button1>
        </Content1>
      </Card>
      <Card>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image-2@2x.png"
        />
        <Content1>
          <Content>
            <Info>
              <TextWrapper>
                <Text1>Category</Text1>
              </TextWrapper>
              <Text2>5 min read</Text2>
            </Info>
            <Title>
              <Heading>Blog title heading will go here</Heading>
              <SubheadingText>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim...
              </SubheadingText>
            </Title>
          </Content>
          <Button1>
            <Button>Read more</Button>
            <IconChevronRight
              loading="eager"
              alt=""
              src="/icon--chevron-right.svg"
            />
          </Button1>
        </Content1>
      </Card>
    </RowRoot>
  );
};

export default Row;
