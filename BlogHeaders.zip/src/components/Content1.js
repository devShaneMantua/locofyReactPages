import styled from "styled-components";
import Card3 from "./Card3";
import Card1 from "./Card1";

const ViewAll = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-normal);
  color: var(--black);
  text-align: left;
`;
const Button = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-smi);
  background-color: transparent;
  width: 88px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const TextOne = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-sm);
  box-sizing: border-box;
  min-width: 84px;
`;
const Button2 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-sm);
  box-sizing: border-box;
  min-width: 89px;
`;
const Categories = styled.div`
  width: 608px;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  row-gap: 20px;
  max-width: 100%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: 64px 32px;
  min-height: 1126px;
  max-width: 100%;
  font-size: var(--text-small-normal-size);
  @media screen and (max-width: 750px) {
    gap: 64px 32px;
  }
`;
const ContentRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
  @media screen and (max-width: 750px) {
    gap: var(--gap-45xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;

const Content1 = () => {
  return (
    <ContentRoot>
      <Categories>
        <Button>
          <ViewAll>View all</ViewAll>
        </Button>
        <Button1>
          <TextOne>Category one</TextOne>
        </Button1>
        <Button1>
          <TextOne>Category two</TextOne>
        </Button1>
        <Button2>
          <TextOne>Category three</TextOne>
        </Button2>
        <Button1>
          <TextOne>Category four</TextOne>
        </Button1>
      </Categories>
      <Content>
        <Card3 />
        <Card3 />
        <Card3 />
        <Card1 />
        <Card1 />
        <Card1 />
      </Content>
    </ContentRoot>
  );
};

export default Content1;
