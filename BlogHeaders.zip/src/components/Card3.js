import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 300px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const NestedTextandFrames = styled.div`
  position: relative;
  font-size: var(--text-small-normal-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-small-normal);
  color: var(--black);
  text-align: left;
`;
const NestedTextandFrames1 = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-5xs);
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  &:hover {
    background-color: var(--color-gainsboro);
  }
`;
const NestedTextandFrames2 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Info = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h5-size);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xl);
  gap: var(--gap-5xl);
`;
const CardRoot = styled.div`
  width: 416px;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 168px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const Card3 = () => {
  return (
    <CardRoot>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image-8@2x.png"
      />
      <Content1>
        <Content>
          <Info>
            <NestedTextandFrames1>
              <NestedTextandFrames>Category</NestedTextandFrames>
            </NestedTextandFrames1>
            <NestedTextandFrames2>5 min read</NestedTextandFrames2>
          </Info>
          <Title>
            <Heading>Blog title heading will go here</Heading>
            <Text1>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </Text1>
          </Title>
        </Content>
        <Button1>
          <Button>Read more</Button>
          <IconChevronRight
            loading="eager"
            alt=""
            src="/icon--chevron-right.svg"
          />
        </Button1>
      </Content1>
    </CardRoot>
  );
};

export default Card3;
