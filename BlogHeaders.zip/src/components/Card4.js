import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 500px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 426px;
  min-height: 500px;
  @media screen and (max-width: 1200px) {
    flex: 1;
  }
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const TextFrame = styled.div`
  position: relative;
  font-size: var(--text-small-normal-size);
  line-height: 150%;
  font-weight: 600;
  font-family: var(--text-small-normal);
  color: var(--black);
  text-align: left;
`;
const TextFrameWrapper = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-9xs) var(--padding-5xs);
  background-color: var(--light-grey);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  &:hover {
    background-color: var(--color-gainsboro);
  }
`;
const ButtonInstance = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Info = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const BlogTitleHeading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const ButtonViewallText = styled.div`
  align-self: stretch;
  height: 48px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h4-size);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  flex: 0.8537;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: space-between;
  padding: var(--padding-29xl);
  box-sizing: border-box;
  min-width: 426px;
  min-height: 500px;
  max-width: 100%;
  @media screen and (max-width: 1200px) {
    flex: 1;
    min-height: auto;
  }
  @media screen and (max-width: 750px) {
    padding-left: var(--padding-5xl);
    padding-right: var(--padding-5xl);
    box-sizing: border-box;
    min-width: 100%;
  }
`;
const CardRoot = styled.section`
  align-self: stretch;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  row-gap: 20px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
  @media screen and (max-width: 1200px) {
    flex-wrap: wrap;
  }
`;

const Card4 = () => {
  return (
    <CardRoot>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image1@2x.png"
      />
      <Content1>
        <Content>
          <Info>
            <TextFrameWrapper>
              <TextFrame>Category</TextFrame>
            </TextFrameWrapper>
            <ButtonInstance>5 min read</ButtonInstance>
          </Info>
          <Title>
            <BlogTitleHeading>Blog title heading will go here</BlogTitleHeading>
            <ButtonViewallText>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </ButtonViewallText>
          </Title>
        </Content>
        <Button1>
          <Button>Read more</Button>
          <IconChevronRight
            loading="eager"
            alt=""
            src="/icon--chevron-right.svg"
          />
        </Button1>
      </Content1>
    </CardRoot>
  );
};

export default Card4;
