import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 250px;
  width: 250px;
  position: relative;
  object-fit: cover;
  @media screen and (max-width: 750px) {
    flex: 1;
  }
`;
const TimeText = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h2`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h5-size);
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const PlaceholderImage1 = styled.img`
  height: 48px;
  width: 48px;
  position: relative;
  object-fit: cover;
  min-height: 48px;
`;
const Subheadingcontainer = styled.div`
  position: relative;
  line-height: 150%;
`;
const Div = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Time = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 196px;
`;
const Avatar = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content2 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl) 0px;
  box-sizing: border-box;
  gap: var(--gap-5xl);
  min-width: 238px;
  max-width: 100%;
`;
const CardRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;

const Card = () => {
  return (
    <CardRoot>
      <PlaceholderImage alt="" src="/placeholder--image-2@2x.png" />
      <Content2>
        <Content>
          <TimeText>Category</TimeText>
          <Heading>Blog title heading will go here</Heading>
        </Content>
        <Avatar>
          <PlaceholderImage1 alt="" src="/placeholder--image-3@2x.png" />
          <Content1>
            <TimeText>Full name</TimeText>
            <Time>
              <Subheadingcontainer>11 Jan 2022</Subheadingcontainer>
              <Div>•</Div>
              <Subheadingcontainer>5 min read</Subheadingcontainer>
            </Time>
          </Content1>
        </Avatar>
      </Content2>
    </CardRoot>
  );
};

export default Card;
