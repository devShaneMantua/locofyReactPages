import styled from "styled-components";
import Card from "./Card";

const Heading = styled.h2`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 400px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Contentcards = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading1 = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h4-size);
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const Blogscontainer = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const PlaceholderImage1 = styled.img`
  height: 48px;
  width: 48px;
  position: relative;
  object-fit: cover;
  min-height: 48px;
`;
const TextBlockB = styled.div`
  position: relative;
  line-height: 150%;
`;
const Div = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 7px;
  }
`;
const Time = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 374px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const Avatar = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const Card = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 416px;
  min-height: 814px;
  max-width: 100%;
  @media screen and (max-width: 1200px) {
    min-height: auto;
  }
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const Blogs = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 416px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
    min-width: 100%;
  }
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  font-size: var(--text-small-normal-size);
  @media screen and (max-width: 1200px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
  }
`;
const BlogHeroRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-21xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-small-normal);
  @media screen and (max-width: 750px) {
    gap: var(--gap-21xl);
  }
`;

const BlogHero = () => {
  return (
    <BlogHeroRoot>
      <Heading>Featured blog posts</Heading>
      <Content2>
        <Card>
          <PlaceholderImage
            loading="eager"
            alt=""
            src="/placeholder--image@2x.png"
          />
          <Content>
            <Contentcards>Category</Contentcards>
            <Heading1>Blog title heading will go here</Heading1>
            <Blogscontainer>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros.
            </Blogscontainer>
          </Content>
          <Avatar>
            <PlaceholderImage1 alt="" src="/placeholder--image-1@2x.png" />
            <Content1>
              <Contentcards>Full name</Contentcards>
              <Time>
                <TextBlockB>11 Jan 2022</TextBlockB>
                <Div>•</Div>
                <TextBlockB>5 min read</TextBlockB>
              </Time>
            </Content1>
          </Avatar>
        </Card>
        <Blogs>
          <Card />
          <Card />
          <Card />
        </Blogs>
      </Content2>
    </BlogHeroRoot>
  );
};

export default BlogHero;
