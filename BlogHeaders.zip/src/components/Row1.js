import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 300px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const HeadingText = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h2`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const CardFrame = styled.div`
  align-self: stretch;
  height: 48px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const Title = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h5-size);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const PlaceholderImage1 = styled.img`
  height: 48px;
  width: 48px;
  position: relative;
  object-fit: cover;
  min-height: 48px;
`;
const Text1 = styled.div`
  position: relative;
  line-height: 150%;
`;
const Div = styled.div`
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 7px;
  }
`;
const Time = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 338px;
  max-width: 100%;
  @media screen and (max-width: 675px) {
    min-width: 100%;
  }
`;
const Avatar = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Card = styled.div`
  flex: 1;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const RowRoot = styled.div`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  text-align: left;
  font-size: var(--text-small-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
`;

const Row1 = () => {
  return (
    <RowRoot>
      <Card>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image2@2x.png"
        />
        <Content2>
          <Content>
            <HeadingText>Category</HeadingText>
            <Title>
              <Heading>Blog title heading will go here</Heading>
              <CardFrame>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros.
              </CardFrame>
            </Title>
          </Content>
          <Avatar>
            <PlaceholderImage1 alt="" src="/placeholder--image-1@2x.png" />
            <Content1>
              <HeadingText>Full name</HeadingText>
              <Time>
                <Text1>11 Jan 2022</Text1>
                <Div>•</Div>
                <Text1>5 min read</Text1>
              </Time>
            </Content1>
          </Avatar>
        </Content2>
      </Card>
      <Card>
        <PlaceholderImage alt="" src="/placeholder--image2@2x.png" />
        <Content2>
          <Content>
            <HeadingText>Category</HeadingText>
            <Title>
              <Heading>Blog title heading will go here</Heading>
              <CardFrame>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse varius enim in eros.
              </CardFrame>
            </Title>
          </Content>
          <Avatar>
            <PlaceholderImage1 alt="" src="/placeholder--image-1@2x.png" />
            <Content1>
              <HeadingText>Full name</HeadingText>
              <Time>
                <Text1>11 Jan 2022</Text1>
                <Div>•</Div>
                <Text1>5 min read</Text1>
              </Time>
            </Content1>
          </Avatar>
        </Content2>
      </Card>
    </RowRoot>
  );
};

export default Row1;
