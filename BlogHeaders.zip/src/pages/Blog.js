import styled from "styled-components";
import Card8 from "../components/Card8";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 750px) {
    font-size: var(--font-size-26xl);
    line-height: 54px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h1-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const ViewAll = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-small-normal);
  color: var(--black);
  text-align: left;
`;
const Button = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-5xs) var(--padding-smi);
  background-color: transparent;
  width: 88px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const TextOne = styled.div`
  position: relative;
  line-height: 150%;
`;
const Button1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-sm);
  box-sizing: border-box;
  min-width: 84px;
`;
const Button2 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: var(--padding-5xs) var(--padding-sm);
  box-sizing: border-box;
  min-width: 89px;
`;
const Categories = styled.div`
  width: 608px;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  row-gap: 20px;
  max-width: 100%;
`;
const Content1 = styled.div`
  width: 1312px;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: 64px 32px;
  min-height: 1094px;
  max-width: 100%;
  @media screen and (max-width: 675px) {
    gap: 64px 32px;
  }
`;
const Content2 = styled.main`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
  @media screen and (max-width: 675px) {
    gap: var(--gap-45xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;
const BlogRoot = styled.div`
  position: relative;
  background-color: var(--white);
  width: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  letter-spacing: normal;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-small-normal);
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Blog = () => {
  return (
    <BlogRoot>
      <SectionTitle>
        <Subheading>Blog</Subheading>
        <Content>
          <Heading>Short heading goes here</Heading>
          <Text1>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</Text1>
        </Content>
      </SectionTitle>
      <Content2>
        <Categories>
          <Button>
            <ViewAll>View all</ViewAll>
          </Button>
          <Button1>
            <TextOne>Category one</TextOne>
          </Button1>
          <Button1>
            <TextOne>Category two</TextOne>
          </Button1>
          <Button2>
            <TextOne>Category three</TextOne>
          </Button2>
          <Button1>
            <TextOne>Category four</TextOne>
          </Button1>
        </Categories>
        <Content1>
          <Card8 />
          <Card8 />
          <Card8 />
          <Card8 />
          <Card8 />
          <Card8 />
        </Content1>
      </Content2>
    </BlogRoot>
  );
};

export default Blog;
