import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--text-small-normal: Roboto;

/* font sizes */
--text-small-normal-size: 14px;
--text-medium-normal-size: 18px;
--text-regular-normal-size: 16px;
--heading-h5-size: 24px;
--font-size-lgi: 19px;
--heading-h1-size: 56px;
--font-size-15xl: 34px;
--font-size-26xl: 45px;
--heading-h4-size: 32px;
--font-size-7xl: 26px;

/* Colors */
--white: #fff;
--black: #000;
--color-darkslategray-100: #333;
--color-darkslategray-200: rgba(51, 51, 51, 0.09);
--light-grey: #f4f4f4;
--color-gainsboro: #dbdbdb;

/* Gaps */
--gap-61xl: 80px;
--gap-45xl: 64px;
--gap-5xl: 24px;
--gap-base: 16px;
--gap-5xs: 8px;
--gap-29xl: 48px;
--gap-21xl: 40px;
--gap-13xl: 32px;
--gap-69xl: 88px;

/* Paddings */
--padding-93xl: 112px;
--padding-45xl: 64px;
--padding-13xl: 32px;
--padding-xl: 20px;
--padding-5xs: 8px;
--padding-sm: 14px;
--padding-smi: 13px;
--padding-9xs: 4px;
--padding-5xl: 24px;
--padding-29xl: 48px;

}
`;
