import styled from "styled-components";

const VectorsFrameIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 22px;
  }
`;
const AvatarImageIcon = styled.img`
  width: 56px;
  height: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const NameSurname = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const TextFrame = styled.div`
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const WebflowBlack = styled.img`
  width: 120px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-normal-size);
`;
const ColumnRoot = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 312px;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;

const Column2 = () => {
  return (
    <ColumnRoot>
      <Stars>
        <VectorsFrameIcon loading="eager" alt="" src="/vector.svg" />
        <VectorsFrameIcon loading="eager" alt="" src="/vector.svg" />
        <VectorsFrameIcon loading="eager" alt="" src="/vector.svg" />
        <VectorsFrameIcon loading="eager" alt="" src="/vector.svg" />
        <VectorsFrameIcon loading="eager" alt="" src="/vector.svg" />
      </Stars>
      <Quote>
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
        varius enim in eros elementum tristique. Duis cursus, mi quis viverra
        ornare."
      </Quote>
      <Avatar>
        <AvatarImageIcon loading="eager" alt="" src="/avatar-image1@2x.png" />
        <AvatarContent>
          <NameSurname>Name Surname</NameSurname>
          <TextFrame>Position, Company name</TextFrame>
        </AvatarContent>
        <WebflowBlack loading="eager" alt="" src="/webflow--black1.svg" />
      </Avatar>
    </ColumnRoot>
  );
};

export default Column2;
