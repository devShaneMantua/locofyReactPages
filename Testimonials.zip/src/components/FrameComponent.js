import styled from "styled-components";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 750px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const HeadingParent = styled.div`
  width: 560px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const Testimonial1InnerRoot = styled.section`width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  flex-shrink: 0;
  text-align: left;
  font-size: var(--heading-h2-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  width: ${(p) => p.frameDivWidth}
  align-self: ${(p) => p.frameDivAlignSelf}
  padding: ${(p) => p.frameDivPadding}
`;

const FrameComponent = ({
  frameDivWidth,
  frameDivAlignSelf,
  frameDivPadding,
}) => {
  return (
    <Testimonial1InnerRoot
      frameDivWidth={frameDivWidth}
      frameDivAlignSelf={frameDivAlignSelf}
      frameDivPadding={frameDivPadding}
    >
      <HeadingParent>
        <Heading>Customer testimonials</Heading>
        <Text1>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</Text1>
      </HeadingParent>
    </Testimonial1InnerRoot>
  );
};

export default FrameComponent;
