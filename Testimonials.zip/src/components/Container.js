import styled from "styled-components";

const VectorIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.b`
  align-self: stretch;
  height: 112px;
  position: relative;
  line-height: 140%;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 22px;
  }
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const Text1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Text2 = styled.div`
  position: relative;
  line-height: 150%;
`;
const TextParent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Divider = styled.div`
  height: 62px;
  width: 1px;
  position: relative;
  border-right: 1px solid var(--black);
  box-sizing: border-box;
  @media screen and (max-width: 450px) {
    width: 100%;
    height: 1px;
  }
`;
const WebflowBlack = styled.img`
  height: 48px;
  width: 120px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const AvatarImageParent = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xl);
  max-width: 100%;
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const ContainerRoot = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 406px;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
    min-width: 100%;
  }
`;

const Container = () => {
  return (
    <ContainerRoot>
      <Stars>
        <VectorIcon loading="eager" alt="" src="/vector.svg" />
        <VectorIcon loading="eager" alt="" src="/vector.svg" />
        <VectorIcon loading="eager" alt="" src="/vector.svg" />
        <VectorIcon loading="eager" alt="" src="/vector.svg" />
        <VectorIcon loading="eager" alt="" src="/vector.svg" />
      </Stars>
      <Quote>
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
        varius enim in eros elementum tristique. Duis cursus, mi quis viverra
        ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat."
      </Quote>
      <AvatarImageParent>
        <AvatarImageIcon loading="eager" alt="" src="/avatar-image@2x.png" />
        <TextParent>
          <Text1>Name Surname</Text1>
          <Text2>Position, Company name</Text2>
        </TextParent>
        <Divider />
        <WebflowBlack loading="eager" alt="" src="/webflow--black.svg" />
      </AvatarImageParent>
    </ContainerRoot>
  );
};

export default Container;
