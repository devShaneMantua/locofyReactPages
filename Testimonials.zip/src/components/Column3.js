import styled from "styled-components";

const StarIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  height: ${(p) => p.textHeight};
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const Text1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Text2 = styled.div`
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content = styled.div`
  align-self: stretch;
  border: 1px solid var(--black);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-12xl);
  gap: var(--gap-13xl);
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;
const Quote1 = styled.div`
  align-self: stretch;
  height: 135px;
  position: relative;
  line-height: 150%;
  display: inline-block;
  height: ${(p) => p.textHeight1};
`;
const ColumnRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 312px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;

const Column3 = ({ quote1, quote2, textHeight, textHeight1 }) => {
  return (
    <ColumnRoot>
      <Content>
        <Stars>
          <StarIcon loading="eager" alt="" src="/vector.svg" />
          <StarIcon loading="eager" alt="" src="/vector.svg" />
          <StarIcon loading="eager" alt="" src="/vector.svg" />
          <StarIcon loading="eager" alt="" src="/vector.svg" />
          <StarIcon loading="eager" alt="" src="/vector.svg" />
        </Stars>
        <Quote textHeight={textHeight}>{quote1}</Quote>
        <Avatar>
          <AvatarImageIcon loading="eager" alt="" src="/avatar-image1@2x.png" />
          <AvatarContent>
            <Text1>Name Surname</Text1>
            <Text2>Position, Company name</Text2>
          </AvatarContent>
        </Avatar>
      </Content>
      <Content>
        <Stars>
          <StarIcon loading="eager" alt="" src="/vector.svg" />
          <StarIcon loading="eager" alt="" src="/vector.svg" />
          <StarIcon loading="eager" alt="" src="/vector.svg" />
          <StarIcon loading="eager" alt="" src="/vector.svg" />
          <StarIcon loading="eager" alt="" src="/vector.svg" />
        </Stars>
        <Quote1 textHeight1={textHeight1}>{quote2}</Quote1>
        <Avatar>
          <AvatarImageIcon
            loading="eager"
            alt=""
            src="/avatar-image-1@2x.png"
          />
          <AvatarContent>
            <Text1>Name Surname</Text1>
            <Text2>Position, Company name</Text2>
          </AvatarContent>
        </Avatar>
      </Content>
    </ColumnRoot>
  );
};

export default Column3;
