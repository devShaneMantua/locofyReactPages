import styled from "styled-components";

const VectorIcon = styled.img`
  height: 18.9px;
  width: 20px;
  position: relative;
  min-height: 19px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Quote = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const AvatarImageIcon = styled.img`
  height: 56px;
  width: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const SliderDots = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const QuoteText = styled.div`
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-xl);
  font-size: var(--text-regular-normal-size);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const ColumnRoot = styled.div`
  width: 600px;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-14xl) var(--padding-13xl)
    var(--padding-12xl);
  gap: var(--gap-5xl);
  max-width: 100%;
  flex-shrink: 0;
  text-align: left;
  font-size: var(--text-medium-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const Column = () => {
  return (
    <ColumnRoot>
      <Stars>
        <VectorIcon loading="eager" alt="" src="/vector.svg" />
        <VectorIcon loading="eager" alt="" src="/vector.svg" />
        <VectorIcon loading="eager" alt="" src="/vector.svg" />
        <VectorIcon loading="eager" alt="" src="/vector.svg" />
        <VectorIcon loading="eager" alt="" src="/vector.svg" />
      </Stars>
      <Content>
        <Quote>
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare."
        </Quote>
        <Avatar>
          <AvatarImageIcon loading="eager" alt="" src="/avatar-image1@2x.png" />
          <AvatarContent>
            <SliderDots>Name Surname</SliderDots>
            <QuoteText>Position, Company name</QuoteText>
          </AvatarContent>
        </Avatar>
      </Content>
    </ColumnRoot>
  );
};

export default Column;
