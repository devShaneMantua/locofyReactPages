import styled from "styled-components";
import Column1 from "./Column1";

const Icon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xs);
  background-color: transparent;
  height: 48px;
  width: 48px;
  border-radius: var(--br-31xl);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const Content = styled.div`
  flex: 1;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-5xl);
  min-width: 806px;
  max-width: 100%;
  @media screen and (max-width: 900px) {
    min-width: 100%;
  }
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
  }
`;
const Dot = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--black);
`;
const Dot1 = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--color-gray);
`;
const SliderDots = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-3xs);
  gap: var(--gap-4xs);
`;
const TextContentRoot = styled.section`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 675px) {
    gap: var(--gap-29xl);
  }
`;

const TextContent = () => {
  return (
    <TextContentRoot>
      <Content1>
        <Button>
          <Icon alt="" src="/icon.svg" />
        </Button>
        <Content>
          <Column1 />
          <Column1 />
          <Column1 />
        </Content>
        <Button>
          <Icon alt="" src="/icon-1.svg" />
        </Button>
      </Content1>
      <SliderDots>
        <Dot />
        <Dot1 />
        <Dot1 />
        <Dot1 />
        <Dot1 />
      </SliderDots>
    </TextContentRoot>
  );
};

export default TextContent;
