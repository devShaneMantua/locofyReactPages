import styled from "styled-components";

const WebflowBlack = styled.img`
  width: 120px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const TextSuspendisseVarius = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 140%;
  @media screen and (max-width: 450px) {
    font-size: var(--text-regular-normal-size);
    line-height: 22px;
  }
`;
const AvatarImageIcon = styled.img`
  width: 56px;
  height: 56px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Text2 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const AvatarContent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
`;
const Avatar = styled.div`
  width: 340px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 0px var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--text-regular-normal-size);
`;
const ColumnRoot = styled.div`
  width: 368px;
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h6-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;

const Column1 = () => {
  return (
    <ColumnRoot>
      <WebflowBlack loading="eager" alt="" src="/webflow--black1.svg" />
      <TextSuspendisseVarius>
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
        varius enim in eros elementum tristique."
      </TextSuspendisseVarius>
      <Avatar>
        <AvatarImageIcon loading="eager" alt="" src="/avatar-image2@2x.png" />
        <AvatarContent>
          <Text1>Name Surname</Text1>
          <Text2>Position, Company name</Text2>
        </AvatarContent>
      </Avatar>
    </ColumnRoot>
  );
};

export default Column1;
