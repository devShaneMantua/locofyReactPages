import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--text-regular-normal: Roboto;

/* font sizes */
--text-regular-normal-size: 16px;
--heading-h6-size: 20px;
--text-medium-normal-size: 18px;
--heading-h2-size: 48px;
--font-size-10xl: 29px;
--font-size-19xl: 38px;

/* Colors */
--white: #fff;
--black: #000;
--color-gray: #8d8d8d;

/* Gaps */
--gap-61xl: 80px;
--gap-30xl: 49px;
--gap-xl: 20px;
--gap-mini: 15px;
--gap-5xs: 8px;
--gap-45xl: 64px;
--gap-13xl: 32px;
--gap-9xs: 4px;
--gap-5xl: 24px;
--gap-29xl: 48px;
--gap-4xs: 9px;
--gap-base: 16px;

/* Paddings */
--padding-93xl: 112px;
--padding-xl: 20px;
--padding-xs: 12px;
--padding-2xs: 11px;
--padding-13xl: 32px;
--padding-14xl: 33px;
--padding-12xl: 31px;
--padding-45xl: 64px;
--padding-3xs: 10px;

/* Border radiuses */
--br-31xl: 50px;

}
`;
