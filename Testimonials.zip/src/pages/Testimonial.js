import FrameComponent from "../components/FrameComponent";
import Container from "../components/Container";
import styled from "styled-components";

const ContainerParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  max-width: 100%;
  @media screen and (max-width: 675px) {
    gap: var(--gap-45xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;
const Dot = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--black);
`;
const Dot1 = styled.div`
  height: 8px;
  width: 8px;
  position: relative;
  border-radius: 50%;
  background-color: var(--color-gray);
`;
const SliderDots = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Icon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Button = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xs);
  background-color: transparent;
  height: 48px;
  width: 48px;
  border-radius: var(--br-31xl);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const ButtonIconFrame = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-mini);
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--gap-xl);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const FrameParent = styled.section`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-30xl);
  max-width: 100%;
  flex-shrink: 0;
  @media screen and (max-width: 675px) {
    gap: var(--gap-30xl);
  }
`;
const TestimonialRoot = styled.div`
  width: 100%;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-xl) 111px;
  box-sizing: border-box;
  gap: var(--gap-61xl);
  letter-spacing: normal;
  @media screen and (max-width: 675px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Testimonial = () => {
  return (
    <TestimonialRoot>
      <FrameComponent />
      <FrameParent>
        <ContainerParent>
          <Container />
          <Container />
        </ContainerParent>
        <Content>
          <SliderDots>
            <Dot />
            <Dot1 />
            <Dot1 />
            <Dot1 />
            <Dot1 />
          </SliderDots>
          <ButtonIconFrame>
            <Button>
              <Icon alt="" src="/icon.svg" />
            </Button>
            <Button>
              <Icon alt="" src="/icon-1.svg" />
            </Button>
          </ButtonIconFrame>
        </Content>
      </FrameParent>
    </TestimonialRoot>
  );
};

export default Testimonial;
