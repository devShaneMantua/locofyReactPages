import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Testimonial from "./pages/Testimonial";
import Testimonial2 from "./pages/Testimonial2";
import Testimonial3 from "./pages/Testimonial3";
import Testimonial1 from "./pages/Testimonial1";
import Testimonial1 from "./pages/Testimonial11";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/testimonial-3":
        title = "";
        metaDescription = "";
        break;
      case "/testimonial-4":
        title = "";
        metaDescription = "";
        break;
      case "/testimonial-5":
        title = "";
        metaDescription = "";
        break;
      case "/testimonial-2":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<Testimonial />} />
      <Route path="/testimonial-3" element={<Testimonial2 />} />
      <Route path="/testimonial-4" element={<Testimonial3 />} />
      <Route path="/testimonial-5" element={<Testimonial1 />} />
      <Route path="/testimonial-2" element={<Testimonial1 />} />
    </Routes>
  );
}
export default App;
