import styled from "styled-components";

const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 68px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const ButtonFrame = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h5-size);
`;
const ContentTop = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-5xl);
  gap: var(--gap-5xl);
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const Image1 = styled.div`
  align-self: stretch;
  height: 171px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
`;
const CardRoot = styled.div`
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const Card1 = () => {
  return (
    <CardRoot>
      <Content1>
        <ContentTop>
          <Subheading>Tagline</Subheading>
          <Content>
            <Heading>Medium length section heading goes here</Heading>
            <ButtonFrame>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</ButtonFrame>
          </Content>
        </ContentTop>
        <Actions>
          <Button1>
            <Button>Button</Button>
            <IconChevronRight
              loading="eager"
              alt=""
              src="/icon--chevron-right.svg"
            />
          </Button1>
        </Actions>
      </Content1>
      <Image1>
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image2@2x.png"
        />
      </Image1>
    </CardRoot>
  );
};

export default Card1;
