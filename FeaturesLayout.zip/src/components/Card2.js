import styled from "styled-components";

const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 750px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const Button = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h3-size);
`;
const ContentTop = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Button1 = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
`;
const Button2 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-4xl);
  background-color: transparent;
  width: 98px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Button3 = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button4 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-29xl);
  gap: var(--gap-13xl);
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
    padding-left: var(--padding-5xl);
    padding-right: var(--padding-5xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-12xl);
    padding-bottom: var(--padding-12xl);
    box-sizing: border-box;
  }
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const Image1 = styled.div`
  align-self: stretch;
  height: 360px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  z-index: 1;
  height: ${(p) => p.propHeight};
`;
const CardRoot = styled.div`align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  align-self: ${(p) => p.buttonAlignSelf}
  width: ${(p) => p.buttonWidth}
  padding: ${(p) => p.buttonPadding}
  min-width: ${(p) => p.buttonMinWidth}
`;

const Card2 = ({
  placeholderImage,
  buttonAlignSelf,
  buttonWidth,
  buttonPadding,
  buttonMinWidth,
  propHeight,
}) => {
  return (
    <CardRoot
      buttonAlignSelf={buttonAlignSelf}
      buttonWidth={buttonWidth}
      buttonPadding={buttonPadding}
      buttonMinWidth={buttonMinWidth}
    >
      <Content1>
        <ContentTop>
          <Subheading>Tagline</Subheading>
          <Content>
            <Heading>Medium length section heading goes here</Heading>
            <Button>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in eros elementum tristique.
            </Button>
          </Content>
        </ContentTop>
        <Actions>
          <Button2>
            <Button1>Button</Button1>
          </Button2>
          <Button4>
            <Button3>Button</Button3>
            <IconChevronRight
              loading="eager"
              alt=""
              src="/icon--chevron-right.svg"
            />
          </Button4>
        </Actions>
      </Content1>
      <Image1 propHeight={propHeight}>
        <PlaceholderImage loading="eager" alt="" src={placeholderImage} />
      </Image1>
    </CardRoot>
  );
};

export default Card2;
