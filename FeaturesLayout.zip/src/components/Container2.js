import styled from "styled-components";
import Row from "./Row";
import Card from "./Card";

const PlaceholderImage = styled.img`
  align-self: stretch;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const Image1 = styled.div`
  align-self: stretch;
  height: 360px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
`;
const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 750px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const ActionsContent = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h3-size);
`;
const ContentTop = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-4xl);
  background-color: transparent;
  width: 98px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Button2 = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button3 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-29xl);
  gap: var(--gap-13xl);
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
    padding-left: var(--padding-5xl);
    padding-right: var(--padding-5xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-12xl);
    padding-bottom: var(--padding-12xl);
    box-sizing: border-box;
  }
`;
const Card = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 416px;
  max-width: 100%;
  @media screen and (max-width: 675px) {
    min-width: 100%;
  }
`;
const Column = styled.div`
  width: 640px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
  }
`;
const Row1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
  }
`;
const ContainerRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
  }
`;

const Container2 = () => {
  return (
    <ContainerRoot>
      <Row1>
        <Card>
          <Image1>
            <PlaceholderImage
              loading="eager"
              alt=""
              src="/placeholder--image1@2x.png"
            />
          </Image1>
          <Content1>
            <ContentTop>
              <Subheading>Tagline</Subheading>
              <Content>
                <Heading>Medium length section heading goes here</Heading>
                <ActionsContent>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros elementum tristique.
                </ActionsContent>
              </Content>
            </ContentTop>
            <Actions>
              <Button1>
                <Button>Button</Button>
              </Button1>
              <Button3>
                <Button2>Button</Button2>
                <IconChevronRight
                  loading="eager"
                  alt=""
                  src="/icon--chevron-right.svg"
                />
              </Button3>
            </Actions>
          </Content1>
        </Card>
        <Column>
          <Row propHeight="unset" propHeight1="unset" />
          <Card
            placeholderImage="/placeholder--image-1@2x.png"
            propHeight="420px"
            propMinHeight="420px"
          />
        </Column>
      </Row1>
    </ContainerRoot>
  );
};

export default Container2;
