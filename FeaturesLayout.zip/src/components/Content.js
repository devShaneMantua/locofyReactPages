import Column from "./Column";
import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 540px;
  width: 610px;
  position: relative;
  max-width: calc(100% - 702px);
  overflow: hidden;
  object-fit: cover;
  @media screen and (max-width: 1100px) {
    max-width: calc(100% - 303px);
  }
  @media screen and (max-width: 1025px) {
    max-width: 100%;
  }
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  @media screen and (max-width: 750px) {
    gap: var(--gap-29xl);
  }
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-4xl);
  background-color: transparent;
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Button2 = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button3 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  width: 200px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--text-regular-normal-size);
`;
const ContentRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-29xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 750px) {
    gap: var(--gap-29xl);
  }
`;

const Content = () => {
  return (
    <ContentRoot>
      <Content1>
        <Column />
        <PlaceholderImage
          loading="eager"
          alt=""
          src="/placeholder--image@2x.png"
        />
        <Column />
      </Content1>
      <Actions>
        <Button1>
          <Button>Button</Button>
        </Button1>
        <Button3>
          <Button2>Button</Button2>
          <IconChevronRight
            loading="eager"
            alt=""
            src="/icon--chevron-right.svg"
          />
        </Button3>
      </Actions>
    </ContentRoot>
  );
};

export default Content;
