import Card1 from "./Card";
import styled from "styled-components";

const Row = styled.div`
  align-self: stretch;
  display: grid;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  grid-template-columns: repeat(4, minmax(228px, 1fr));
  @media screen and (max-width: 1050px) {
    justify-content: center;
    grid-template-columns: repeat(2, minmax(228px, 395px));
  }
  @media screen and (max-width: 725px) {
    gap: var(--gap-13xl);
    grid-template-columns: minmax(228px, 1fr);
  }
`;
const ContainerRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 725px) {
    gap: var(--gap-13xl);
  }
`;

const Container1 = () => {
  return (
    <ContainerRoot>
      <Row>
        <Card1 />
        <Card1 />
        <Card1 />
        <Card1 />
      </Row>
    </ContainerRoot>
  );
};

export default Container1;
