import styled from "styled-components";
import Card2 from "./Card2";

const IconRelume = styled.img`
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 84px;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const FrameCard = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const ContentTop = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-13xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
  min-height: 391px;
`;
const Card = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
`;
const Row = styled.div`
  width: 416px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 270px;
  max-width: 100%;
  flex-shrink: 0;
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;
const Row1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 1200px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
  }
`;
const ContainerRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h4-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
  }
`;

const Container3 = () => {
  return (
    <ContainerRoot>
      <Row1>
        <Row>
          <Card>
            <Content1>
              <ContentTop>
                <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
                <Content>
                  <Heading>Medium length section heading goes here</Heading>
                  <FrameCard>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </FrameCard>
                </Content>
              </ContentTop>
              <Actions>
                <Button1>
                  <Button>Button</Button>
                  <IconChevronRight
                    loading="eager"
                    alt=""
                    src="/icon--chevron-right.svg"
                  />
                </Button1>
              </Actions>
            </Content1>
          </Card>
          <Card>
            <Content1>
              <ContentTop>
                <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
                <Content>
                  <Heading>Medium length section heading goes here</Heading>
                  <FrameCard>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </FrameCard>
                </Content>
              </ContentTop>
              <Actions>
                <Button1>
                  <Button>Button</Button>
                  <IconChevronRight
                    loading="eager"
                    alt=""
                    src="/icon--chevron-right.svg"
                  />
                </Button1>
              </Actions>
            </Content1>
          </Card>
        </Row>
        <Card2
          placeholderImage="/placeholder--image4@2x.png"
          buttonAlignSelf="unset"
          buttonWidth="869px"
          buttonPadding="0px var(--padding-11xs) 0px 0px"
          buttonMinWidth="866px"
          propHeight="486px"
        />
      </Row1>
    </ContainerRoot>
  );
};

export default Container3;
