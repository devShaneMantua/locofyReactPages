import styled from "styled-components";

const IconRelume = styled.img`
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 68px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const PlaceholderImage = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Content1 = styled.div`
  width: 280px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 0px var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
`;
const ColumnRoot = styled.div`
  width: 303px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-45xl);
  text-align: center;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 1025px) {
    display: none;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-45xl);
  }
`;

const Column = () => {
  return (
    <ColumnRoot>
      <Content1>
        <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
        <Content>
          <Heading>Short heading goes here</Heading>
          <PlaceholderImage>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros.
          </PlaceholderImage>
        </Content>
      </Content1>
      <Content1>
        <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
        <Content>
          <Heading>Short heading goes here</Heading>
          <PlaceholderImage>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros.
          </PlaceholderImage>
        </Content>
      </Content1>
    </ColumnRoot>
  );
};

export default Column;
