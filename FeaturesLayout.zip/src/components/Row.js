import styled from "styled-components";

const IconRelume = styled.img`
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 68px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Heading1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const ContentTop = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  align-self: stretch;
  height: 340px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
  height: ${(p) => p.propHeight};
`;
const Card = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 198px;
`;
const Content2 = styled.div`
  align-self: stretch;
  height: 340px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
  height: ${(p) => p.propHeight1};
`;
const RowRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 675px) {
    flex-wrap: wrap;
    gap: var(--gap-13xl);
  }
`;

const Row = ({ propHeight, propHeight1 }) => {
  return (
    <RowRoot>
      <Card>
        <Content1 propHeight={propHeight}>
          <ContentTop>
            <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
            <Content>
              <Heading>Medium length section heading goes here</Heading>
              <Heading1>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </Heading1>
            </Content>
          </ContentTop>
          <Actions>
            <Button1>
              <Button>Button</Button>
              <IconChevronRight
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button1>
          </Actions>
        </Content1>
      </Card>
      <Card>
        <Content2 propHeight1={propHeight1}>
          <ContentTop>
            <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
            <Content>
              <Heading>Medium length section heading goes here</Heading>
              <Heading1>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </Heading1>
            </Content>
          </ContentTop>
          <Actions>
            <Button1>
              <Button>Button</Button>
              <IconChevronRight
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button1>
          </Actions>
        </Content2>
      </Card>
    </RowRoot>
  );
};

export default Row;
