import styled from "styled-components";

const IconRelume = styled.img`
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading = styled.b`
  align-self: stretch;
  height: 68px;
  position: relative;
  line-height: 140%;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Heading1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const ContentTop = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  font-size: var(--text-regular-normal-size);
`;
const Content1 = styled.div`
  align-self: stretch;
  height: 352px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xl);
  box-sizing: border-box;
  gap: var(--gap-5xl);
`;
const Card = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 198px;
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  @media screen and (max-width: 675px) {
    flex-wrap: wrap;
    gap: var(--gap-13xl);
  }
`;
const Heading2 = styled.h3`
  margin: 0;
  align-self: stretch;
  height: 68px;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 416px;
  max-width: 100%;
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
    min-width: 100%;
  }
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const Image1 = styled.div`
  align-self: stretch;
  height: 360px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
`;
const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading3 = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 750px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h3-size);
`;
const Button2 = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
`;
const Button3 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-4xl);
  background-color: transparent;
  width: 98px;
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Actions1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Content3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-29xl);
  gap: var(--gap-13xl);
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
    padding-left: var(--padding-5xl);
    padding-right: var(--padding-5xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-12xl);
    padding-bottom: var(--padding-12xl);
    box-sizing: border-box;
  }
`;
const Card1 = styled.div`
  flex: 1;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  min-width: 416px;
  max-width: 100%;
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 675px) {
    min-width: 100%;
  }
`;
const Row1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
  }
`;
const ContainerRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
  }
`;

const Container = () => {
  return (
    <ContainerRoot>
      <Row1>
        <Column>
          <Row>
            <Card>
              <Content1>
                <ContentTop>
                  <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
                  <Content>
                    <Heading>Medium length section heading goes here</Heading>
                    <Heading1>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    </Heading1>
                  </Content>
                </ContentTop>
                <Actions>
                  <Button1>
                    <Button>Button</Button>
                    <IconChevronRight
                      loading="eager"
                      alt=""
                      src="/icon--chevron-right.svg"
                    />
                  </Button1>
                </Actions>
              </Content1>
            </Card>
            <Card>
              <Content1>
                <ContentTop>
                  <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
                  <Content>
                    <Heading>Medium length section heading goes here</Heading>
                    <Heading1>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    </Heading1>
                  </Content>
                </ContentTop>
                <Actions>
                  <Button1>
                    <Button>Button</Button>
                    <IconChevronRight
                      loading="eager"
                      alt=""
                      src="/icon--chevron-right.svg"
                    />
                  </Button1>
                </Actions>
              </Content1>
            </Card>
          </Row>
          <Row>
            <Card>
              <Content1>
                <ContentTop>
                  <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
                  <Content>
                    <Heading2>Medium length section heading goes here</Heading2>
                    <Heading1>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    </Heading1>
                  </Content>
                </ContentTop>
                <Actions>
                  <Button1>
                    <Button>Button</Button>
                    <IconChevronRight
                      loading="eager"
                      alt=""
                      src="/icon--chevron-right.svg"
                    />
                  </Button1>
                </Actions>
              </Content1>
            </Card>
            <Card>
              <Content1>
                <ContentTop>
                  <IconRelume loading="eager" alt="" src="/icon--relume.svg" />
                  <Content>
                    <Heading>Medium length section heading goes here</Heading>
                    <Heading1>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    </Heading1>
                  </Content>
                </ContentTop>
                <Actions>
                  <Button1>
                    <Button>Button</Button>
                    <IconChevronRight
                      loading="eager"
                      alt=""
                      src="/icon--chevron-right.svg"
                    />
                  </Button1>
                </Actions>
              </Content1>
            </Card>
          </Row>
        </Column>
        <Card1>
          <Image1>
            <PlaceholderImage
              loading="eager"
              alt=""
              src="/placeholder--image1@2x.png"
            />
          </Image1>
          <Content3>
            <Content>
              <Subheading>Tagline</Subheading>
              <Content2>
                <Heading3>Medium length section heading goes here</Heading3>
                <Heading1>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse varius enim in eros elementum tristique.
                </Heading1>
              </Content2>
            </Content>
            <Actions1>
              <Button3>
                <Button2>Button</Button2>
              </Button3>
              <Button1>
                <Button>Button</Button>
                <IconChevronRight
                  loading="eager"
                  alt=""
                  src="/icon--chevron-right.svg"
                />
              </Button1>
            </Actions1>
          </Content3>
        </Card1>
      </Row1>
    </ContainerRoot>
  );
};

export default Container;
