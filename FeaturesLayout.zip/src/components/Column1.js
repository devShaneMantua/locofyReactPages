import styled from "styled-components";

const PlaceholderImage = styled.img`
  align-self: stretch;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const Image1 = styled.div`
  align-self: stretch;
  height: 233px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
`;
const Subheading = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 84px;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 750px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--heading-h4-size);
`;
const ContentTop = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Button = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-13xl);
  gap: var(--gap-5xl);
`;
const Card = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-11xs) 0px 0px;
  flex-shrink: 0;
`;
const IconRelume = styled.input`
  margin: 0;
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const ContentTop1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Actions1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  font-size: var(--text-regular-normal-size);
`;
const Content3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-13xl);
  gap: var(--gap-5xl);
  flex-shrink: 0;
`;
const Card1 = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-11xs) 0px 0px;
  flex-shrink: 0;
  font-size: var(--heading-h4-size);
`;
const ColumnRoot = styled.div`
  width: 416px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const Column1 = () => {
  return (
    <ColumnRoot>
      <Card>
        <Image1>
          <PlaceholderImage
            loading="eager"
            alt=""
            src="/placeholder--image3@2x.png"
          />
        </Image1>
        <Content1>
          <ContentTop>
            <Subheading>Tagline</Subheading>
            <Content>
              <Heading>Medium length section heading goes here</Heading>
              <Text1>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </Text1>
            </Content>
          </ContentTop>
          <Actions>
            <Button1>
              <Button>Button</Button>
              <IconChevronRight
                loading="eager"
                alt=""
                src="/icon--chevron-right.svg"
              />
            </Button1>
          </Actions>
        </Content1>
      </Card>
      <Card1>
        <Content3>
          <ContentTop1>
            <IconRelume type="checkbox" />
            <Content2>
              <Heading>Medium length section heading goes here</Heading>
              <Text1>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </Text1>
            </Content2>
          </ContentTop1>
          <Actions1>
            <Button1>
              <Button>Button</Button>
              <IconChevronRight alt="" src="/icon--chevron-right.svg" />
            </Button1>
          </Actions1>
        </Content3>
      </Card1>
    </ColumnRoot>
  );
};

export default Column1;
