import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--text-regular-normal: Roboto;

/* font sizes */
--text-regular-normal-size: 16px;
--heading-h5-size: 24px;
--font-size-lgi: 19px;
--text-medium-normal-size: 18px;
--heading-h2-size: 48px;
--font-size-19xl: 38px;
--font-size-10xl: 29px;
--heading-h3-size: 40px;
--heading-h4-size: 32px;
--font-size-7xl: 26px;

/* Colors */
--white: #fff;
--black: #000;
--color-darkslategray-100: #333;
--color-darkslategray-200: rgba(51, 51, 51, 0.09);

/* Gaps */
--gap-61xl: 80px;
--gap-29xl: 48px;
--gap-5xl: 24px;
--gap-5xs: 8px;
--gap-45xl: 64px;
--gap-base: 16px;
--gap-13xl: 32px;

/* Paddings */
--padding-93xl: 112px;
--padding-45xl: 64px;
--padding-13xl: 32px;
--padding-base: 16px;
--padding-xs: 12px;
--padding-4xl: 23px;
--padding-xl: 20px;
--padding-29xl: 48px;
--padding-12xl: 31px;
--padding-5xl: 24px;
--padding-11xs: 2px;

}
`;
