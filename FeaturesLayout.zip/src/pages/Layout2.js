import styled from "styled-components";
import Column1 from "../components/Column1";

const Subheading = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 750px) {
    font-size: var(--font-size-19xl);
    line-height: 46px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
    line-height: 35px;
  }
`;
const Heading1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-medium-normal-size);
  line-height: 150%;
`;
const Content = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  font-size: var(--heading-h2-size);
`;
const SectionTitle = styled.div`
  width: 768px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const IconRelume = styled.input`
  margin: 0;
  width: 48px;
  height: 48px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading2 = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 84px;
  position: relative;
  font-size: inherit;
  line-height: 130%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  @media screen and (max-width: 750px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const Button = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const ContentTop = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Button1 = styled.div`
  position: relative;
  line-height: 150%;
`;
const IconChevronRight = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const Button2 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: var(--gap-5xs);
`;
const Actions = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  font-size: var(--text-regular-normal-size);
`;
const Content2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-13xl);
  gap: var(--gap-5xl);
  flex-shrink: 0;
`;
const Card = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-11xs) 0px 0px;
  flex-shrink: 0;
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
`;
const Image1 = styled.div`
  align-self: stretch;
  height: 233px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
`;
const Subheading1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Content3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--heading-h4-size);
`;
const ContentTop1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Actions1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
`;
const Content4 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-13xl);
  gap: var(--gap-5xl);
`;
const Card1 = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-11xs) 0px 0px;
  flex-shrink: 0;
  font-size: var(--text-regular-normal-size);
`;
const Column = styled.div`
  width: 416px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
`;
const Row = styled.div`
  width: 1312px;
  overflow-x: auto;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
  }
`;
const Container = styled.section`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h4-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 675px) {
    gap: var(--gap-13xl);
  }
`;
const LayoutRoot = styled.div`
  position: relative;
  background-color: var(--white);
  width: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  letter-spacing: normal;
  text-align: center;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;

const Layout2 = () => {
  return (
    <LayoutRoot>
      <SectionTitle>
        <Subheading>Tagline</Subheading>
        <Content>
          <Heading>Short heading goes here</Heading>
          <Heading1>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          </Heading1>
        </Content>
      </SectionTitle>
      <Container>
        <Row>
          <Column1 />
          <Column>
            <Card>
              <Content2>
                <ContentTop>
                  <IconRelume type="checkbox" />
                  <Content1>
                    <Heading2>Medium length section heading goes here</Heading2>
                    <Button>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    </Button>
                  </Content1>
                </ContentTop>
                <Actions>
                  <Button2>
                    <Button1>Button</Button1>
                    <IconChevronRight alt="" src="/icon--chevron-right.svg" />
                  </Button2>
                </Actions>
              </Content2>
            </Card>
            <Card1>
              <Image1>
                <PlaceholderImage alt="" src="/placeholder--image3@2x.png" />
              </Image1>
              <Content4>
                <ContentTop1>
                  <Subheading1>Tagline</Subheading1>
                  <Content3>
                    <Heading2>Medium length section heading goes here</Heading2>
                    <Button>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    </Button>
                  </Content3>
                </ContentTop1>
                <Actions1>
                  <Button2>
                    <Button1>Button</Button1>
                    <IconChevronRight alt="" src="/icon--chevron-right.svg" />
                  </Button2>
                </Actions1>
              </Content4>
            </Card1>
          </Column>
          <Column1 />
        </Row>
      </Container>
    </LayoutRoot>
  );
};

export default Layout2;
