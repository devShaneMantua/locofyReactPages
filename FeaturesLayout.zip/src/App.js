import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Layout5 from "./pages/Layout5";
import Layout6 from "./pages/Layout6";
import Layout1 from "./pages/Layout1";
import Layout2 from "./pages/Layout2";
import Layout from "./pages/Layout";
import Layout3 from "./components/Layout3";
import Layout4 from "./pages/Layout4";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/layout-1":
        title = "";
        metaDescription = "";
        break;
      case "/layout-2":
        title = "";
        metaDescription = "";
        break;
      case "/layout-3":
        title = "";
        metaDescription = "";
        break;
      case "/layout-4":
        title = "";
        metaDescription = "";
        break;
      case "/layout-5":
        title = "";
        metaDescription = "";
        break;
      case "/layout-6":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<Layout5 />} />
      <Route path="/layout-1" element={<Layout6 />} />
      <Route path="/layout-2" element={<Layout1 />} />
      <Route path="/layout-3" element={<Layout2 />} />
      <Route path="/layout-4" element={<Layout />} />
      <Route path="/layout-5" element={<Layout3 />} />
      <Route path="/layout-6" element={<Layout4 />} />
    </Routes>
  );
}
export default App;
