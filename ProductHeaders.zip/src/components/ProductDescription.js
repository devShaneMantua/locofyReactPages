import styled from "styled-components";
import TabsMenu from "./TabsMenu";

const Heading = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: var(--heading-h3-size);
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const List = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const LoremIpsumDolor = styled.li``;
const LoremIpsumDolorSitAmetCo = styled.ul`
  margin: 0;
  font-family: inherit;
  font-size: inherit;
  padding-left: var(--padding-2xl);
`;
const TabIconContainerContainer = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
`;
const ListItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  max-width: 100%;
`;
const List1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  max-width: 100%;
`;
const Description = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const ProductDescriptionRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 541px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;

const ProductDescription = () => {
  return (
    <ProductDescriptionRoot>
      <Heading>Product name</Heading>
      <Description>
        <List>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
        </List>
        <List1>
          <ListItem>
            <TabIconContainerContainer>
              <LoremIpsumDolorSitAmetCo>
                <LoremIpsumDolor>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</LoremIpsumDolor>
              </LoremIpsumDolorSitAmetCo>
            </TabIconContainerContainer>
          </ListItem>
          <ListItem>
            <TabIconContainerContainer>
              <LoremIpsumDolorSitAmetCo>
                <LoremIpsumDolor>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</LoremIpsumDolor>
              </LoremIpsumDolorSitAmetCo>
            </TabIconContainerContainer>
          </ListItem>
          <ListItem>
            <TabIconContainerContainer>
              <LoremIpsumDolorSitAmetCo>
                <LoremIpsumDolor>{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. `}</LoremIpsumDolor>
              </LoremIpsumDolorSitAmetCo>
            </TabIconContainerContainer>
          </ListItem>
        </List1>
      </Description>
      <TabsMenu productImageContainer="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere." />
    </ProductDescriptionRoot>
  );
};

export default ProductDescription;
