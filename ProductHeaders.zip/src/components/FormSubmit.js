import styled from "styled-components";

const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--white);
  text-align: left;
  display: ${(p) => p.buttonDisplay};
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-5xl);
  background-color: var(--black);
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Button2 = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
  display: ${(p) => p.buttonDisplay1};
`;
const Button3 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-5xl);
  background-color: transparent;
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const FormSubmitRoot = styled.div`width: 616px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-base);
  width: ${(p) => p.propWidth}
  align-self: ${(p) => p.propAlignSelf}
`;

const FormSubmit = ({
  propWidth,
  propAlignSelf,
  buttonDisplay,
  buttonDisplay1,
}) => {
  return (
    <FormSubmitRoot propWidth={propWidth} propAlignSelf={propAlignSelf}>
      <Button1>
        <Button buttonDisplay={buttonDisplay}>Add To Cart</Button>
      </Button1>
      <Button3>
        <Button2 buttonDisplay1={buttonDisplay1}>Buy Now</Button2>
      </Button3>
    </FormSubmitRoot>
  );
};

export default FormSubmit;
