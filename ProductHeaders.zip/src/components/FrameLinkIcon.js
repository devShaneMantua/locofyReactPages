import styled from "styled-components";

const Link = styled.div`
  position: relative;
  line-height: 150%;
`;
const Icon = styled.img`
  height: 16px;
  width: 16px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Link1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Link2 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
  min-width: 205px;
  min-height: 304px;
`;
const Row = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const PlaceholderImage1 = styled.img`
  height: 304px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  min-width: 205px;
  min-height: 304px;
  @media screen and (max-width: 750px) {
    flex: 1;
  }
`;
const PlaceholderImage2 = styled.img`
  height: 304px;
  width: 316px;
  position: relative;
  object-fit: cover;
  display: none;
`;
const Button = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-lgi) var(--padding-xs)
    var(--padding-4xl);
  background-color: var(--white);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  z-index: 1;
  &:hover {
    background-color: var(--color-gainsboro);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Container = styled.div`
  flex: 0.8987;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: flex-end;
  padding: var(--padding-base);
  box-sizing: border-box;
  gap: var(--gap-base);
  background-image: url("/container@3x.png");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
  min-width: 205px;
  min-height: 304px;
  @media screen and (max-width: 750px) {
    flex: 1;
    min-height: auto;
  }
`;
const ShippingReturnsFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const Tab = styled.div`
  width: 648px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const Button2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-end;
  max-width: 100%;
`;
const FrameLinkIconRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--text-small-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const FrameLinkIcon = () => {
  return (
    <FrameLinkIconRoot>
      <Link2>
        <Link>Shop all</Link>
        <Icon loading="eager" alt="" src="/icon.svg" />
        <Link>Category</Link>
        <Icon loading="eager" alt="" src="/icon.svg" />
        <Link1>Product name</Link1>
      </Link2>
      <Button2>
        <Tab>
          <Row>
            <PlaceholderImage
              loading="eager"
              alt=""
              src="/placeholder--image-1@2x.png"
            />
            <PlaceholderImage
              loading="eager"
              alt=""
              src="/placeholder--image-1@2x.png"
            />
          </Row>
          <ShippingReturnsFrame>
            <PlaceholderImage1
              loading="eager"
              alt=""
              src="/placeholder--image-1@2x.png"
            />
            <Container>
              <PlaceholderImage2 alt="" src="/placeholder--image-1@2x.png" />
              <Button1>
                <Button>Show All Photos</Button>
              </Button1>
            </Container>
          </ShippingReturnsFrame>
        </Tab>
      </Button2>
    </FrameLinkIconRoot>
  );
};

export default FrameLinkIcon;
