import styled from "styled-components";
import Input2 from "./Input2";
import FormSubmit from "./FormSubmit";

const Price = styled.b`
  align-self: stretch;
  position: relative;
  line-height: 130%;
  white-space: nowrap;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const ProductName = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  font-size: var(--heading-h4-size);
`;
const TabsContainerIcon = styled.img`
  height: 15.1px;
  width: 16px;
  position: relative;
  min-height: 15px;
`;
const TabsContainerIcon1 = styled.img`
  height: 15.2px;
  width: 16px;
  position: relative;
  min-height: 15px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const ProductDescriptionArea = styled.div`
  position: relative;
  line-height: 150%;
`;
const ProductReview = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  text-align: center;
  font-size: var(--text-small-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Quantity = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Placeholder = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.div`
  width: 66px;
  height: ;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-sm) var(--padding-xs)
    var(--padding-xs);
`;
const Input = styled.div`
  align-self: stretch;
  height: 80px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const TextInputField = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-tiny-normal-size);
  line-height: 150%;
  text-align: center;
`;
const FormRoot = styled.div`
  width: 400px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 400px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 1200px) {
    flex: 1;
  }
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;

const Form = () => {
  return (
    <FormRoot>
      <ProductName>
        <Price>{`$55 `}</Price>
      </ProductName>
      <ProductReview>
        <Stars>
          <TabsContainerIcon loading="eager" alt="" src="/vector.svg" />
          <TabsContainerIcon loading="eager" alt="" src="/vector.svg" />
          <TabsContainerIcon loading="eager" alt="" src="/vector.svg" />
          <TabsContainerIcon1 loading="eager" alt="" src="/vector-3.svg" />
          <TabsContainerIcon loading="eager" alt="" src="/vector-4.svg" />
        </Stars>
        <ProductDescriptionArea>
          (3.5 stars) • 10 reviews
        </ProductDescriptionArea>
      </ProductReview>
      <Input2 />
      <Input>
        <Quantity>Quantity</Quantity>
        <TextInput>
          <Placeholder>1</Placeholder>
        </TextInput>
      </Input>
      <FormSubmit
        propWidth="unset"
        propAlignSelf="stretch"
        buttonDisplay="inline-block"
        buttonDisplay1="inline-block"
      />
      <TextInputField>Free shipping over $50</TextInputField>
    </FormRoot>
  );
};

export default Form;
