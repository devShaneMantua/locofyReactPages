import styled from "styled-components";

const Variant = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const SelectOne = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: calc(100% - 40px);
`;
const IconChevronDown = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: ${(p) => p.propMinHeight};
`;
const Select = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-smi) var(--padding-xs)
    var(--padding-2xs);
  gap: var(--gap-base);
  max-width: 100%;
  color: var(--color-dimgray);
`;
const InputRoot = styled.div`width: 616px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  width: ${(p) => p.propWidth}
  flex: ${(p) => p.propFlex}
`;

const Input1 = ({ propWidth, propFlex, propMinHeight }) => {
  return (
    <InputRoot propWidth={propWidth} propFlex={propFlex}>
      <Variant>Variant</Variant>
      <Select>
        <SelectOne>Select</SelectOne>
        <IconChevronDown
          alt=""
          src="/icon--chevron-down.svg"
          propMinHeight={propMinHeight}
        />
      </Select>
    </InputRoot>
  );
};

export default Input1;
