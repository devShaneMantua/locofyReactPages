import styled from "styled-components";

const Details = styled.div`
  position: relative;
  line-height: 150%;
`;
const VectorArrowIcon = styled.img`
  align-self: stretch;
  height: 1px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
`;
const Tab = styled.div`
  height: 32px;
  width: 49px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const TabChild = styled.img`
  align-self: stretch;
  height: 0px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  display: none;
`;
const Tab1 = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Tabs = styled.div`
  width: 214px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const ProductImageContainer = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  height: ${(p) => p.propHeight};
`;
const TabsMenuRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const TabsMenu = ({ productImageContainer, propHeight }) => {
  return (
    <TabsMenuRoot>
      <Tabs>
        <Tab>
          <Details>Details</Details>
          <VectorArrowIcon loading="eager" alt="" src="/vector-1.svg" />
        </Tab>
        <Tab1>
          <Details>Shipping</Details>
          <TabChild alt="" src="/vector-1.svg" />
        </Tab1>
        <Tab1>
          <Details>Returns</Details>
          <TabChild alt="" src="/vector-1.svg" />
        </Tab1>
      </Tabs>
      <ProductImageContainer propHeight={propHeight}>
        {productImageContainer}
      </ProductImageContainer>
    </TabsMenuRoot>
  );
};

export default TabsMenu;
