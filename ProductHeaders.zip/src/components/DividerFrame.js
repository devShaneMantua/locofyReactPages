import styled from "styled-components";

const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Heading = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
  max-width: calc(100% - 36px);
`;
const Icon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const IconTextFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
`;
const Text1 = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const DividerFrameRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-semi-bold-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const DividerFrame = ({ heading, icon }) => {
  return (
    <DividerFrameRoot>
      <Divider />
      <IconTextFrame>
        <Heading>{heading}</Heading>
        <Icon alt="" src={icon} />
      </IconTextFrame>
      <Text1>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
        varius enim in eros elementum tristique. Duis cursus, mi quis viverra
        ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
        Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut
        sem vitae risus tristique posuere.
      </Text1>
    </DividerFrameRoot>
  );
};

export default DividerFrame;
