import styled from "styled-components";
import Input1 from "./Input1";
import Input from "./Input";
import FormSubmit from "./FormSubmit";
import DividerFrame from "./DividerFrame";

const Heading = styled.h1`
  margin: 0;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const Price = styled.b`
  position: relative;
  font-size: var(--heading-h5-size);
  line-height: 140%;
  white-space: nowrap;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const ProductName = styled.div`
  width: 252px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  font-size: var(--heading-h3-size);
`;
const StarVectorIcon = styled.img`
  height: 15.1px;
  width: 16px;
  position: relative;
  min-height: 15px;
`;
const StarVectorIcon1 = styled.img`
  height: 15.2px;
  width: 16px;
  position: relative;
  min-height: 15px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const Text1 = styled.div`
  position: relative;
  line-height: 150%;
`;
const ProductReview = styled.div`
  width: 247px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  text-align: center;
  font-size: var(--text-small-normal-size);
`;
const FormButton = styled.div`
  width: 616px;
  position: relative;
  line-height: 150%;
  display: inline-block;
`;
const Quantity = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Placeholder = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.div`
  width: 66px;
  height: ;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-sm) var(--padding-xs)
    var(--padding-xs);
`;
const Input2 = styled.div`
  width: 616px;
  height: 80px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const ProductNameLabel = styled.div`
  width: 616px;
  position: relative;
  font-size: var(--text-tiny-normal-size);
  line-height: 150%;
  text-align: center;
  display: inline-block;
`;
const ProductDescription = styled.div`
  flex: 1;
  overflow-x: auto;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const ProductDescriptionWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-5xs);
  box-sizing: border-box;
  max-width: 100%;
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const FrameParentRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const FrameComponent = () => {
  return (
    <FrameParentRoot>
      <ProductDescriptionWrapper>
        <ProductDescription>
          <ProductName>
            <Heading>Product name</Heading>
            <Price>{`$55 `}</Price>
          </ProductName>
          <ProductReview>
            <Stars>
              <StarVectorIcon loading="eager" alt="" src="/vector.svg" />
              <StarVectorIcon alt="" src="/vector.svg" />
              <StarVectorIcon alt="" src="/vector.svg" />
              <StarVectorIcon1 alt="" src="/vector-3.svg" />
              <StarVectorIcon alt="" src="/vector-4.svg" />
            </Stars>
            <Text1>(3.5 stars) • 10 reviews</Text1>
          </ProductReview>
          <FormButton>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla, ut commodo diam libero
            vitae erat.
          </FormButton>
          <Input1 />
          <Input />
          <Input2>
            <Quantity>Quantity</Quantity>
            <TextInput>
              <Placeholder>1</Placeholder>
            </TextInput>
          </Input2>
          <FormSubmit />
          <ProductNameLabel>Free shipping over $50</ProductNameLabel>
        </ProductDescription>
      </ProductDescriptionWrapper>
      <DividerFrame heading="Details" icon="/icon-2.svg" />
      <DividerFrame heading="Shipping" icon="/icon-2.svg" />
      <DividerFrame heading="Returns" icon="/icon-2.svg" />
      <Divider />
    </FrameParentRoot>
  );
};

export default FrameComponent;
