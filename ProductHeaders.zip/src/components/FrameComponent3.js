import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 500px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  display: none;
`;
const Row = styled.div`
  align-self: stretch;
  height: 500px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  background-image: url("/row@3x.png");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
  max-width: 100%;
`;
const PlaceholderImage1 = styled.img`
  align-self: stretch;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
  min-width: 195px;
  min-height: 250px;
`;
const Row1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const RowParentRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;

const FrameComponent3 = () => {
  return (
    <RowParentRoot>
      <Row>
        <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
      </Row>
      <Row1>
        <PlaceholderImage1
          loading="eager"
          alt=""
          src="/placeholder--image3@2x.png"
        />
        <PlaceholderImage1 alt="" src="/placeholder--image3@2x.png" />
      </Row1>
      <Row1>
        <PlaceholderImage1 alt="" src="/placeholder--image3@2x.png" />
        <PlaceholderImage1 alt="" src="/placeholder--image3@2x.png" />
      </Row1>
      <Row1>
        <PlaceholderImage1 alt="" src="/placeholder--image3@2x.png" />
        <PlaceholderImage1 alt="" src="/placeholder--image3@2x.png" />
      </Row1>
    </RowParentRoot>
  );
};

export default FrameComponent3;
