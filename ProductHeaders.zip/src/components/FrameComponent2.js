import styled from "styled-components";
import Input1 from "./Input1";
import Input from "./Input";
import FormSubmit from "./FormSubmit";
import FrameSections from "./FrameSections";
import DividerFrame from "./DividerFrame";

const Link = styled.div`
  position: relative;
  line-height: 150%;
`;
const Icon = styled.img`
  height: 16px;
  width: 16px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Link1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Breadcrumbs = styled.div`
  width: 616px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const Heading = styled.h1`
  margin: 0;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const Price = styled.b`
  position: relative;
  font-size: var(--heading-h4-size);
  line-height: 130%;
  white-space: nowrap;
  @media screen and (max-width: 1050px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const ProductName = styled.div`
  width: 616px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  text-align: left;
  font-size: var(--heading-h3-size);
`;
const VectorStarIcon = styled.img`
  height: 15.1px;
  width: 16px;
  position: relative;
  min-height: 15px;
`;
const VectorStarIcon1 = styled.img`
  height: 15.2px;
  width: 16px;
  position: relative;
  min-height: 15px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const ProductReview = styled.div`
  width: 247px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const InputSelectOptions = styled.div`
  width: 616px;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  text-align: left;
  display: inline-block;
`;
const Input = styled.div`
  width: 616px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Quantity = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const Placeholder = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.div`
  width: 66px;
  height: ;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-sm) var(--padding-xs)
    var(--padding-xs);
`;
const Input2 = styled.div`
  width: 616px;
  height: 80px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  text-align: left;
  font-size: var(--text-regular-normal-size);
`;
const FreeShippingOver = styled.div`
  width: 616px;
  position: relative;
  font-size: var(--text-tiny-normal-size);
  line-height: 150%;
  display: inline-block;
`;
const ProductDescription = styled.div`
  flex: 1;
  overflow-x: auto;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const FRAME = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-5xs);
  box-sizing: border-box;
  max-width: 100%;
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const FRAMEParentRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 400px;
  max-width: 100%;
  text-align: center;
  font-size: var(--text-small-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;

const FrameComponent2 = () => {
  return (
    <FRAMEParentRoot>
      <FRAME>
        <ProductDescription>
          <Breadcrumbs>
            <Link>Shop all</Link>
            <Icon loading="eager" alt="" src="/icon.svg" />
            <Link>Category</Link>
            <Icon alt="" src="/icon.svg" />
            <Link1>Product name</Link1>
          </Breadcrumbs>
          <ProductName>
            <Heading>Product name</Heading>
            <Price>{`$55 `}</Price>
          </ProductName>
          <ProductReview>
            <Stars>
              <VectorStarIcon loading="eager" alt="" src="/vector.svg" />
              <VectorStarIcon alt="" src="/vector.svg" />
              <VectorStarIcon alt="" src="/vector.svg" />
              <VectorStarIcon1 alt="" src="/vector-3.svg" />
              <VectorStarIcon alt="" src="/vector-4.svg" />
            </Stars>
            <Link>(3.5 stars) • 10 reviews</Link>
          </ProductReview>
          <InputSelectOptions>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla, ut commodo diam libero
            vitae erat.
          </InputSelectOptions>
          <Input>
            <Input1 propWidth="unset" propFlex="1" propMinHeight="24px" />
            <Input1 propWidth="unset" propFlex="1" propMinHeight="24px" />
          </Input>
          <Input propWidth="616px" propAlignSelf="unset" />
          <Input2>
            <Quantity>Quantity</Quantity>
            <TextInput>
              <Placeholder>1</Placeholder>
            </TextInput>
          </Input2>
          <FormSubmit
            propWidth="616px"
            propAlignSelf="unset"
            buttonDisplay="inline-block"
            buttonDisplay1="inline-block"
          />
          <FreeShippingOver>Free shipping over $50</FreeShippingOver>
        </ProductDescription>
      </FRAME>
      <FrameSections plus="/icon-2.svg" plus1="/icon-2.svg" />
      <DividerFrame heading="Returns" icon="/icon-2.svg" />
      <Divider />
    </FRAMEParentRoot>
  );
};

export default FrameComponent2;
