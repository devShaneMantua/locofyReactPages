import styled from "styled-components";

const Variant = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const OptionOne = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--white);
  text-align: left;
`;
const Button = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xl);
  background-color: var(--black);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  &:hover {
    background-color: var(--color-darkslategray-100);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const OptionTwo = styled.div`
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
  font-family: var(--text-regular-normal);
  color: var(--black);
  text-align: left;
`;
const Button1 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xl);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Button2 = styled.button`
  cursor: pointer;
  border: 1px solid var(--black);
  padding: var(--padding-xs) var(--padding-2xl);
  background-color: transparent;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  opacity: 0.25;
  &:hover {
    background-color: var(--color-darkslategray-200);
    border: 1px solid var(--color-darkslategray-100);
    box-sizing: border-box;
  }
`;
const Variants = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const InputRoot = styled.div`width: 616px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  width: ${(p) => p.propWidth}
  align-self: ${(p) => p.propAlignSelf}
`;

const Input = ({ propWidth, propAlignSelf }) => {
  return (
    <InputRoot propWidth={propWidth} propAlignSelf={propAlignSelf}>
      <Variant>Variant</Variant>
      <Variants>
        <Button>
          <OptionOne>Option One</OptionOne>
        </Button>
        <Button1>
          <OptionTwo>Option Two</OptionTwo>
        </Button1>
        <Button2>
          <OptionTwo>Option Three</OptionTwo>
        </Button2>
      </Variants>
    </InputRoot>
  );
};

export default Input;
