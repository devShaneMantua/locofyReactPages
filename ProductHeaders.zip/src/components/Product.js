import styled from "styled-components";
import FormSubmit from "./FormSubmit";

const PlaceholderIcon = styled.img`
  align-self: stretch;
  height: 190px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
`;
const Price = styled.b`
  position: relative;
  line-height: 130%;
  white-space: nowrap;
  @media screen and (max-width: 1000px) {
    font-size: var(--font-size-7xl);
    line-height: 33px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 25px;
  }
`;
const LinkIconVector = styled.img`
  align-self: stretch;
  width: 1px;
  position: relative;
  max-height: 100%;
  min-height: 42px;
`;
const RatingVectorIcon = styled.img`
  height: 15.1px;
  width: 16px;
  position: relative;
  min-height: 15px;
`;
const RatingVectorIcon1 = styled.img`
  height: 15.2px;
  width: 16px;
  position: relative;
  min-height: 15px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const TextReviewFrame = styled.div`
  position: relative;
  line-height: 150%;
`;
const ProductReview = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-9xs);
  text-align: center;
  font-size: var(--text-small-normal-size);
`;
const Price1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const PriceLabel = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-tiny-normal-size);
  line-height: 150%;
  text-align: center;
`;
const ProductRoot = styled.div`
  width: 360px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 360px;
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h4-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 1100px) {
    flex: 1;
  }
  @media screen and (max-width: 450px) {
    min-width: 100%;
  }
`;

const Product = () => {
  return (
    <ProductRoot>
      <PlaceholderIcon loading="eager" alt="" src="/placeholder.svg" />
      <Price1>
        <Price>{`$55 `}</Price>
        <LinkIconVector alt="" src="/link-icon-vector.svg" />
        <ProductReview>
          <Stars>
            <RatingVectorIcon alt="" src="/vector.svg" />
            <RatingVectorIcon alt="" src="/vector.svg" />
            <RatingVectorIcon alt="" src="/vector.svg" />
            <RatingVectorIcon1 alt="" src="/vector-3.svg" />
            <RatingVectorIcon alt="" src="/vector-4.svg" />
          </Stars>
          <TextReviewFrame>(3.5 stars) • 10 reviews</TextReviewFrame>
        </ProductReview>
      </Price1>
      <FormSubmit
        propWidth="unset"
        propAlignSelf="stretch"
        buttonDisplay="inline-block"
        buttonDisplay1="inline-block"
      />
      <PriceLabel>30-Day Money-Back Guarantee</PriceLabel>
    </ProductRoot>
  );
};

export default Product;
