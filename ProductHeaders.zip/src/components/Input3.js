import styled from "styled-components";

const Variant = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const SelectOne = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: calc(100% - 40px);
`;
const IconChevronDown = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: ${(p) => p.propMinHeight};
`;
const Select = styled.div`
  align-self: stretch;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-smi) var(--padding-xs)
    var(--padding-2xs);
  gap: var(--gap-base);
  max-width: 100%;
  color: var(--color-dimgray);
`;
const Column = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  min-width: 348px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
  min-width: ${(p) => p.propMinWidth};
`;
const Placeholder = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
`;
const TextInput = styled.div`
  width: 66px;
  height: ;
  background-color: var(--white);
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-sm) var(--padding-xs)
    var(--padding-xs);
`;
const Column1 = styled.div`
  height: 80px;
  width: 64px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const InputRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;

const Input3 = ({ propMinWidth, propMinHeight }) => {
  return (
    <InputRoot>
      <Column propMinWidth={propMinWidth}>
        <Variant>Variant</Variant>
        <Select>
          <SelectOne>Select</SelectOne>
          <IconChevronDown
            alt=""
            src="/icon--chevron-down.svg"
            propMinHeight={propMinHeight}
          />
        </Select>
      </Column>
      <Column1>
        <Variant>Qty</Variant>
        <TextInput>
          <Placeholder>1</Placeholder>
        </TextInput>
      </Column1>
    </InputRoot>
  );
};

export default Input3;
