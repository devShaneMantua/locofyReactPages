import styled from "styled-components";
import Input from "./Input";
import Input3 from "./Input3";
import FormSubmit from "./FormSubmit";
import FrameSections from "./FrameSections";
import DividerFrame from "./DividerFrame";

const Link = styled.div`
  position: relative;
  line-height: 150%;
`;
const Icon = styled.img`
  height: 16px;
  width: 16px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Link1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Breadcrumbs = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  text-align: center;
  font-size: var(--text-small-normal-size);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Heading = styled.h1`
  margin: 0;
  position: relative;
  font-size: var(--heading-h3-size);
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 1050px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const Price = styled.b`
  position: relative;
  line-height: 140%;
  white-space: nowrap;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const ReviewStarsIcon = styled.img`
  align-self: stretch;
  width: 1px;
  position: relative;
  max-height: 100%;
  min-height: 34px;
`;
const InputFieldsIcon = styled.img`
  height: 15.1px;
  width: 16px;
  position: relative;
  min-height: 15px;
`;
const InputFieldsIcon1 = styled.img`
  height: 15.2px;
  width: 16px;
  position: relative;
  min-height: 15px;
`;
const Stars = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-9xs);
`;
const ProductReview = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  text-align: center;
  font-size: var(--text-small-normal-size);
`;
const Price1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--heading-h5-size);
`;
const FormSubmitButton = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
`;
const ImageContainers = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-tiny-normal-size);
  line-height: 150%;
  text-align: center;
`;
const ProductDescription = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
`;
const FrameProductDescription = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-5xs);
  box-sizing: border-box;
  max-width: 100%;
`;
const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const FrameProductDescriptionParentRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  min-width: 400px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;

const FrameComponent1 = () => {
  return (
    <FrameProductDescriptionParentRoot>
      <FrameProductDescription>
        <ProductDescription>
          <Breadcrumbs>
            <Link>Shop all</Link>
            <Icon loading="eager" alt="" src="/icon.svg" />
            <Link>Category</Link>
            <Icon loading="eager" alt="" src="/icon.svg" />
            <Link1>Product name</Link1>
          </Breadcrumbs>
          <Heading>Product name</Heading>
          <Price1>
            <Price>{`$55 `}</Price>
            <ReviewStarsIcon loading="eager" alt="" src="/vector-2.svg" />
            <ProductReview>
              <Stars>
                <InputFieldsIcon loading="eager" alt="" src="/vector.svg" />
                <InputFieldsIcon loading="eager" alt="" src="/vector.svg" />
                <InputFieldsIcon loading="eager" alt="" src="/vector.svg" />
                <InputFieldsIcon1 loading="eager" alt="" src="/vector-3.svg" />
                <InputFieldsIcon loading="eager" alt="" src="/vector-4.svg" />
              </Stars>
              <Link>(3.5 stars) • 10 reviews</Link>
            </ProductReview>
          </Price1>
          <FormSubmitButton>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            varius enim in eros elementum tristique. Duis cursus, mi quis
            viverra ornare, eros dolor interdum nulla, ut commodo diam libero
            vitae erat.
          </FormSubmitButton>
          <Input propWidth="unset" propAlignSelf="stretch" />
          <Input3 />
          <FormSubmit
            propWidth="unset"
            propAlignSelf="stretch"
            buttonDisplay="inline-block"
            buttonDisplay1="inline-block"
          />
          <ImageContainers>Free shipping over $50</ImageContainers>
        </ProductDescription>
      </FrameProductDescription>
      <FrameSections plus="/plus.svg" plus1="/plus.svg" />
      <DividerFrame heading="Returns" icon="/plus.svg" />
      <Divider />
    </FrameProductDescriptionParentRoot>
  );
};

export default FrameComponent1;
