import styled from "styled-components";

const Divider = styled.div`
  align-self: stretch;
  height: 1px;
  position: relative;
  background-color: var(--black);
`;
const Details = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  font-weight: 600;
  display: inline-block;
  max-width: calc(100% - 36px);
`;
const PlusIcon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const DetailsReturn = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
`;
const ParentFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const EmptyFrame = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: 100%;
`;
const RowElements = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-5xs);
  box-sizing: border-box;
  max-width: 100%;
  font-size: var(--text-regular-normal-size);
`;
const ShippingParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xs);
  max-width: 100%;
`;
const ImagePlaceholders = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const FrameSectionsRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  text-align: left;
  font-size: var(--text-medium-semi-bold-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const FrameSections = ({ plus, plus1 }) => {
  return (
    <FrameSectionsRoot>
      <ParentFrame>
        <Divider />
        <DetailsReturn>
          <Details>Details</Details>
          <PlusIcon loading="eager" alt="" src={plus} />
        </DetailsReturn>
      </ParentFrame>
      <RowElements>
        <EmptyFrame>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
          Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc
          ut sem vitae risus tristique posuere.
        </EmptyFrame>
      </RowElements>
      <ParentFrame>
        <Divider />
        <ShippingParent>
          <Details>Shipping</Details>
          <PlusIcon loading="eager" alt="" src={plus1} />
        </ShippingParent>
      </ParentFrame>
      <ImagePlaceholders>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
        varius enim in eros elementum tristique. Duis cursus, mi quis viverra
        ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
        Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut
        sem vitae risus tristique posuere.
      </ImagePlaceholders>
    </FrameSectionsRoot>
  );
};

export default FrameSections;
