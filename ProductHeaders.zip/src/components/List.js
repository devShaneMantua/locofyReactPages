import styled from "styled-components";

const Check = styled.input`
  margin: 0;
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const FormSubmit = styled.div`
  flex: 1;
  position: relative;
  line-height: 150%;
  display: inline-block;
  max-width: calc(100% - 40px);
`;
const ListItem = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
`;
const ListRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 255px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const List = () => {
  return (
    <ListRoot>
      <ListItem>
        <Check type="checkbox" />
        <FormSubmit>Feature text goes here</FormSubmit>
      </ListItem>
      <ListItem>
        <Check type="checkbox" />
        <FormSubmit>Feature text goes here</FormSubmit>
      </ListItem>
      <ListItem>
        <Check type="checkbox" />
        <FormSubmit>Feature text goes here</FormSubmit>
      </ListItem>
      <ListItem>
        <Check type="checkbox" />
        <FormSubmit>Feature text goes here</FormSubmit>
      </ListItem>
    </ListRoot>
  );
};

export default List;
