import styled from "styled-components";
import List from "./List";

const Link = styled.div`
  position: relative;
  line-height: 150%;
`;
const Icon = styled.img`
  height: 16px;
  width: 16px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Link1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const LinkFrame = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
  text-align: center;
`;
const Heading = styled.h1`
  margin: 0;
  position: relative;
  font-size: inherit;
  line-height: 120%;
  font-weight: 700;
  font-family: inherit;
  display: inline-block;
  max-width: 100%;
  @media screen and (max-width: 1000px) {
    font-size: var(--heading-h4-size);
    line-height: 38px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--heading-h5-size);
    line-height: 29px;
  }
`;
const Content = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--text-regular-normal-size);
  line-height: 150%;
`;
const ListFrame = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--heading-h3-size);
`;
const Heading1 = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const Content1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  box-sizing: border-box;
  gap: var(--gap-5xl);
  max-width: 100%;
  font-size: var(--text-regular-normal-size);
  @media screen and (max-width: 1000px) {
    flex-wrap: wrap;
  }
`;
const List1 = styled.div`
  align-self: stretch;
  border: 1px solid var(--black);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-13xl) var(--padding-12xl);
  gap: var(--gap-base);
  max-width: 100%;
  font-size: var(--text-medium-semi-bold-size);
`;
const LinkIconFrameRoot = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  min-width: 567px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-small-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-13xl);
  }
`;

const FrameComponent4 = () => {
  return (
    <LinkIconFrameRoot>
      <LinkFrame>
        <Link>All</Link>
        <Icon loading="eager" alt="" src="/icon.svg" />
        <Link>Category</Link>
        <Icon alt="" src="/icon.svg" />
        <Link1>Digital product name</Link1>
      </LinkFrame>
      <ListFrame>
        <Heading>Digital product name</Heading>
        <Content>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla.
        </Content>
      </ListFrame>
      <List1>
        <Heading1>Includes:</Heading1>
        <Content1>
          <List />
          <List />
        </Content1>
      </List1>
    </LinkIconFrameRoot>
  );
};

export default FrameComponent4;
