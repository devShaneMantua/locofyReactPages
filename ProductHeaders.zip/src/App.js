import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import ProductHeader from "./pages/ProductHeader";
import ProductHeader1 from "./pages/ProductHeader1";
import ProductHeader2 from "./pages/ProductHeader2";
import ProductHeader3 from "./pages/ProductHeader3";
import ProductHeader from "./pages/ProductHeader4";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/product-header-2":
        title = "";
        metaDescription = "";
        break;
      case "/product-header-3":
        title = "";
        metaDescription = "";
        break;
      case "/product-header-4":
        title = "";
        metaDescription = "";
        break;
      case "/product-header-6":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<ProductHeader />} />
      <Route path="/product-header-2" element={<ProductHeader1 />} />
      <Route path="/product-header-3" element={<ProductHeader2 />} />
      <Route path="/product-header-4" element={<ProductHeader3 />} />
      <Route path="/product-header-6" element={<ProductHeader />} />
    </Routes>
  );
}
export default App;
