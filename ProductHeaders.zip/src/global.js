import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--text-regular-normal: Roboto;

/* font sizes */
--text-regular-normal-size: 16px;
--text-medium-semi-bold-size: 18px;
--text-tiny-normal-size: 12px;
--text-small-normal-size: 14px;
--heading-h5-size: 24px;
--font-size-lgi: 19px;
--heading-h3-size: 40px;
--heading-h4-size: 32px;
--font-size-7xl: 26px;

/* Colors */
--white: #fff;
--black: #000;
--color-darkslategray-100: #333;
--color-darkslategray-200: rgba(51, 51, 51, 0.09);
--color-dimgray: #505050;
--color-gainsboro: #e6e6e6;

/* Gaps */
--gap-61xl: 80px;
--gap-5xl: 24px;
--gap-base: 16px;
--gap-xs: 12px;
--gap-5xs: 8px;
--gap-9xs: 4px;
--gap-13xl: 32px;
--gap-xl: 20px;

/* Paddings */
--padding-93xl: 112px;
--padding-45xl: 64px;
--padding-13xl: 32px;
--padding-xl: 20px;
--padding-5xs: 8px;
--padding-xs: 12px;
--padding-5xl: 24px;
--padding-sm: 14px;
--padding-2xl: 21px;
--padding-smi: 13px;
--padding-2xs: 11px;
--padding-base: 16px;
--padding-lgi: 19px;
--padding-4xl: 23px;
--padding-12xl: 31px;

}
`;
