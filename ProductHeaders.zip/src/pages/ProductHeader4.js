import FrameComponent4 from "../components/FrameComponent4";
import Product from "../components/Product";
import styled from "styled-components";

const LinkIconFrameParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 1100px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
  }
  @media screen and (max-width: 450px) {
    gap: var(--gap-61xl);
  }
`;
const Heading = styled.h3`
  margin: 0;
  position: relative;
  font-size: inherit;
  line-height: 140%;
  font-weight: 700;
  font-family: inherit;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 27px;
  }
`;
const TextFrame = styled.section`
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--heading-h5-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 750px) {
    gap: var(--gap-13xl);
  }
`;
const Divider = styled.div`
  height: 1px;
  width: 872px;
  position: relative;
  background-color: var(--black);
  max-width: 100%;
`;
const HeaderFrame = styled.div`
  width: 1312px;
  height: 5px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Icon = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const Heading1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const IconParent = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const HeaderFrame1 = styled.div`
  width: 1312px;
  height: 31px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const Text1 = styled.div`
  width: 872px;
  position: relative;
  line-height: 150%;
  display: inline-block;
  flex-shrink: 0;
  max-width: 100%;
`;
const HeaderFrame2 = styled.section`
  width: 1312px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  min-height: 80px;
  max-width: 100%;
  text-align: left;
  font-size: var(--text-regular-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;
const Divider1 = styled.div`
  align-self: stretch;
  width: 872px;
  position: relative;
  background-color: var(--black);
  max-width: 100%;
`;
const HeaderFrame3 = styled.div`
  width: 1312px;
  height: 1px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  max-width: 100%;
`;
const ProductHeaderRoot = styled.div`
  width: 100%;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-base);
  letter-spacing: normal;
  text-align: left;
  font-size: var(--text-medium-semi-bold-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
`;

const ProductHeader = () => {
  return (
    <ProductHeaderRoot>
      <TextFrame>
        <LinkIconFrameParent>
          <FrameComponent4 />
          <Product />
        </LinkIconFrameParent>
        <Heading>More information</Heading>
      </TextFrame>
      <HeaderFrame>
        <Divider />
      </HeaderFrame>
      <HeaderFrame1>
        <IconParent>
          <Icon loading="eager" alt="" src="/icon-2.svg" />
          <Heading1>Details One</Heading1>
        </IconParent>
      </HeaderFrame1>
      <HeaderFrame2>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
          Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc
          ut sem vitae risus tristique posuere.
        </Text1>
      </HeaderFrame2>
      <HeaderFrame>
        <Divider />
      </HeaderFrame>
      <HeaderFrame1>
        <IconParent>
          <Icon loading="eager" alt="" src="/icon-2.svg" />
          <Heading1>Details Two</Heading1>
        </IconParent>
      </HeaderFrame1>
      <HeaderFrame2>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
          Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc
          ut sem vitae risus tristique posuere.
        </Text1>
      </HeaderFrame2>
      <HeaderFrame>
        <Divider />
      </HeaderFrame>
      <HeaderFrame1>
        <IconParent>
          <Icon loading="eager" alt="" src="/icon-2.svg" />
          <Heading1>Details Three</Heading1>
        </IconParent>
      </HeaderFrame1>
      <HeaderFrame2>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
          Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc
          ut sem vitae risus tristique posuere.
        </Text1>
      </HeaderFrame2>
      <HeaderFrame>
        <Divider />
      </HeaderFrame>
      <HeaderFrame1>
        <IconParent>
          <Icon loading="eager" alt="" src="/icon-2.svg" />
          <Heading1>Details Four</Heading1>
        </IconParent>
      </HeaderFrame1>
      <HeaderFrame2>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
          Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc
          ut sem vitae risus tristique posuere.
        </Text1>
      </HeaderFrame2>
      <HeaderFrame>
        <Divider />
      </HeaderFrame>
      <HeaderFrame1>
        <IconParent>
          <Icon loading="eager" alt="" src="/icon-2.svg" />
          <Heading1>Details Five</Heading1>
        </IconParent>
      </HeaderFrame1>
      <HeaderFrame2>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
          Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc
          ut sem vitae risus tristique posuere.
        </Text1>
      </HeaderFrame2>
      <HeaderFrame>
        <Divider />
      </HeaderFrame>
      <HeaderFrame1>
        <IconParent>
          <Icon loading="eager" alt="" src="/icon-2.svg" />
          <Heading1>Details Six</Heading1>
        </IconParent>
      </HeaderFrame1>
      <HeaderFrame2>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
          Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc
          ut sem vitae risus tristique posuere.
        </Text1>
      </HeaderFrame2>
      <HeaderFrame>
        <Divider />
      </HeaderFrame>
      <HeaderFrame1>
        <IconParent>
          <Icon loading="eager" alt="" src="/icon-2.svg" />
          <Heading1>Details Seven</Heading1>
        </IconParent>
      </HeaderFrame1>
      <HeaderFrame2>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
          Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc
          ut sem vitae risus tristique posuere.
        </Text1>
      </HeaderFrame2>
      <HeaderFrame>
        <Divider />
      </HeaderFrame>
      <HeaderFrame1>
        <IconParent>
          <Icon loading="eager" alt="" src="/icon-2.svg" />
          <Heading1>Details Eight</Heading1>
        </IconParent>
      </HeaderFrame1>
      <HeaderFrame2>
        <Text1>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          varius enim in eros elementum tristique. Duis cursus, mi quis viverra
          ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.
          Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc
          ut sem vitae risus tristique posuere.
        </Text1>
      </HeaderFrame2>
      <HeaderFrame3>
        <Divider1 />
      </HeaderFrame3>
    </ProductHeaderRoot>
  );
};

export default ProductHeader;
