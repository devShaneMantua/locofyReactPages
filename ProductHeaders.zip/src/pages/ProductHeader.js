import styled from "styled-components";
import FrameComponent from "../components/FrameComponent";

const Link = styled.div`
  position: relative;
  line-height: 150%;
`;
const Icon = styled.img`
  height: 16px;
  width: 16px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const LinkParent = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-5xs);
`;
const PlaceholderImage = styled.img`
  align-self: stretch;
  height: 100px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Column = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const FrameGroup = styled.div`
  height: 685px;
  width: 80px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
`;
const Link1 = styled.div`
  position: relative;
  line-height: 150%;
  font-weight: 600;
`;
const PlaceholderImage1 = styled.img`
  height: 640px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  display: none;
`;
const Column1 = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  background-image: url("/column@3x.png");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
  max-width: 100%;
`;
const ColumnWrapper = styled.div`
  align-self: stretch;
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px 0px var(--padding-sm);
  box-sizing: border-box;
  max-width: 100%;
`;
const FrameContainer = styled.div`
  height: 685px;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: calc(100% - 82px);
`;
const FrameParent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 2px;
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const ProductHeader1Inner = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 45px 0px 0px;
  box-sizing: border-box;
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 1200px) {
    padding-top: 29px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    padding-top: var(--padding-xl);
    box-sizing: border-box;
    min-width: 100%;
  }
`;
const ProductHeaderRoot = styled.div`
  width: 100%;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  letter-spacing: normal;
  text-align: center;
  font-size: var(--text-small-normal-size);
  color: var(--black);
  font-family: var(--text-regular-normal);
  @media screen and (max-width: 1200px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
  }
`;

const ProductHeader = () => {
  return (
    <ProductHeaderRoot>
      <FrameParent>
        <FrameGroup>
          <LinkParent>
            <Link>Shop all</Link>
            <Icon loading="eager" alt="" src="/icon.svg" />
          </LinkParent>
          <Column>
            <PlaceholderImage
              loading="eager"
              alt=""
              src="/placeholder--image@2x.png"
            />
            <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
            <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
          </Column>
        </FrameGroup>
        <FrameContainer>
          <LinkParent>
            <Link>Category</Link>
            <Icon alt="" src="/icon.svg" />
            <Link1>Product name</Link1>
          </LinkParent>
          <ColumnWrapper>
            <Column1>
              <PlaceholderImage1 alt="" src="/placeholder--image@2x.png" />
            </Column1>
          </ColumnWrapper>
        </FrameContainer>
      </FrameParent>
      <ProductHeader1Inner>
        <FrameComponent />
      </ProductHeader1Inner>
    </ProductHeaderRoot>
  );
};

export default ProductHeader;
