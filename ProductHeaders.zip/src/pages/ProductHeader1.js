import styled from "styled-components";
import FrameLinkIcon from "../components/FrameLinkIcon";
import ProductDescription from "../components/ProductDescription";
import Form from "../components/Form";

const PlaceholderImage = styled.img`
  position: absolute;
  top: 157px;
  left: 64px;
  width: 648px;
  height: 624px;
  object-fit: cover;
`;
const Column = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-61xl);
  max-width: 100%;
  @media screen and (max-width: 1200px) {
    flex-wrap: wrap;
  }
`;
const FrameLinkIconParent = styled.main`
  position: absolute;
  top: 112px;
  left: 64px;
  width: 1312px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 48px;
  max-width: 100%;
`;
const ProductHeaderRoot = styled.div`
  width: 100%;
  height: 1486px;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  letter-spacing: normal;
  @media screen and (max-width: 450px) {
    height: auto;
    min-height: 1486;
  }
`;

const ProductHeader1 = () => {
  return (
    <ProductHeaderRoot>
      <PlaceholderImage
        loading="eager"
        alt=""
        src="/placeholder--image1@2x.png"
      />
      <FrameLinkIconParent>
        <FrameLinkIcon />
        <Column>
          <ProductDescription />
          <Form />
        </Column>
      </FrameLinkIconParent>
    </ProductHeaderRoot>
  );
};

export default ProductHeader1;
