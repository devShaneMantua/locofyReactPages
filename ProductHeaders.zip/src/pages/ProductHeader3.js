import FrameComponent3 from "../components/FrameComponent3";
import FrameComponent2 from "../components/FrameComponent2";
import styled from "styled-components";

const ProductHeaderRoot = styled.div`
  width: 100%;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  letter-spacing: normal;
  @media screen and (max-width: 1200px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
  }
`;

const ProductHeader3 = () => {
  return (
    <ProductHeaderRoot>
      <FrameComponent3 />
      <FrameComponent2 />
    </ProductHeaderRoot>
  );
};

export default ProductHeader3;
