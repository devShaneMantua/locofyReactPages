import FrameComponent1 from "../components/FrameComponent1";
import styled from "styled-components";

const PlaceholderImage = styled.img`
  height: 500px;
  flex: 1;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  object-fit: cover;
  display: none;
`;
const Row = styled.div`
  align-self: stretch;
  height: 500px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  background-image: url("/row@3x.png");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
  max-width: 100%;
`;
const PlaceholderImage1 = styled.img`
  align-self: stretch;
  flex: 1;
  position: relative;
  max-width: 110px;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
  min-width: 108px;
  min-height: 96px;
`;
const Row1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-base);
  @media screen and (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
const RowFrame = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  min-width: 400px;
  max-width: 100%;
  @media screen and (max-width: 750px) {
    min-width: 100%;
  }
`;
const ProductHeaderRoot = styled.div`
  width: 100%;
  position: relative;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-93xl) var(--padding-45xl);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  letter-spacing: normal;
  @media screen and (max-width: 1200px) {
    gap: var(--gap-61xl);
    padding-left: var(--padding-13xl);
    padding-right: var(--padding-13xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 750px) {
    gap: var(--gap-61xl);
  }
`;

const ProductHeader2 = () => {
  return (
    <ProductHeaderRoot>
      <FrameComponent1 />
      <RowFrame>
        <Row>
          <PlaceholderImage alt="" src="/placeholder--image@2x.png" />
        </Row>
        <Row1>
          <PlaceholderImage1
            loading="eager"
            alt=""
            src="/placeholder--image2@2x.png"
          />
          <PlaceholderImage1
            loading="eager"
            alt=""
            src="/placeholder--image-11@2x.png"
          />
          <PlaceholderImage1
            loading="eager"
            alt=""
            src="/placeholder--image-2@2x.png"
          />
          <PlaceholderImage1
            loading="eager"
            alt=""
            src="/placeholder--image-3@2x.png"
          />
          <PlaceholderImage1
            loading="eager"
            alt=""
            src="/placeholder--image-4@2x.png"
          />
        </Row1>
      </RowFrame>
    </ProductHeaderRoot>
  );
};

export default ProductHeader2;
